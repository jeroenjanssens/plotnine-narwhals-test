from __future__ import annotations

import decimal
import typing
from contextlib import suppress
from copy import deepcopy
from typing import Iterable, List, cast, overload

import narwhals as nw
import numpy as np

from ._utils import array_kind, check_required_aesthetics, frame, ninteraction
from ._utils.frame import native_io
from ._utils.registry import Registry
from .exceptions import PlotnineError
from .mapping._asis import is_asis
from .mapping.aes import (
    NO_GROUP,
    POSITION_AESTHETICS,
    X_AESTHETICS,
    Y_AESTHETICS,
    aes,
    make_labels,
)
from .mapping.evaluation import evaluate_aesthetics, stage

if typing.TYPE_CHECKING:
    from typing import Any, Callable, Literal, Sequence, SupportsIndex

    from plotnine import ggplot
    from plotnine._utils.frame import DataFrame, Implementation
    from plotnine.coords.coord import coord
    from plotnine.facets.layout import Layout
    from plotnine.geoms.geom import geom
    from plotnine.iapi import labels_view
    from plotnine.layer import layer
    from plotnine.mapping import Environment
    from plotnine.positions.position import position
    from plotnine.scales.scales import Scales
    from plotnine.stats.stat import stat
    from plotnine.typing import (
        DataLike,
        LayerDataLike,
    )


class layer:
    """
    Layer

    When a `geom` or `stat` is added to a
    [](`~plotnine.ggplot`) object, it creates a single layer.
    This class is a representation of that layer.

    Parameters
    ----------
    geom :
        Geom used to draw this layer. Accepts an instance,
        a class, or a string name (e.g. ``"point"``).
    stat :
        Stat used for the statistical transformation of data
        in this layer. Accepts an instance, a class, or a
        string name. If ``None``, the geom's default stat is
        used.
    mapping :
        Aesthetic mappings.
    data :
        Data plotted in this layer. If `None`, the data from
        the [](`~plotnine.ggplot`) object will be used.
    position :
        Position adjustment for geometries in this layer.
        Accepts an instance, a class, or a string name. If
        ``None``, the geom's default position is used.
    inherit_aes :
        If `True` inherit from the aesthetic mappings of
        the [](`~plotnine.ggplot`) object.
    show_legend :
        Whether to make up and show a legend for the mappings
        of this layer. If `None` then an automatic/good choice
        is made.
    raster :
        If `True`, draw onto this layer a raster (bitmap)
        object even if the final image format is vector.
    **kwargs :
        Keyword arguments passed to the geom constructor when
        *geom* is a class or string.
    """

    # Data for this layer. It is a narwhals dataframe.
    data: DataFrame

    # The dataframe library to use when the layer has no data
    _backend: Implementation

    # The aesthetics whose values are literal i.e. they bypass
    # the scales
    asis: set[str]

    def __init__(
        self,
        geom: geom | type[geom] | str | None = None,
        stat: stat | type[stat] | str | None = None,
        *,
        mapping: aes | None = None,
        data: LayerDataLike | None = None,
        position: position | type[position] | str | None = None,
        inherit_aes: bool = True,
        show_legend: bool | dict[str, bool] | None = None,
        raster: bool = False,
        **kwargs: Any,
    ):
        # Stat-first: derive geom from stat's default
        if geom is None:
            if stat is not None:
                stat_ref = _lookup_stat(stat)
                if isinstance(stat_ref, type):
                    geom = stat_ref.default_params["geom"]
                else:
                    geom = stat_ref.params["geom"]
                    # Forward stat instance's kwargs to the geom
                    if mapping is None and data is None and not kwargs:
                        mapping = stat_ref._raw_kwargs.get("mapping")
                        data = stat_ref._raw_kwargs.get("data")
                        kwargs = {
                            k: v
                            for k, v in stat_ref._raw_kwargs.items()
                            if k not in ("mapping", "data", "geom")
                        }
            else:
                # i.e. layer()
                geom = "blank"

        geom = cast("geom | type[geom] | str", geom)
        _geom = _resolve_geom(geom, mapping, data, kwargs)
        _stat = _resolve_stat(stat, _geom)
        _pos = _resolve_position(position, _geom)
        self._verify_arguments(_geom, _stat)

        # Layer params: prefer explicit kwargs, fall back to
        # geom._raw_kwargs, then geom.default_params
        raw = _geom._raw_kwargs
        self.inherit_aes = raw.get(
            "inherit_aes",
            _geom.default_params.get("inherit_aes", inherit_aes),
        )
        self.show_legend = raw.get(
            "show_legend",
            _geom.default_params.get("show_legend", show_legend),
        )
        self.raster = raw.get(
            "raster",
            _geom.default_params.get("raster", raster),
        )

        self.geom = _geom
        self.stat = _stat
        self._data = _geom.data
        self.mapping = _geom.mapping
        self.position = _pos
        self.zorder = 0
        self.asis = set()

    @staticmethod
    def _verify_arguments(geom: geom, stat: stat) -> None:
        """
        Verify arguments for the geom, stat and layer
        """
        geom_stat_args = geom._raw_kwargs.keys() | stat._raw_kwargs.keys()
        unknown = (
            geom_stat_args
            - geom.aesthetics()
            - geom.default_params.keys()
            - stat.aesthetics()
            - stat.default_params.keys()
            - {
                "data",
                "mapping",
                "geom",
                "stat",
                "position",
                "na_rm",
                "show_legend",
                "inherit_aes",
                "raster",
            }
        )
        if unknown:
            msg = (
                "Parameters {}, are not understood by "
                "either the geom, stat or layer."
            )
            raise PlotnineError(msg.format(unknown))

    def __radd__(self, other: ggplot) -> ggplot:
        """
        Add layer to ggplot object
        """
        try:
            other.layers.append(self)
        except AttributeError as e:
            msg = f"Cannot add layer to object of type {type(other)!r}"
            raise PlotnineError(msg) from e
        return other

    def __deepcopy__(self, memo: dict[Any, Any]) -> layer:
        """
        Deep copy without copying the self.data dataframe
        """
        cls = self.__class__
        result = cls.__new__(cls)
        memo[id(self)] = result
        old = self.__dict__
        new = result.__dict__

        for key, item in old.items():
            if key == "data":
                new[key] = item
            else:
                new[key] = deepcopy(item, memo)

        return result

    def setup(self, plot: ggplot):
        """
        Prepare layer for the plot building

        Give the layer access to the data, mapping and environment
        """
        self._backend = _plot_backend(plot)
        self._make_layer_data(plot.data)
        self._make_layer_mapping(plot.mapping)
        self._make_layer_environments(plot.environment)
        self._share_layer_params()

    def _make_layer_data(self, plot_data: DataLike | None):
        """
        Generate data to be used by this layer

        Parameters
        ----------
        plot_data :
            ggplot object data
        """
        if plot_data is None:
            data = frame.frame(backend=self._backend)
        else:
            data = frame.to_frame(plot_data)

        # Each layer that does not have data gets the ggplot.data.
        # Since narwhals dataframes cannot be modified in place, the
        # users data cannot be altered.
        if self._data is None:
            self.data = data
        elif callable(self._data):
            result = self._data(data.to_native())
            if not frame.is_frame(result):
                raise PlotnineError(
                    "Data function must return a dataframe, "
                    f"but it returned a {type(result).__name__}."
                )
            self.data = frame.to_frame(result)
        elif frame.is_frame(self._data) or hasattr(self._data, "to_pandas"):
            self.data = frame.to_frame(self._data)
        else:
            _geom_name = self.geom.__class__.__name__
            _data_name = self._data.__class__.__name__
            msg = (
                f"{_geom_name} layer expects a dataframe, "
                f"but it got {_data_name} instead."
            )
            raise PlotnineError(msg)

        self.data = _decimal_columns_to_float(self.data)

    def _make_layer_mapping(self, plot_mapping: aes):
        """
        Create the aesthetic mappings to be used by this layer

        Parameters
        ----------
        plot_mapping :
            ggplot object mapping
        """
        if self.inherit_aes:
            self.mapping = self.mapping.inherit(plot_mapping)

        # aesthetics set as parameters override the same
        # aesthetics set as mappings, so we can ignore
        # those in the mapping
        for ae in self.geom.aes_params:
            if ae in self.mapping:
                del self.mapping[ae]

        # Set group as a mapping if set as a parameter
        if "group" in self.geom.aes_params:
            group = self.geom.aes_params["group"]
            # Double quote str so that it evaluates to itself
            if isinstance(group, str):
                group = f'"{group}"'
            self.mapping["group"] = stage(start=group)

    def _make_layer_environments(self, plot_environment: Environment):
        """
        Create the aesthetic mappings to be used by this layer

        Parameters
        ----------
        plot_environment :
            Namespace in which to execute aesthetic expressions.
        """
        self.geom.environment = plot_environment
        self.stat.environment = plot_environment

    def _share_layer_params(self):
        """
        Pass necessary layer parameters to the geom
        """
        self.geom.params["zorder"] = self.zorder
        self.geom.params["raster"] = self.raster
        self.geom.params["inherit_aes"] = self.inherit_aes

    def compute_aesthetics(self, plot: ggplot):
        """
        Return a dataframe where the columns match the aesthetic mappings

        Transformations like 'factor(cyl)' and other
        expression evaluation are  made in here
        """
        data = frame.to_frame(self.data)
        evaled, asis = evaluate_aesthetics(
            self.mapping._starting, data, plot.environment
        )
        self.asis = asis | {
            ae for ae, value in self.geom.aes_params.items() if is_asis(value)
        }
        evaled_aes = aes(
            **{col: col for col in evaled.columns if col not in asis}
        )
        plot.scales.add_defaults(evaled.drop(*asis), evaled_aes)

        # With no data and vectors suppled to aesthetics, there is
        # only one panel
        no_data = len(data) == 0 and len(evaled) > 0
        panel = 1 if no_data else data["PANEL"]

        evaled = frame.assign(evaled, PANEL=panel)
        data = add_group(evaled)
        self.data = frame.sort(data, "PANEL")

    def compute_statistic(self, layout: Layout):
        """
        Compute & return statistics for this layer
        """
        data = frame.to_frame(self.data)
        if not len(data):
            return

        self.stat.setup_params(data)
        data = self.stat.use_defaults(data)
        data = self.stat.setup_data(data)
        data = self.stat.compute_layer(data, layout)
        self.data = frame.to_frame(data)

    def map_statistic(self, plot: ggplot):
        """
        Mapping aesthetics to computed statistics
        """
        # Mixin default stat aesthetic mappings
        calculated = (
            aes(**self.stat.DEFAULT_AES)._calculated | self.mapping._calculated
        )

        if not len(self.data) or not calculated:
            return

        # The statistics are calculated in transformed space, but
        # we evaluate the mapping to them in data space.
        # NOTE: If the inverse-retransform turn out to be slow
        # we can try applying them to only the required columns.
        data = self._apply_scales(plot.scales.inverse_df)
        stat_data, asis = evaluate_aesthetics(
            calculated, data, plot.environment
        )
        self.asis = (self.asis - set(stat_data.columns)) | asis

        # If there are duplicate columns, we use the computed
        # ones in stat_data
        columns = [c for c in data.columns if c not in stat_data.columns]
        data = nw.concat([data.select(columns), stat_data], how="horizontal")
        self.data = data
        data = self._apply_scales(plot.scales.transform_df)
        self.data = data

        # Add any new scales, if needed
        new = {ae: ae for ae in stat_data.columns if ae not in self.asis}
        plot.scales.add_defaults(data.select(list(new)), new)

    def setup_data(self):
        """
        Prepare/modify data for plotting
        """
        data = frame.to_frame(self.data)
        if len(data) == 0:
            return

        self.geom.params["stat_params"] = self.stat.params
        self.geom.setup_params(data)
        self.geom.setup_aes_params(data)
        data = frame.to_frame(self.geom.setup_data(data))

        check_required_aesthetics(
            self.geom.REQUIRED_AES,
            set(data.columns) | set(self.geom.aes_params),
            self.geom.__class__.__name__,
        )

        self.data = data

    def compute_position(self, layout: Layout):
        """
        Compute the position of each geometric object

        This is in concert with the other objects in the panel depending
        on the position class of the geom
        """
        data = frame.to_frame(self.data)
        if len(data) == 0:
            return

        params = self.position.setup_params(data)
        data = self.position.setup_data(data, params)
        data = self.position.compute_layer(data, params, layout)
        self.data = frame.to_frame(data)

    def resolve_asis_positions(self, layout: Layout, coord: coord):
        """
        Convert panel fractions in position aesthetics to data coordinates

        Parameters
        ----------
        layout :
            Layout containing each panel's trained ranges.
        coord :
            Coordinate system that converts panel ranges to the
            unflipped, untransformed data coordinates in the columns.
        """
        data = frame.to_frame(self.data)
        if not len(data):
            return

        columns = (self.asis & POSITION_AESTHETICS) & set(data.columns)
        if not columns:
            return

        by_dimension: tuple[tuple[set[str], Literal["x", "y"]], ...] = (
            (columns & X_AESTHETICS, "x"),
            (columns & Y_AESTHETICS, "y"),
        )
        panels = frame.as_numpy(data["PANEL"])
        resolved = {}
        for col in columns:
            # Integer fractions become floats when they are resolved
            resolved[col] = frame.as_numpy(data[col]).astype(float)

        for pid in np.unique(panels):
            idx = panels == pid
            panel_params = layout.panel_params[int(pid) - 1]
            for cols, dimension in by_dimension:
                for col in cols:
                    resolved[col][idx] = coord.panel_fraction_to_data(
                        resolved[col][idx], panel_params, dimension
                    )

        self.data = frame.assign(data, **resolved)

    def draw(self, layout: Layout, coord: coord):
        """
        Draw geom

        Parameters
        ----------
        layout : Layout
            Layout object created when the plot is getting
            built
        coord : coord
            Type of coordinate axes
        """
        data = frame.to_frame(self.geom.handle_na(frame.to_frame(self.data)))
        self.data = data
        # At this point each layer must have the data
        # that is created by the plot build process
        self.geom.draw_layer(data, layout, coord)

    def use_defaults(
        self,
        data: DataFrame,
        aes_modifiers: dict[str, Any],
        scales: Scales | None = None,
    ) -> DataFrame:
        """
        Prepare/modify data for plotting

        Parameters
        ----------
        data :
            Data
        aes_modifiers :
            Expression to evaluate and replace aesthetics in
            the data.
        """
        data = frame.to_frame(data)
        old_columns = set(data.columns)
        data = frame.to_frame(self.geom.use_defaults(data, aes_modifiers))
        if scales is not None:
            # The default aesthetics and the aesthetic parameters are
            # specified in userspace. When we add them we have to
            # transform them.
            new_columns = [
                c
                for c in data.columns
                if c not in old_columns and c not in self.asis
            ]
            if new_columns:
                transformed = frame.to_frame(
                    scales.transform_df(data.select(new_columns))
                )
                data = data.with_columns(transformed[c] for c in new_columns)
        return data

    def finish_statistics(self):
        """
        Prepare/modify data for plotting
        """
        data = self.stat.finish_layer(frame.to_frame(self.data))
        self.data = frame.to_frame(data)

    def update_labels(self, labels: labels_view):
        """
        Fill unset labels from this layer's mapping and statistic

        Parameters
        ----------
        labels :
            Labels to update.
        """
        labels.add_defaults(self.mapping.labels)
        labels.add_defaults(make_labels(self.stat.DEFAULT_AES))

    def _apply_scales(self, func: Callable[[Any], Any]) -> DataFrame:
        """
        Apply a function of the scales to the data that is not literal

        Literal (`I()`) columns bypass the scales. They are left out of
        the data that func gets, and then added back to the result.

        Parameters
        ----------
        func :
            A function that takes a dataframe and returns a dataframe
            with the same number of rows, e.g. `scales.transform_df`.
        """
        data = frame.to_frame(self.data)
        asis = [c for c in data.columns if c in self.asis]
        if not asis:
            return frame.to_frame(func(data))

        result = frame.to_frame(func(data.drop(*asis)))
        result = nw.concat([result, data.select(asis)], how="horizontal")
        order = [c for c in data.columns if c in result.columns]
        order += [c for c in result.columns if c not in order]
        return result.select(order)


class Layers(List[layer]):
    """
    List of layers

    During the plot building pipeline, many operations are
    applied at all layers in the plot. This class makes those
    tasks easier.
    """

    @overload
    def __radd__(self, other: Iterable[layer]) -> Layers: ...

    @overload
    def __radd__(self, other: ggplot) -> ggplot: ...

    def __radd__(self, other: Iterable[layer] | ggplot) -> Layers | ggplot:
        """
        Add layers to ggplot object
        """
        # Add layers to ggplot object
        from .ggplot import ggplot

        if isinstance(other, ggplot):
            for obj in self:
                other += obj
        else:
            raise PlotnineError(
                f"Cannot add Layers to object of type {type(other)}"
            )
        return other

    @overload
    def __getitem__(self, key: SupportsIndex) -> layer: ...

    @overload
    def __getitem__(self, key: slice) -> Layers: ...

    def __getitem__(self, key: SupportsIndex | slice) -> layer | Layers:
        result = super().__getitem__(key)
        if isinstance(result, Iterable):
            result = Layers(result)
        return result

    @property
    def data(self) -> list[DataFrame]:
        return [l.data for l in self]

    def setup(self, plot: ggplot):
        # If zorder is 0, it is left to MPL
        for i, l in enumerate(self, start=1):
            l.zorder = i
            l.setup(plot)

    def setup_data(self):
        for l in self:
            l.setup_data()

    def draw(self, layout: Layout, coord: coord):
        for l in self:
            l.draw(layout, coord)

    def compute_aesthetics(self, plot: ggplot):
        for l in self:
            l.compute_aesthetics(plot)

    def compute_statistic(self, layout: Layout):
        for l in self:
            l.compute_statistic(layout)

    def map_statistic(self, plot: ggplot):
        for l in self:
            l.map_statistic(plot)

    def compute_position(self, layout: Layout):
        for l in self:
            l.compute_position(layout)

    def resolve_asis_positions(self, layout: Layout, coord: coord):
        """
        Convert panel fractions in position aesthetics to data coordinates

        Parameters
        ----------
        layout :
            Layout containing each panel's trained ranges.
        coord :
            Coordinate system used by each layer.
        """
        for l in self:
            l.resolve_asis_positions(layout, coord)

    def use_defaults_after_scale(self, scales: Scales):
        for l in self:
            data = l.use_defaults(l.data, l.mapping._scaled, scales)
            l.data = data

    def transform(self, scales: Scales):
        for l in self:
            l.data = l._apply_scales(scales.transform_df)

    def train(self, scales: Scales):
        for l in self:
            data = frame.to_frame(l.data)
            scales.train_df(data.drop(*(l.asis & set(data.columns))))

    def map(self, scales: Scales):
        for l in self:
            l.data = l._apply_scales(scales.map_df)

    def finish_statistics(self):
        for l in self:
            l.finish_statistics()

    def update_labels(self, labels: labels_view):
        """
        Fill unset labels from every layer's mapping and statistic

        Parameters
        ----------
        labels :
            Labels to update.
        """
        for l in self:
            l.update_labels(labels)


@native_io
def add_group(data: DataFrame) -> DataFrame:
    """
    Add group to the dataframe

    The group depends on the interaction of the discrete
    aesthetic columns in the dataframe.
    """
    if len(data) == 0:
        return data

    if "group" not in data.columns:
        # Exclude some "special" aesthetics from contributing towards
        # the grouping.
        # label - geom_text, geom_label
        # geometry - geom_map
        # where - geom_ribbon
        # A subgroup divides one polygon group into rings.
        # subgroup - geom_polygon
        ignore = ["PANEL", "label", "geometry", "where", "subgroup"]
        disc = discrete_columns(data, ignore=ignore)
        if disc:
            group = ninteraction(data.select(disc), drop=True)
        else:
            group = NO_GROUP
    else:
        group = ninteraction(data.select("group"), drop=True)

    return frame.assign(data, group=group)


@native_io
def discrete_columns(df: DataFrame, ignore: Sequence[str]) -> Sequence[str]:
    """
    Return a list of the discrete columns in the dataframe

    Parameters
    ----------
    df :
        Data
    ignore :
        A list|set|tuple with the names of the columns to skip.
    """
    lst = []
    for col in df.columns:
        if array_kind.discrete(df[col]) and (col not in ignore):
            # Some columns are represented as object dtype
            # but may have compound structures as values.
            if df.schema[col] == nw.Object:
                try:
                    hash(df[col].item(0))
                except TypeError:
                    continue
            lst.append(str(col))
    return lst


def _resolve_geom(
    geom_spec: geom | type[geom] | str,
    mapping: aes | None,
    data: LayerDataLike | None,
    kwargs: dict[str, Any],
) -> geom:
    """
    Resolve a geom specification to an instantiated geom

    Parameters
    ----------
    geom_spec :
        A geom instance, class, or string name.
    mapping :
        Aesthetic mappings.
    data :
        Layer data.
    kwargs :
        Additional keyword arguments forwarded to the geom
        constructor.
    """
    from .geoms.geom import geom as geom_cls

    if isinstance(geom_spec, geom_cls):
        for param in set(geom_spec.aesthetics()) & set(kwargs):
            geom_spec.aes_params[param] = kwargs[param]

        for param in set(geom_spec.default_params) & set(kwargs):
            geom_spec.params[param] = kwargs[param]
        return geom_spec

    if isinstance(geom_spec, type) and issubclass(geom_spec, geom_cls):
        klass = geom_spec
    elif isinstance(geom_spec, str):
        name = geom_spec
        if not name.startswith("geom_"):
            name = f"geom_{name}"
        klass = Registry[name]
    else:
        raise PlotnineError(f"Unknown geom of type {type(geom_spec)}")

    return klass(mapping, data, **kwargs)


def _lookup_stat(
    stat_spec: stat | type[stat] | str,
) -> stat | type[stat]:
    """
    Look up a stat specification without instantiation

    Parameters
    ----------
    stat_spec :
        A stat instance, class, or string name.

    Returns
    -------
    :
        The stat instance or class.
    """
    from .stats.stat import stat as stat_cls

    # Duck-type guard for module reloads
    if not isinstance(stat_spec, type) and hasattr(stat_spec, "compute_layer"):
        return stat_spec  # pyright: ignore[reportReturnType]

    if isinstance(stat_spec, stat_cls):
        return stat_spec

    if isinstance(stat_spec, type) and issubclass(stat_spec, stat_cls):
        return stat_spec

    if isinstance(stat_spec, str):
        name = stat_spec
        if not name.startswith("stat_"):
            name = f"stat_{name}"
        return Registry[name]

    raise PlotnineError(f"Unknown stat of type {type(stat_spec)}")


def _resolve_stat(
    stat_spec: stat | type[stat] | str | None,
    geom_obj: geom,
) -> stat:
    """
    Resolve a stat specification to an instantiated stat

    Parameters
    ----------
    stat_spec :
        A stat instance, class, string name, or None to use
        the geom's default.
    geom_obj :
        The resolved geom (used to derive defaults).
    """
    from .stats.stat import stat as stat_cls

    if stat_spec is None:
        stat_spec = geom_obj.params["stat"]

    result = _lookup_stat(stat_spec)  # pyright: ignore[reportArgumentType]

    if isinstance(result, stat_cls):
        kwargs = result._raw_kwargs
        for param in set(result.aesthetics()) & set(kwargs):
            result.aes_params[param] = kwargs[param]

        for param in set(result.default_params) & set(kwargs):
            result.params[param] = kwargs[param]
        return result

    # It's a class — instantiate with filtered geom kwargs
    klass = result
    kwargs = geom_obj._raw_kwargs
    valid_kwargs = (
        klass.aesthetics() | klass.default_params.keys()
    ) & kwargs.keys()
    params = {k: kwargs[k] for k in valid_kwargs}
    return klass(**params)


def _resolve_position(
    position_spec: position | type[position] | str | None,
    geom_obj: geom,
) -> position:
    """
    Resolve a position specification to an instantiated position

    Parameters
    ----------
    position_spec :
        A position instance, class, string name, or None to use
        the geom's default.
    geom_obj :
        The resolved geom (used to derive defaults).
    """
    from .positions.position import position as position_cls

    if position_spec is None:
        position_spec = geom_obj.params.get("position", "identity")

    if isinstance(position_spec, position_cls):
        return position_spec

    if isinstance(position_spec, type) and issubclass(
        position_spec, position_cls
    ):
        klass = position_spec
    elif isinstance(position_spec, str):
        name = position_spec
        if not name.startswith("position_"):
            name = f"position_{name}"
        klass = Registry[name]
    else:
        raise PlotnineError(f"Unknown position of type {type(position_spec)}")

    return klass()


def _decimal_columns_to_float(data: DataFrame) -> DataFrame:
    """
    Cast columns of decimal values to float

    A Decimal column or a pandas object column holding
    `decimal.Decimal` values would be treated as discrete, and
    such a column could not be used with a continuous scale. Casting
    it to float lets it behave like any other numeric column.
    """
    cols = []
    for name, dtype in data.schema.items():
        if dtype == nw.Decimal:
            cols.append(name)
        elif dtype == nw.Object:
            values = data[name].drop_nulls()
            if len(values) and isinstance(values.item(0), decimal.Decimal):
                cols.append(name)

    if not cols:
        return data

    return data.with_columns(
        frame.series(
            [None if v is None else float(v) for v in data[name].to_list()],
            name,
            backend=data.implementation,
            dtype=nw.Float64,
        )
        for name in cols
    )


def _plot_backend(plot: ggplot) -> Implementation:
    """
    Library of the dataframes that plotnine creates for a plot

    It is the library of the plot data or the first layer with data.
    """
    candidates = [plot.data] + [l._data for l in plot.layers]
    for data in candidates:
        if data is not None and not callable(data):
            with suppress(TypeError):
                return frame.to_frame(data).implementation
    return frame.default_backend()
