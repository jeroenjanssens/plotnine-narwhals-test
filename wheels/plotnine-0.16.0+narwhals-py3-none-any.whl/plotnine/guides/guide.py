from __future__ import annotations

from abc import ABC
from dataclasses import asdict, dataclass, field
from functools import cached_property
from types import SimpleNamespace as NS
from typing import TYPE_CHECKING, cast

from .._utils import MARGIN_SIDE, ensure_xy_location
from .._utils.registry import Register
from ..themes.theme import theme as Theme

if TYPE_CHECKING:
    from typing import Literal, Optional, Sequence, TypeAlias

    from matplotlib.figure import Figure
    from matplotlib.offsetbox import PackerBase
    from typing_extensions import Self

    from plotnine import aes, ggplot, guides
    from plotnine.guides.guides import LegendOwner
    from plotnine.iapi import guide_text
    from plotnine.layer import Layers, layer
    from plotnine.scales.scale import scale
    from plotnine.typing import (
        LegendPosition,
        Orientation,
        Side,
    )

    from .guides import GuidesElements

    AlignDict: TypeAlias = dict[
        Literal["ha", "va"], dict[tuple[Orientation, Side], str]
    ]
    from plotnine._utils.frame import DataFrame


@dataclass
class guide(ABC, metaclass=Register):
    """
    Base class for all guides

    Notes
    -----
    At the moment not all parameters have been fully implemented.
    """

    title: Optional[str] = None
    """
    Title of the guide. Default is the name of the aesthetic or the
    name specified using [](`~plotnine.components.labels.lab`)
    """

    theme: Theme = field(default_factory=Theme)
    """A theme to style the guide. If `None`, the plots theme is used."""

    position: Optional[LegendPosition] = None
    """Where to place the guide relative to the panels."""

    direction: Optional[Orientation] = None
    """
    Direction of the guide. The default is depends on
    [](`~plotnine.themes.themeable.legend_position`).
    """

    reverse: bool = False
    """Whether to reverse the order of the legend keys."""

    order: int = 0
    """Order of this guide among multiple guides."""

    # Non-Parameter Attributes
    available_aes: set[str] = field(init=False, default_factory=set)

    hash: str = field(init=False, repr=False)
    key: DataFrame = field(init=False, repr=False)
    plot_layers: Layers = field(init=False, repr=False)
    plot_mapping: aes = field(init=False, repr=False)
    guides_elements: GuidesElements = field(init=False, repr=False)
    elements: GuideElements = field(init=False, repr=False)

    # Set in `_bind_owner()`; the guide theme reads it through its owner.
    figure: Figure = field(init=False, repr=False)

    def legend_aesthetics(self, layer: layer):
        """
        Return the aesthetics that contribute to the legend

        Parameters
        ----------
        layer : Layer
            Layer whose legend is to be drawn

        Returns
        -------
        matched : list
            List of the names of the aethetics that contribute
            to the legend.
        """
        l = layer
        legend_ae = set(self.key.columns) - {"label"}
        all_ae = (
            l.mapping.keys()
            | (self.plot_mapping if l.inherit_aes else set())
            | l.stat.DEFAULT_AES.keys()
        )
        geom_ae = l.geom.REQUIRED_AES | l.geom.DEFAULT_AES.keys()
        matched = all_ae & geom_ae & legend_ae
        matched = list(matched - set(l.geom.aes_params) - l.asis)
        return matched

    def _bind_source(self, plot: ggplot):
        """
        Bind to the source plot

        Captures the data-source state: layers and mapping. These
        determine which geoms contribute glyphs to the guide.

        Parameters
        ----------
        plot :
            The plot that supplies layers and mapping for this guide.
        """
        self.plot_layers = plot.built.layers
        self.plot_mapping = plot.mapping

    def _resolve_theme(self, owner: LegendOwner) -> Theme:
        """
        Return the guide theme resolved against its rendering owner
        """
        return owner.theme + self.theme

    @property
    def _elements_cls(self) -> type[GuideElements]:
        return GuideElements

    def _bind_owner(self, owner: LegendOwner):
        """
        Bind to the rendering owner

        Captures the rendering context: the owner's theme and figure.
        The parent container's `guides_elements` is assigned separately
        by the container's own owner-binding loop.

        Parameters
        ----------
        owner :
            Whoever renders this guide — its theme and figure drive
            layout and attachment.
        """
        # The guide theme controls styling, but the owner supplies figure
        # properties. Keep the guide's targets separate from the owner's.
        self.figure = owner.figure
        self.theme = self._resolve_theme(owner)
        self.theme._inherit_figure_props(owner.theme)
        self.theme._setup(self)
        self.elements = self._elements_cls(self.theme, self)

    def setup(self, guides: guides):
        """
        Setup guide for drawing process
        """
        self._bind_source(guides.plot)
        self.guides_elements = guides.elements
        self._bind_owner(guides.plot)

    @property
    def _resolved_position_justification(
        self,
    ) -> tuple[Side, float] | tuple[tuple[float, float], tuple[float, float]]:
        """
        Return the final position & justification to draw the guide
        """
        pos = self.elements.position
        just_view = asdict(self.guides_elements.justification)
        if isinstance(pos, str):
            just = cast("float", just_view[pos])
            return (pos, just)
        else:
            # If no justification is given for an inside legend,
            # we use the position of the legend
            if (just := just_view["inside"]) is None:
                just = pos
            just = cast("tuple[float, float]", just)
            return (pos, just)

    @property
    def num_breaks(self) -> int:
        """
        Number of breaks
        """
        return len(self.key)

    def train(
        self, scale: scale, aesthetic: Optional[str] = None
    ) -> Self | None:
        """
        Create the key for the guide

        Returns guide if training is successful
        """

    def merge(self, other: Self) -> Self:
        """
        Merge with another guide
        """
        return self

    def draw(self) -> PackerBase:
        """
        Draw guide
        """
        raise NotImplementedError

    def create_geoms(self) -> Optional[Self]:
        """
        Create layers of geoms for the guide

        Returns
        -------
        :
            self if geom layers were create or None of no geom layers
            were created.
        """
        raise NotImplementedError


@dataclass
class GuideElements:
    """
    Access & calculate theming for the guide
    """

    theme: Theme
    guide: guide

    @cached_property
    def text(self) -> guide_text:
        raise NotImplementedError

    def __post_init__(self):
        self.guide_kind = type(self.guide).__name__.split("_")[-1]

    @cached_property
    def margin(self):
        return self.theme.getp("legend_margin")

    @cached_property
    def title(self):
        ha = self.theme.getp(("legend_title", "ha"))
        va = self.theme.getp(("legend_title", "va"), "center")
        _margin = self.theme.getp(("legend_title", "margin")).pt
        margin = getattr(_margin, MARGIN_SIDE[self.title_position])
        top_or_bottom = self.title_position in ("top", "bottom")
        is_blank = self.theme.T.is_blank("legend_title")

        # The original ha & va values are used by the HPacker/VPacker
        # to align the title textarea with the bundled legend keys.
        if self.is_vertical:
            align = (ha or "left") if top_or_bottom else va
        else:
            align = (ha or "center") if top_or_bottom else va

        return NS(
            margin=margin,
            align=align,
            ha="center",
            va="baseline",
            is_blank=is_blank,
        )

    @cached_property
    def text_positions(self) -> Sequence[Side]:
        raise NotImplementedError

    @cached_property
    def _text_margin(self) -> Sequence[float]:
        _margin = self.theme.getp(
            (f"legend_text_{self.guide_kind}", "margin")
        ).pt
        return [getattr(_margin, MARGIN_SIDE[p]) for p in self.text_positions]

    @cached_property
    def title_position(self) -> Side:
        if not (pos := self.theme.getp("legend_title_position")):
            pos = "top" if self.is_vertical else "left"
        return pos

    @cached_property
    def direction(self) -> Orientation:
        if self.guide.direction:
            return self.guide.direction

        if not (direction := self.theme.getp("legend_direction")):
            direction = (
                "horizontal"
                if self.position in ("bottom", "top")
                else "vertical"
            )
        return direction

    @cached_property
    def position(self) -> Side | tuple[float, float]:
        if (guide_pos := self.guide.position) == "inside":
            guide_pos = self._position_inside

        if guide_pos:
            return guide_pos

        if (pos := self.theme.getp("legend_position", "right")) == "inside":
            pos = self._position_inside
        return pos

    @cached_property
    def _position_inside(self) -> Side | tuple[float, float]:
        pos = self.theme.getp("legend_position_inside")
        if isinstance(pos, tuple):
            return pos

        just = self.theme.getp("legend_justification_inside", (0.5, 0.5))
        return ensure_xy_location(just)

    #  These do not track the themeables directly
    @cached_property
    def is_vertical(self) -> bool:
        """
        Whether the guide is vertical
        """
        return self.direction == "vertical"

    @cached_property
    def is_horizontal(self) -> bool:
        """
        Whether the guide is horizontal
        """
        return self.direction == "horizontal"
