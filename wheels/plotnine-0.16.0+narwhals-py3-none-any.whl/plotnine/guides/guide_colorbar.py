from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from functools import cached_property
from types import SimpleNamespace as NS
from typing import TYPE_CHECKING, cast
from warnings import warn

import numpy as np
from mizani.bounds import rescale

from plotnine.iapi import guide_text

from .._utils import OPPOSITE_SIDE, frame
from ..exceptions import PlotnineError, PlotnineWarning
from ..mapping.aes import rename_aesthetics
from ..scales.scale_continuous import scale_continuous
from ..themes.elements import element_line
from ..themes.theme import theme
from .guide import GuideElements, guide

if TYPE_CHECKING:
    from typing import Literal, Optional, Sequence

    from matplotlib.artist import Artist
    from matplotlib.collections import LineCollection
    from matplotlib.offsetbox import AuxTransformBox, PackerBase
    from matplotlib.text import Text

    from plotnine.guides.guides import LegendOwner
    from plotnine.scales.scale import scale
    from plotnine.typing import FloatArrayLike, Side


@dataclass
class guide_colorbar(guide):
    """
    Guide colorbar

    Notes
    -----
    To correctly place a rasterized colorbar when saving the plot as an `svg`
    or `pdf`, you should set the `dpi` to 72 i.e. `theme(dpi=72)`{.py}.
    """

    nbin: int = 300
    """
    Number of bins for drawing a colorbar. A larger value yields
    a smoother colorbar
    """

    display: Literal["gradient", "rectangles", "raster"] = "gradient"
    """
    How to render the colorbar

    SVG figures will always use "rectangles" to create gradients. This has
    better support across applications that render svg images.
    """

    alpha: Optional[float] = None
    """
    Opacity (in the range `[0, 1]`) of the colorbar. The default
    `None`, is to use the opacity of the plot.
    """

    draw_ulim: bool = True
    """Whether to show the upper limit tick marks."""

    draw_llim: bool = True
    """Whether to show the lower limit tick marks. """

    # Non-Parameter Attributes
    available_aes: set[str] = field(
        init=False, default_factory=lambda: {"colour", "color", "fill"}
    )

    elements: GuideElementsColorbar = field(  # pyright: ignore[reportIncompatibleVariableOverride]
        init=False, repr=False
    )

    @property
    def _elements_cls(self) -> type[GuideElementsColorbar]:
        return GuideElementsColorbar

    def _resolve_theme(self, owner: LegendOwner) -> theme:
        """
        Return the resolved colour-bar theme with default tick styling
        """
        resolved = super()._resolve_theme(owner)
        if resolved.T.get("legend_ticks") is None:
            resolved += theme(
                legend_ticks=element_line(color="#CCCCCC", size=1)
            )
        return resolved

    def train(self, scale: scale, aesthetic=None):
        self.title = cast("str", self.title)

        if not isinstance(scale, scale_continuous):
            warn("colorbar guide needs continuous scales", PlotnineWarning)
            return None

        if aesthetic is None:
            aesthetic = scale.aesthetics[0]

        # Do nothing if scales are inappropriate
        if set(scale.aesthetics) & self.available_aes == 0:
            warn("colorbar guide needs appropriate scales.", PlotnineWarning)
            return None

        # value = breaks (numeric) is used for determining the
        # position of ticks
        limits = scale.final_limits
        breaks = scale.get_bounded_breaks()

        if not len(breaks):
            return None

        backend = frame.default_backend()
        self.key = frame.frame(
            {
                aesthetic: scale.map(breaks),
                "label": scale.get_labels(breaks),
                "value": breaks,
            },
            backend=backend,
        )

        bar = np.linspace(limits[0], limits[1], self.nbin)
        self.bar = frame.frame(
            {"color": scale.map(bar), "value": bar}, backend=backend
        )

        labels = " ".join(str(x) for x in self.key["label"])
        info = "\n".join(
            [
                self.title,
                labels,
                " ".join(self.bar["color"].to_list()),
                self.__class__.__name__,
            ]
        )
        self.hash = hashlib.sha256(info.encode("utf-8")).hexdigest()
        return self

    def create_geoms(self):
        """
        Return self if colorbar will be drawn and None if not

        This guide is not geom based
        """
        for l in self.plot_layers:
            exclude = set()
            if isinstance(l.show_legend, dict):
                l.show_legend = rename_aesthetics(l.show_legend)
                exclude = {ae for ae, val in l.show_legend.items() if not val}
            elif l.show_legend not in (None, True):
                continue

            matched = self.legend_aesthetics(l)

            # layer uses guide
            if set(matched) - exclude:
                break
        # no break, no layer uses this guide
        else:
            return None

        return self

    def _tick_locations(self, elements: GuideElementsColorbar) -> np.ndarray:
        """Calculate tick positions along the colour bar"""
        nbars = len(self.bar)
        # A half-step offset centres ticks on segmented bars and places them
        # between the interpolation points on gradient bars.
        _from = self.bar["value"].min(), self.bar["value"].max()
        locations = (
            rescale(
                frame.to_numpy(self.key["value"]), (0.5, nbars - 0.5), _from
            )
            * elements.key_height
            / nbars
        )

        # Floating-point error can make the end ticks overlap the frame when
        # there are many bins, so snap dense tick positions to whole pixels.
        if nbars >= 150 and len(locations) >= 2:
            locations = np.asarray(
                [
                    np.floor(locations[0]),
                    *np.round(locations[1:-1]),
                    np.ceil(locations[-1]),
                ]
            )
        return np.asarray(locations)

    def _draw_bar(
        self,
        auxbox: AuxTransformBox,
        colors: Sequence[str],
        alpha: float | None,
        elements: GuideElementsColorbar,
        display: str,
        raster: bool,
    ) -> None:
        """Draw the configured continuous colour bar"""
        if display == "rectangles":
            add_segmented_colorbar(auxbox, colors, alpha, elements)
        else:
            add_gradient_colorbar(auxbox, colors, alpha, elements, raster)

    def draw(self):
        """
        Draw guide

        Returns
        -------
        out : matplotlib.offsetbox.Offsetbox
            A drawing of this legend
        """
        from matplotlib.offsetbox import (
            HPacker,
            TextArea,
            VPacker,
        )
        from matplotlib.transforms import IdentityTransform

        from .._mpl.offsetbox import DPICorAuxTransformBox

        obverse = slice(0, None)
        reverse = slice(None, None, -1)
        elements = self.elements
        format = self.theme.getp("figure_format")
        display = self.display
        if format is not None and format.lower() in {"svg", "svgz"}:
            display = "rectangles"
        raster = display == "raster"
        alpha = self.alpha

        colors = self.bar["color"].to_list()
        labels = self.key["label"].to_list()
        targets = self.theme.targets

        tick_locations = self._tick_locations(elements)

        if self.reverse:
            colors = colors[::-1]
            labels = labels[::-1]
            tick_locations = elements.key_height - tick_locations[::-1]

        auxbox = DPICorAuxTransformBox(IdentityTransform())

        # title
        title = cast("str", self.title)
        props = {"ha": elements.title.ha, "va": elements.title.va}
        title_box = TextArea(title, textprops=props)
        targets.legend_title = title_box._text  # type: ignore

        # labels
        if not self.elements.text.is_blank:
            texts = add_labels(
                auxbox, labels, tick_locations.tolist(), elements
            )
            targets.legend_text_colorbar = texts

        # colorbar
        self._draw_bar(auxbox, colors, alpha, elements, display, raster)

        # ticks
        visible = slice(
            None if self.draw_llim else 1,
            None if self.draw_ulim else -1,
        )
        coll = add_ticks(auxbox, tick_locations[visible], elements)
        targets.legend_ticks = coll

        # frame
        frame = add_frame(auxbox, elements)
        targets.legend_frame = frame

        # title + colorbar(with labels)
        lookup: dict[Side, tuple[type[PackerBase], slice]] = {
            "right": (HPacker, reverse),
            "left": (HPacker, obverse),
            "bottom": (VPacker, reverse),
            "top": (VPacker, obverse),
        }
        packer, slc = lookup[elements.title_position]

        if elements.title.is_blank:
            children: list[Artist] = [auxbox]
        else:
            children = [title_box, auxbox][slc]

        box = packer(
            children=children,
            sep=elements.title.margin,
            align=elements.title.align,
            pad=0,
        )
        return box


guide_colourbar = guide_colorbar


def add_gradient_colorbar(
    auxbox: AuxTransformBox,
    colors: Sequence[str],
    alpha: float | None,
    elements: GuideElementsColorbar,
    raster: bool = False,
):
    """
    Add an interpolated gradient colorbar to DrawingArea
    """
    from matplotlib.collections import QuadMesh
    from matplotlib.colors import ListedColormap

    # Special case that arises due to not so useful
    # aesthetic mapping.
    if len(colors) == 1:
        colors = [colors[0], colors[0]]

    # Number of horizontal edges(breaks) in the grid
    # No need to create more nbreak than colors, provided
    # no. of colors = no. of breaks = no. of cmap colors
    # the shading does a perfect interpolation
    nbreak = len(colors)

    if elements.is_vertical:
        colorbar_height = elements.key_height
        colorbar_width = elements.key_width

        mesh_width = 1
        mesh_height = nbreak - 1
        linewidth = colorbar_height / mesh_height
        # Construct rectangular meshgrid
        # The values(Z) at each vertex are just the
        # normalized (onto [0, 1]) vertical distance
        x = np.array([0, colorbar_width])
        y = np.arange(0, nbreak) * linewidth
        X, Y = np.meshgrid(x, y)
        Z = Y / y.max()
    else:
        colorbar_width = elements.key_height
        colorbar_height = elements.key_width

        mesh_width = nbreak - 1
        mesh_height = 1
        linewidth = colorbar_width / mesh_width
        x = np.arange(0, nbreak) * linewidth
        y = np.array([0, colorbar_height])
        X, Y = np.meshgrid(x, y)
        Z = X / x.max()

    # As a 3D (mesh_width x mesh_height x 2) coordinates array
    coordinates = np.stack([X, Y], axis=-1)
    cmap = ListedColormap(colors)
    coll = QuadMesh(
        coordinates,
        antialiased=False,
        shading="gouraud",
        cmap=cmap,
        array=Z.ravel(),
        alpha=alpha,
        rasterized=raster,
    )
    auxbox.add_artist(coll)


def add_segmented_colorbar(
    auxbox: AuxTransformBox,
    colors: Sequence[str],
    alpha: float | None,
    elements: GuideElementsColorbar,
    boundaries: FloatArrayLike | None = None,
):
    """
    Add 'non-rastered' colorbar to AuxTransformBox
    """
    from matplotlib.collections import PolyCollection

    nbreak = len(colors)
    # Problem:
    # 1. Webbrowsers do not properly render SVG with QuadMesh
    #    colorbars. Also when the QuadMesh is "rasterized",
    #    the colorbar is misplaced within the SVG (and pdfs!).
    #    So SVGs cannot use `add_gradient_colobar` at all.
    # 2. Webbrowsers do not properly render SVG with PolyCollection
    #    colorbars when the adjacent rectangles that make up the
    #    colorbar touch each other precisely. The "bars" appear to
    #    be separated by lines.
    #
    # For a wayout, we overlap the bars.
    # Continuous gradients overlap backwards to prevent hairline SVG gaps.
    # Explicit steps overlap forwards beneath polygons drawn later, so their
    # nominal starting edges preserve every colour segment.
    overlap_factor = 2
    boundary_values = (
        None if boundaries is None else np.asarray(boundaries, dtype=float)
    )
    if boundary_values is not None and len(boundary_values) != nbreak + 1:
        raise PlotnineError(
            "Segment boundaries must contain one more value than `colors`."
        )

    if elements.is_vertical:
        colorbar_height = elements.key_height
        colorbar_width = elements.key_width

        verts = []
        x1, x2 = 0, colorbar_width
        for i in range(nbreak):
            if boundary_values is None:
                linewidth = colorbar_height / nbreak
                y1, y2 = i * linewidth, (i + 1) * linewidth
                if i > 0:
                    y1 -= linewidth * overlap_factor
            else:
                y1, y2 = boundary_values[i : i + 2] * colorbar_height
                linewidth = y2 - y1
                if i < nbreak - 1:
                    y2 = min(y2 + linewidth * overlap_factor, colorbar_height)

            verts.append(((x1, y1), (x1, y2), (x2, y2), (x2, y1)))
    else:
        colorbar_width = elements.key_height
        colorbar_height = elements.key_width

        verts = []
        y1, y2 = 0, colorbar_height
        for i in range(nbreak):
            if boundary_values is None:
                linewidth = colorbar_width / nbreak
                x1, x2 = i * linewidth, (i + 1) * linewidth
                if i > 0:
                    x1 -= linewidth * overlap_factor
            else:
                x1, x2 = boundary_values[i : i + 2] * colorbar_width
                linewidth = x2 - x1
                if i < nbreak - 1:
                    x2 = min(x2 + linewidth * overlap_factor, colorbar_width)

            verts.append(((x1, y1), (x1, y2), (x2, y2), (x2, y1)))

    coll = PolyCollection(
        verts,
        facecolors=colors,
        linewidth=0,
        alpha=alpha,
        antialiased=False,
    )
    auxbox.add_artist(coll)


def add_ticks(auxbox, locations, elements) -> LineCollection:
    """
    Add ticks to colorbar
    """
    from matplotlib.collections import LineCollection

    segments = []
    l = elements.ticks_length
    tick_stops = np.array([0.0, l, 1 - l, 1]) * elements.key_width
    if elements.is_vertical:
        x1, x2, x3, x4 = tick_stops
        for y in locations:
            segments.extend(
                [
                    ((x1, y), (x2, y)),
                    ((x3, y), (x4, y)),
                ]
            )
    else:
        y1, y2, y3, y4 = tick_stops
        for x in locations:
            segments.extend(
                [
                    ((x, y1), (x, y2)),
                    ((x, y3), (x, y4)),
                ]
            )

    coll = LineCollection(segments)
    auxbox.add_artist(coll)
    return coll


def add_labels(
    auxbox: AuxTransformBox,
    labels: Sequence[str],
    ys: FloatArrayLike,
    elements: GuideElementsColorbar,
) -> list[Text]:
    """
    Return Texts added to the auxbox
    """
    from matplotlib.text import Text

    seps = elements.text.margins
    texts: list[Text] = []
    has = elements.text.has
    vas = elements.text.vas
    width = elements.key_width

    # The horizontal and vertical alignments are set in the theme
    # or dynamically calculates in GuideElements and added to the
    # themeable properties dict
    if elements.is_vertical:
        xs = [
            width + sep if side == "right" else -sep
            for side, sep in zip(elements.text_positions, seps)
        ]
    else:
        xs = ys
        ys = [
            -sep if side == "bottom" else width + sep
            for side, sep in zip(elements.text_positions, seps)
        ]

    for x, y, s, ha, va in zip(xs, ys, labels, has, vas):
        t = Text(x, y, s, ha=ha, va=va)
        auxbox.add_artist(t)
        texts.append(t)

    return texts


def add_frame(auxbox, elements):
    """
    Add frame to colorbar
    """
    from matplotlib.patches import Rectangle
    # from .._mpl.patches import InsideStrokedRectangle as Rectangle

    width = elements.key_width
    height = elements.key_height

    if elements.is_horizontal:
        width, height = height, width

    rect = Rectangle((0, 0), width, height, facecolor="none")
    auxbox.add_artist(rect)
    return rect


class GuideElementsColorbar(GuideElements):
    """
    Access & calculate theming for the colobar
    """

    @cached_property
    def text(self):
        size = self.theme.getp(("legend_text_colorbar", "size"))
        ha = self.theme.getp(("legend_text_colorbar", "ha"))
        va = self.theme.getp(("legend_text_colorbar", "va"))
        is_blank = self.theme.T.is_blank("legend_text_colorbar")
        n = self.guide.num_breaks

        # Default text alignment depends on the direction of the
        # colorbar
        centers = ("center",) * n
        has = (ha,) * n if isinstance(ha, str) else ha
        vas = (va,) * n if isinstance(va, str) else va
        opposite_sides = [OPPOSITE_SIDE[s] for s in self.text_positions]
        if self.is_vertical:
            has = has or opposite_sides
            vas = vas or centers
        else:
            vas = vas or opposite_sides
            has = has or centers
        return guide_text(
            self._text_margin,
            aligns=centers,
            fontsize=size,
            has=has,  # pyright: ignore[reportArgumentType]
            vas=vas,  # pyright: ignore[reportArgumentType]
            is_blank=is_blank,
        )

    @cached_property
    def text_positions(self) -> Sequence[Side]:
        if not (user_position := self.theme.getp("legend_text_position")):
            position = "right" if self.is_vertical else "bottom"
            return (position,) * self.guide.num_breaks

        alternate = {"left-right", "right-left", "bottom-top", "top-bottom"}
        if user_position in alternate:
            tup = user_position.split("-")
            return [tup[i % 2] for i in range(self.guide.num_breaks)]

        position = cast("Side | Sequence[Side]", user_position)

        if isinstance(position, str):
            position = (position,) * self.guide.num_breaks

        valid = {"right", "left"} if self.is_vertical else {"bottom", "top"}
        if any(p for p in position if p not in valid):
            raise PlotnineError(
                "The text position for a horizontal legend must be "
                f"either one of {valid!r}. I got {user_position!r}."
            )

        return position

    @cached_property
    def key_width(self):
        # We scale up the width only if it inherited its value
        dim = (self.is_vertical and "width") or "height"
        legend_key_dim = f"legend_key_{dim}"
        inherited = self.theme.T.get(legend_key_dim) is None
        scale = 1.45 if inherited else 1
        return np.round(self.theme.getp(legend_key_dim) * scale)

    @cached_property
    def key_height(self):
        # We scale up the height only if it inherited its value
        dim = (self.is_vertical and "height") or "width"
        legend_key_dim = f"legend_key_{dim}"
        inherited = self.theme.T.get(legend_key_dim) is None
        scale = (1.45 * 5) if inherited else 1
        return np.round(self.theme.getp(legend_key_dim) * scale)

    @cached_property
    def frame(self):
        lw = self.theme.getp(("legend_frame", "linewidth"), 0)
        return NS(linewidth=lw)

    @cached_property
    def ticks_length(self):
        return self.theme.getp("legend_ticks_length")

    @cached_property
    def ticks(self):
        lw = self.theme.getp(("legend_ticks", "linewidth"))
        return NS(linewidth=lw)
