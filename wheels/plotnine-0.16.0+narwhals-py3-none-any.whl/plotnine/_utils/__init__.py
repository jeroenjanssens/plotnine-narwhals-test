"""
Little functions used all over the codebase
"""

from __future__ import annotations

import inspect
import itertools
import warnings
from collections import defaultdict
from collections.abc import Iterable, Sequence
from contextlib import suppress
from copy import deepcopy
from dataclasses import field
from typing import TYPE_CHECKING, cast
from warnings import warn

import mizani._colors.utils as color_utils
import narwhals as nw
import numpy as np
from narwhals.dependencies import get_pandas

from ..exceptions import PlotnineError, PlotnineWarning
from ..mapping import aes
from . import frame
from .frame import (
    as_numpy,
    as_series,
    dtype_kind,
    is_native_series,
    native_io,
)

if TYPE_CHECKING:
    from io import BytesIO
    from pathlib import Path
    from typing import Any, Callable, Literal, TypeVar

    import numpy.typing as npt
    from typing_extensions import TypeGuard

    from plotnine._utils.frame import DataFrame
    from plotnine.typing import (
        AnyArrayLike,
        DataLike,
        FloatArray,
        FloatArrayLike,
        HorizontalJustification,
        PolarSide,
        RandomGenerator,
        RandomStateLike,
        Side,
        VerticalJustification,
    )

    T = TypeVar("T")

# Points and lines of equal size should give the
# same visual diameter (for points) and thickness
# (for lines). Given the adjustments in geom_point,
# this factor gives us the match.
SIZE_FACTOR = np.sqrt(np.pi)

# A lookup for the coordinates of specific named positions on
# a unit square.
BOX_LOCATIONS: dict[str, tuple[float, float]] = {
    "left": (0, 0.5),
    "right": (1, 0.5),
    "top": (0.5, 1),
    "bottom": (0.5, 0),
    "center": (0.5, 0.5),
    "centre": (0.5, 0.5),
}


def to_rgba(colors: Any, alpha: Any) -> Any:
    """
    Convert colors to rgba values

    Parameters
    ----------
    colors :
        Color(s) to convert. They can be in a series.
    alpha :
        Alpha value(s). They can be in a series.
    """
    # mizani expects python scalars
    if (s := as_series(colors)) is not None:
        colors = s.to_list()
    if (s := as_series(alpha)) is not None:
        alpha = s.to_list()
    elif isinstance(alpha, np.ndarray):
        alpha = alpha.tolist()
    elif isinstance(alpha, np.generic):
        alpha = alpha.item()
    return color_utils.to_rgba(colors, alpha)


def side_artists(side: Side | PolarSide) -> tuple[str, str]:
    """
    Return the (tickline, label) attribute names for one side of an axis

    `"top"`/`"right"` (and their polar counterparts `"theta_outside"`/
    `"r_end"`) use the second tick/label pair; every other side uses the
    first.
    """
    if side in ("top", "right", "theta_outside", "r_end"):
        return ("tick2line", "label2")
    return ("tick1line", "label1")


# The side opposite each axis side
OPPOSITE_SIDE: dict[Side, Side] = {
    "top": "bottom",
    "bottom": "top",
    "left": "right",
    "right": "left",
}

# The margin side that faces inward for an element on each side: for an axis
# the side facing the panel (bottom axis -> top "t", top -> "b", left -> right
# "r", right -> "l"); for a legend title/text the side facing the keys. It is
# the initial of the opposite side; cf. OPPOSITE_SIDE. Polar boundaries reuse
# the cartesian side their tick/label pair matches in side_artists: outside
# and start behave like bottom/left, inside and end like top/right.
MARGIN_SIDE: dict[Side | PolarSide, str] = {
    "bottom": "t",
    "top": "b",
    "left": "r",
    "right": "l",
    "theta_outside": "t",
    "theta_inside": "b",
    "r_start": "r",
    "r_end": "l",
}


def is_scalar(val):
    """
    Return whether the given object is a scalar

    A scalar is a single object i.e. not a collection therefore
    not iterable. Except strings are scalars.
    """
    return not isinstance(val, Iterable) or isinstance(val, str)


def is_list_like(obj: Any) -> bool:
    """
    Return True if *obj* is a list, tuple, series or array
    """
    if isinstance(obj, (list, tuple, np.ndarray, nw.Series)):
        return True
    return is_native_series(obj)


def identity(*args: Any) -> Any:
    """
    Return whatever is passed in
    """
    return args[0] if len(args) == 1 else args


def match(
    v1, v2, nomatch=-1, incomparables=None, start=0
) -> npt.NDArray[np.int64]:
    """
    Return a vector of the positions of (first)
    matches of its first argument in its second.

    Parameters
    ----------
    v1: array_like
        the values to be matched

    v2: array_like
        the values to be matched against

    nomatch: int
        the value to be returned in the case when
        no match is found.

    incomparables: array_like
        a list of values that cannot be matched.
        Any value in v1 matching a value in this list
        is assigned the nomatch value.
    start: int
        type of indexing to use. Most likely 0 or 1
    """
    # NOTE: This function gets called a lot. If it can
    # be optimised, it should.

    # Missing values (None & NaN) match each other
    lookup = {}
    for i, x in enumerate(v2):
        if x is None or x != x:
            x = _MISSING
        if x not in lookup:
            lookup[x] = i

    v1 = [_MISSING if x is None or x != x else x for x in v1]
    if incomparables:
        skip = set(incomparables) if incomparables else set()
        lst = [
            lookup[x] + start if x not in skip and x in lookup else nomatch
            for x in v1
        ]
    else:
        lst = [lookup[x] + start if x in lookup else nomatch for x in v1]
    return np.array(lst, dtype=np.int64)


# A key for the missing values
_MISSING = object()


def multitype_sort(arr: AnyArrayLike) -> list[Any]:
    """
    Sort elements of multiple types

    x is assumed to contain elements of different types, such that
    plain sort would raise a `TypeError`.

    Parameters
    ----------
    a : array_like
        Array of items to be sorted

    Returns
    -------
    out : list
        Items sorted within their type groups.
    """
    types = defaultdict(list)

    for x in arr:
        if isinstance(x, (int, float, complex)):
            types["number"].append(x)
        else:
            types[type(x)].append(x)

    for t, values in types.items():
        types[t] = sorted(values)

    return list(itertools.chain.from_iterable(types[t] for t in types))


def _margins(
    vars: tuple[Sequence[str], Sequence[str]],
    margins: bool | Sequence[str] = True,
):
    """
    Figure out margining variables.

    Given the variables that form the rows and
    columns, and a set of desired margins, works
    out which ones are possible. Variables that
    can't be margined over are dropped silently.

    Parameters
    ----------
    vars : list
        variable names for rows and columns
    margins : bool | list
        If true, margins over all vars, otherwise
        only those listed

    Return
    ------
    out : list
        All the margins to create.
    """
    if margins is False:
        return []

    def fn(_vars):
        "The margin variables for a given row or column"
        # The first item is and empty list for no margins
        dim_margins = [[]]
        # for each wanted variable, couple it with
        # all variables to the right
        for i, u in enumerate(_vars):
            if margins is True or u in margins:
                lst = [u] + list(_vars[i + 1 :])
                dim_margins.append(lst)
        return dim_margins

    # Margin variables for rows and columns
    row_margins = fn(vars[0])
    col_margins = fn(vars[1])

    # Cross the two
    lst = list(itertools.product(col_margins, row_margins))

    # Clean up -- merge the row and column variables
    pretty = []
    for c, r in lst:
        pretty.append(r + c)
    return pretty


@native_io
def add_margins(
    df: DataFrame,
    vars: tuple[Sequence[str], Sequence[str]],
    margins: bool | Sequence[str] = True,
) -> DataFrame:
    """
    Add margins to a data frame.

    All margining variables will be converted to categoricals.

    Parameters
    ----------
    df : dataframe
        input data frame

    vars : list
        a list of 2 lists | tuples vectors giving the
        variables in each dimension

    margins : bool | list
        variable names to compute margins for.
        True will compute all possible margins.
    """
    margin_vars = _margins(vars, margins)
    if not margin_vars:
        return df

    # All margin columns become categoricals. The margin indicator
    # (all) needs to be added as the last level of the categories.
    impl = df.implementation
    categories = {}
    for v in itertools.chain(*vars):
        if v not in df.columns:
            continue
        categories[v] = frame.levels(df[v])
        if "(all)" not in categories[v]:
            categories[v].append("(all)")

    df = df.with_columns(
        frame.categorical(df[v], cats, name=v, backend=impl)
        for v, cats in categories.items()
    )

    # create margin dataframes
    n = len(df)
    margin_dfs = [df]
    for vlst in margin_vars[1:]:
        dfx = df.with_columns(
            frame.categorical(
                ["(all)"] * n, categories[v], name=v, backend=impl
            )
            for v in vlst
        )
        margin_dfs.append(dfx)

    return frame.concat(margin_dfs)


@native_io
def ninteraction(df: DataFrame, drop: bool = False) -> list[int]:
    """
    Compute a unique numeric id for each unique row in
    a data frame. The ids start at 1 -- in the spirit
    of `plyr::id`

    Parameters
    ----------
    df : dataframe
        Rows
    drop : bool
        If true, drop unused categorical levels leaving no
        gaps in the assignments.

    Returns
    -------
    out : list
        Row assignments.

    Notes
    -----
    So far there has been no need not to drop unused levels
    of categorical variables.
    """
    if len(df) == 0:
        return []

    # Special case for single variable
    if len(df.columns) == 1:
        return _id_var(df[df.columns[0]], drop)

    # Calculate individual ids
    ids = [np.asarray(_id_var(df[c], drop)) for c in reversed(df.columns)]

    # Calculate dimensions
    ndistinct = np.array([len(np.unique(x)) for x in ids])
    combs = np.hstack([1, np.cumprod(ndistinct[:-1])])
    mat = np.column_stack(ids)
    res: list[int] = ((mat - 1) @ combs + 1).tolist()

    if drop:
        return _id_var(res, drop)
    else:
        return res


def _id_var(x: AnyArrayLike | nw.Series[Any], drop: bool = False) -> list[int]:
    """
    Assign ids to items in x

    If two items are the same, they get the same id.
    The ids start at 1 and, for categorical data, NaNs
    get the highest id.

    Parameters
    ----------
    x : array_like
        items to associate ids with
    drop : bool
        Whether to drop unused factor levels

    Returns
    -------
    ids:
        List of ids
    """
    if len(x) == 0:
        return []

    if is_native_series(x):
        x = nw.from_native(x, series_only=True)

    if isinstance(x, nw.Series) and frame.is_categorical(x):
        # The ids are a "re-coding" of the categorical levels
        # to meet the output requirements.
        levels = frame.levels(x)
        if drop:
            present = set(x.drop_nulls().unique().to_list())
            levels = [lvl for lvl in levels if lvl in present]
        lookup = {lvl: i for i, lvl in enumerate(levels, start=1)}

        # We want our list to start at 1. Missing values get the
        # highest id, i.e. they are ordered last.
        highest_id = len(levels) + 1
        return [lookup.get(v, highest_id) for v in x.to_list()]

    if isinstance(x, nw.Series):
        if x.dtype.is_numeric() and not frame.is_missing(x).any():
            _, inverse = np.unique(x.to_numpy(), return_inverse=True)
            return (inverse + 1).tolist()
        x = x.to_list()

    try:
        levels = sorted(set(x))
    except TypeError:
        # x probably has NANs
        levels = multitype_sort(list(set(x)))

    return list(match(x, levels, start=1))


@native_io
def join_keys(x: DataFrame, y: DataFrame, by: Sequence[str]):
    """
    Join keys.

    Given two data frames, create a unique key for each row.

    Parameters
    -----------
    x : dataframe
    y : dataframe
    by : list-like
        Column names to join by

    Returns
    -------
    out : dict
        Dictionary with keys x and y. The values of both keys
        are arrays with integer elements. Identical rows in
        x and y dataframes would have the same key in the
        output. The key elements start at 1.
    """
    by = list(by)
    joint = frame.concat([x.select(by), y.select(by)])
    keys = np.asarray(ninteraction(joint, drop=True))
    nx, ny = len(x), len(y)
    return {"x": keys[np.arange(nx)], "y": keys[nx + np.arange(ny)]}


def check_required_aesthetics(required, present, name):
    missing_aes = set(required) - set(present)

    if missing_aes:
        msg = "{} requires the following missing aesthetics: {}"
        raise PlotnineError(msg.format(name, ", ".join(missing_aes)))


@native_io
def uniquecols(data: DataFrame) -> DataFrame:
    """
    Return unique columns

    This is used for figuring out which columns are
    constant within a group
    """

    def is_unique(s: nw.Series[Any]) -> bool:
        try:
            return s.n_unique() == 1
        except Exception:
            # e.g. object columns with unhashable values
            values = s.to_list()
            return all(v == values[0] for v in values[1:])

    cols = [c for c in data.columns if is_unique(data[c])]
    return data.select(cols).head(1)


def normalise_random_state(
    random_state: RandomStateLike | None,
) -> RandomGenerator | None:
    """
    Convert an integer seed into a random number generator

    Parameters
    ----------
    random_state :
        Integer seed or random number generator. `None` remains unchanged
        so the caller can select NumPy's global random state.

    Notes
    -----
    Convert a seed once when several draws must advance the same stream.
    Preserving `None` lets callers defer access to NumPy's global random
    state without storing the unpicklable [](`numpy.random`) module in
    plot parameters.
    """
    if isinstance(random_state, int):
        return np.random.RandomState(random_state)
    return random_state


def jitter(x, factor=1, amount=None, random_state=None):
    """
    Add a small amount of noise to values in an array_like

    Parameters
    ----------
    x : array_like
        Values to apply a jitter
    factor : float
        Multiplicative value to used in automatically determining
        the `amount`. If the `amount` is given then the `factor`
        has no effect.
    amount : float
        This defines the range ([-amount, amount]) of the jitter to
        apply to the values. If `0` then `amount = factor * z/50`.
        If `None` then `amount = factor * d/5`, where d is about
        the smallest difference between `x` values and `z` is the
        range of the `x` values.
    random_state :
        Integer seed, [](`~numpy.random.RandomState`), or
        [](`numpy.random.Generator`). If `None`, draw from NumPy's global
        random state.

    References:

        - Chambers, J. M., Cleveland, W. S., Kleiner, B. and Tukey,
          P.A. (1983) *Graphical Methods for Data Analysis*. Wadsworth;
          figures 2.8, 4.22, 5.4.
    """
    if len(x) == 0:
        return x

    random_state = normalise_random_state(random_state)
    if random_state is None:
        random_state = np.random

    x = np.asarray(x)

    try:
        z = np.ptp(x[np.isfinite(x)])
    except IndexError:
        z = 0

    if z == 0:
        z = np.abs(np.min(x))
    if z == 0:
        z = 1

    if amount is None:
        _x = np.round(x, 3 - int(np.floor(np.log10(z)))).astype(int)
        xx = np.unique(np.sort(_x))
        d = np.diff(xx)
        if len(d):
            d = d.min()
        elif xx != 0:
            d = xx / 10.0
        else:
            d = z / 10
        amount = factor / 5.0 * abs(d)
    elif amount == 0:
        amount = factor * (z / 50.0)

    return x + random_state.uniform(-amount, amount, len(x))


@native_io
def remove_missing(
    data: DataFrame,
    na_rm: bool = False,
    vars: Sequence[str] | None = None,
    name: str = "",
    finite: bool = False,
) -> DataFrame:
    """
    Convenience function to remove missing values from a dataframe

    Parameters
    ----------
    df : dataframe
    na_rm : bool
        If False remove all non-complete rows with and show warning.
    vars : list-like
        columns to act on
    name : str
        Name of calling method for a more informative message
    finite : bool
        If True replace the infinite values in addition to the NaNs
    """
    n = len(data)

    if vars is None:
        vars = data.columns
    else:
        _vars = set(vars)
        vars = [c for c in data.columns if c in _vars]

    if finite:
        txt = "non-finite"
        is_ok = frame.is_finite
    else:
        txt = "missing"

        def is_ok(s):
            return ~frame.is_missing(s)

    if not n or not vars:
        return data

    keep = None
    for v in vars:
        ok = is_ok(data[v])
        keep = ok if keep is None else (keep & ok)

    if keep is not None and not keep.all():
        data = data.filter(keep)

    if len(data) < n and not na_rm:
        msg = "{} : Removed {} rows containing {} values."
        warn(
            msg.format(name, n - len(data), txt), PlotnineWarning, stacklevel=4
        )
    return data


def groupby_apply(
    df: DataFrame,
    cols: str | list[str],
    func: Callable[..., DataFrame],
    *args: Any,
    **kwargs: Any,
) -> DataFrame:
    """
    Groupby cols and call the function fn on each grouped dataframe.

    Parameters
    ----------
    cols : str | list of str
        columns to groupby
    func : callable
        function to call on the grouped data
    *args : tuple
        positional parameters to pass to func
    **kwargs : dict
        keyword parameter to pass to func
    """
    data, was_native = frame._to_nw(df)
    if not was_native:
        return frame.group_apply(data, cols, func, *args, **kwargs)

    # The function expects native dataframes
    def _func(gdf, *args, **kwargs):
        return frame.to_frame(func(gdf.to_native(), *args, **kwargs))

    return frame.group_apply(data, cols, _func, *args, **kwargs).to_native()


def make_line_segments(
    x: FloatArrayLike, y: FloatArrayLike, ispath=True
) -> FloatArray:
    """
    Return an (n x 2 x 2) array of n line segments

    Parameters
    ----------
    x : array_like
        x points
    y : array_like
        y points
    ispath : bool
        If True, the points represent a path from one point
        to the next until the last. If False, then each pair
        of successive(even-odd pair) points yields a line.
    """
    # Series objects would otherwise require .iloc
    x = np.asarray(x)
    y = np.asarray(y)
    if ispath:
        x = interleave(x[:-1], x[1:])
        y = interleave(y[:-1], y[1:])
    elif len(x) % 2:
        raise PlotnineError("Expects an even number of points")

    n = len(x) // 2
    segments = np.reshape(list(zip(x, y)), [n, 2, 2])
    return segments


def get_kwarg_names(func):
    """
    Return a list of valid kwargs to function func
    """
    sig = inspect.signature(func)
    kwonlyargs = [
        p.name for p in sig.parameters.values() if p.default is not p.empty
    ]
    return kwonlyargs


def get_valid_kwargs(func, potential_kwargs):
    """
    Return valid kwargs to function func
    """
    kwargs = {}
    for name in get_kwarg_names(func):
        with suppress(KeyError):
            kwargs[name] = potential_kwargs[name]
    return kwargs


def copy_missing_columns(df: DataFrame, ref_df: DataFrame) -> DataFrame:
    """
    Copy missing columns from ref_df to df

    If df and ref_df are the same length, the columns are
    copied in the entirety. If the length ofref_df is a
    divisor of the length of df, then the values of the
    columns from ref_df are repeated.

    Otherwise if not the same length, df gets a column
    where all elements are the same as the first element
    in ref_df

    Parameters
    ----------
    df : dataframe
        Dataframe to which columns will be added
    ref_df : dataframe
        Dataframe from which columns will be copied

    Returns
    -------
    :
        df with the added columns
    """
    cols = [c for c in ref_df.columns if c not in df.columns]
    if not cols:
        return df

    l1, l2 = len(df), len(ref_df)
    if l1 >= l2 and l1 % l2 == 0:
        idx = np.tile(range(l2), l1 // l2)
    else:
        idx = np.repeat(0, l1)

    copied = frame.convert(
        frame.take(ref_df.select(cols), idx), df.implementation
    )
    if not df.columns:
        return copied
    return nw.concat([df, copied], how="horizontal")


def data_mapping_as_kwargs(args, kwargs):
    """
    Return kwargs with the mapping and data values

    Parameters
    ----------
    args : tuple
        Arguments to [](`~plotnine.geoms.geom`) or
        [](`~plotnine.stats.stat`).
    kwargs : dict
        Keyword arguments to [](`~plotnine.geoms.geom`) or
        [](`~plotnine.stats.stat`).

    Returns
    -------
    out : dict
        kwargs that includes 'data' and 'mapping' keys.
    """
    data, mapping = order_as_data_mapping(*args)

    # check kwargs #
    if mapping is not None:
        if "mapping" in kwargs:
            raise PlotnineError("More than one mapping argument.")
        else:
            kwargs["mapping"] = mapping
    else:
        if "mapping" not in kwargs:
            mapping = aes()

    if kwargs.get("mapping", None) is None:
        kwargs["mapping"] = mapping

    if data is not None and "data" in kwargs:
        raise PlotnineError("More than one data argument.")
    elif "data" not in kwargs:
        kwargs["data"] = data

    duplicates = set(kwargs["mapping"]) & set(kwargs)
    if duplicates:
        msg = "Aesthetics {} specified two times."
        raise PlotnineError(msg.format(duplicates))
    return kwargs


def ungroup(data: DataLike) -> DataLike:
    """Return an ungrouped DataFrame, or pass the original data back."""
    _pd = get_pandas()
    if _pd is not None and isinstance(data, _pd.core.groupby.DataFrameGroupBy):
        return cast("Any", data).obj

    return data


def order_as_data_mapping(
    arg1: DataLike | aes | None,
    arg2: DataLike | aes | None,
) -> tuple[DataLike | None, aes | None]:
    """
    Reorder args to ensure (data, mapping) order

    This function allow the user to pass mapping and data
    to ggplot and geom in any order.

    Parameter
    ---------
    arg1 : DataFrame | aes
        Dataframe or aes Mapping
    arg2 : DataFrame | aes
        Dataframe or aes Mapping

    Returns
    -------
    data : DataFrame | callable
    mapping : aes
    """
    # Valid types for the values are:
    #   - None, None
    #   - Dataframe, None
    #   - None, DataFrame
    #   - aes, None
    #   - None, aes
    #   - DataFrame, aes
    data: DataLike | None = None
    mapping: aes | None = None

    for arg in [arg1, arg2]:
        if isinstance(arg, aes):
            if mapping is None:
                mapping = arg
            else:
                raise TypeError(
                    "Expected a single aesthetic mapping, found two"
                )
        elif is_data_like(arg):
            if data is None:
                data = arg
            else:
                raise TypeError("Expected a single dataframe, found two")
        elif arg is not None:
            raise TypeError(
                f"Bad type of argument {arg!r}, expected a dataframe "
                "or a mapping."
            )

    return data, mapping


# Returning a type guard here is not fully sound, because if `obj`
# is a callable, we aren't checking that it has no required args
# and we can't check the return value's type.
def is_data_like(obj: Any) -> TypeGuard[DataLike]:
    """
    Return True if obj could be data

    Parameters
    ----------
    obj : object
        Object that could be data

    Returns
    -------
    out : bool
        Whether obj could represent data as expected by
        ggplot(), geom() or stat().
    """
    if callable(obj) or frame.is_frame(obj) or hasattr(obj, "to_pandas"):
        return True
    _pd = get_pandas()
    return _pd is not None and isinstance(
        obj, _pd.core.groupby.DataFrameGroupBy
    )


def interleave(*arrays):
    """
    Interleave arrays

    All arrays/lists must be the same length

    Parameters
    ----------
    arrays : tup
        2 or more arrays to interleave

    Return
    ------
    out : np.array
        Result from interleaving the input arrays
    """
    return np.column_stack(arrays).ravel()


def resolution(x, zero=True):
    """
    Compute the resolution of a data vector

    Resolution is smallest non-zero distance between adjacent values

    Parameters
    ----------
    x : array_like
        1-Dimension
    zero : Boolean
        Whether to include zero values in the computation

    Result
    ------
    res : resolution of x
        If x is an integer array, then the resolution is 1
    """
    from mizani.bounds import zero_range

    x = as_numpy(x)

    # (unsigned) integers or an effective range of zero
    _x = (x.min(), x.max())
    if x.dtype.kind in ("i", "u") or zero_range(_x):
        return 1

    x = np.unique(x)
    if zero:
        x = np.unique(np.hstack([0, x]))

    return np.min(np.diff(np.sort(x)))


@native_io
def cross_join(df1: DataFrame, df2: DataFrame) -> DataFrame:
    """
    Return a cross between df1 & df2 if each is not empty
    """
    if len(df1) == 0:
        return df2

    if len(df2) == 0:
        return df1

    return df1.join(df2, how="cross")


def to_inches(value: float, units: str) -> float:
    """
    Convert value to inches

    Parameters
    ----------
    value : float
        Value to be converted
    units : str
        Units of value. Must be one of
        `['in', 'cm', 'mm']`.
    """
    lookup: dict[str, Callable[[float], float]] = {
        "in": lambda x: x,
        "cm": lambda x: x / 2.54,
        "mm": lambda x: x / (2.54 * 10),
    }
    try:
        return lookup[units](value)
    except KeyError as e:
        msg = f"Unknown units '{units}'"
        raise PlotnineError(msg) from e


def from_inches(value: float, units: str) -> float:
    """
    Convert value in inches to given units

    Parameters
    ----------
    value : float
        Value to be converted
    units : str
        Units to convert value to. Must be one of
        `['in', 'cm', 'mm']`.
    """
    lookup: dict[str, Callable[[float], float]] = {
        "in": lambda x: x,
        "cm": lambda x: x * 2.54,
        "mm": lambda x: x * 2.54 * 10,
    }
    try:
        return lookup[units](value)
    except KeyError as e:
        msg = f"Unknown units '{units}'"
        raise PlotnineError(msg) from e


class array_kind:
    @staticmethod
    def discrete(arr):
        """
        Return True if array is discrete

        Parameters
        ----------
        arr : numpy.array
            Must have a dtype

        Returns
        -------
        out : bool
            Whether array `arr` is discrete
        """
        return dtype_kind(arr) in "ObUS"

    @staticmethod
    def continuous(arr):
        """
        Return True if array is continuous

        Parameters
        ----------
        arr : numpy.array | series
            Must have a dtype

        Returns
        -------
        out : bool
            Whether array `arr` is continuous
        """
        return dtype_kind(arr) in "ifuc"

    @staticmethod
    def datetime(arr):
        return dtype_kind(arr) == "M"

    @staticmethod
    def timedelta(arr):
        return dtype_kind(arr) == "m"

    @staticmethod
    def ordinal(arr):
        """
        Return True if array is an ordered categorical

        Parameters
        ----------
        arr : series
            Must have a dtype

        Returns
        -------
        out : bool
            Whether array `arr` is an ordered categorical
        """
        s = as_series(arr)
        return s is not None and frame.is_ordinal(s)

    @staticmethod
    def categorical(arr):
        """
        Return True if array is a categorical

        Parameters
        ----------
        arr : list-like
            List

        Returns
        -------
        bool
            Whether array `arr` is a categorical
        """
        s = as_series(arr)
        return s is not None and frame.is_categorical(s)


def log(x, base=None):
    """
    Calculate the log

    Parameters
    ----------
    x : float | array_like
        Input values
    base : int | float, default=None
        Base of the log. If `None`, the natural logarithm
        is computed (`base=np.e`).

    Returns
    -------
    out : float | ndarray
        Calculated result
    """
    if base == 10:
        return np.log10(x)
    elif base == 2:
        return np.log2(x)
    elif base is None or base == np.e:
        return np.log(x)
    else:
        return np.log(x) / np.log(base)


class ignore_warnings:
    """
    Ignore Warnings Context Manager

    Wrap around warnings.catch_warnings to make ignoring
    warnings easier.

    Parameters
    ----------
    *categories : tuple
        Warning categories to ignore e.g UserWarning,
        FutureWarning, RuntimeWarning, ...
    """

    _cm: warnings.catch_warnings

    def __init__(self, *categories):
        self.categories = categories
        self._cm = warnings.catch_warnings()

    def __enter__(self):
        self._cm.__enter__()
        for c in self.categories:
            warnings.filterwarnings("ignore", category=c)

    def __exit__(self, type, value, traceback):
        return self._cm.__exit__(type, value, traceback)


def simple_table(
    rows: list[tuple[str, str]], headers: tuple[str, str], **kwargs
):
    """
    Generate a simple markdown table

    The header is center aligned
    The cells is left aligned
    """
    # +2 reserves some margins for aligning
    column_width = [len(s) + 2 for s in headers]
    for row in rows:
        for i, cell in enumerate(row):
            column_width[i] = max(column_width[i], len(cell))

    sep = "  "
    underline = sep.join("-" * w for w in column_width)
    formatting_spec = sep.join(
        f"{{{i}: <{w}}}" for i, w in enumerate(column_width)
    )
    format_row = formatting_spec.format
    format_header = formatting_spec.replace("<", "^").format

    _rows = [
        format_header(*headers),  # C1 C2 C3
        underline,  # --- --- ---
        *[format_row(*row) for row in rows],  # Ri1 Ri2 Ri3
    ]
    return "\n".join(_rows)


def no_init(default: T) -> T:
    """
    Set default value of a dataclass field that will not be __init__ed
    """
    return field(init=False, default=default)


def no_init_mutable(default: T) -> T:
    """
    Set default value of a dataclass field that will not be __init__ed
    """
    return field(init=False, default_factory=lambda: deepcopy(default))


def default_field(default: T) -> T:
    """
    Set default value of a dataclass field using a factory
    """
    return field(default_factory=lambda: deepcopy(default))


def ensure_xy_location(
    loc: Side | Literal["center"] | float | tuple[float, float],
) -> tuple[float, float]:
    """
    Convert input into (x, y) location

    Parameters
    ----------
    loc:
        A specification for a location that can be converted to
        coordinate points on a unit-square. Note that, if the location
        is (x, y) points, the same points are returned.
    """
    if loc in BOX_LOCATIONS:
        return BOX_LOCATIONS[loc]
    elif isinstance(loc, (float, int)):
        return (loc, 0.5)
    elif isinstance(loc, tuple):
        h, v = loc
        if isinstance(h, str) and isinstance(v, str):
            return BOX_LOCATIONS[h][0], BOX_LOCATIONS[v][1]
        if isinstance(h, (int, float)) and isinstance(v, (int, float)):
            return (h, v)
    raise ValueError(f"Cannot make a location from '{loc}'")


def ha_as_float(ha: HorizontalJustification | float) -> float:
    """
    Return horizontal alignment as a float
    """
    lookup = {"left": 0.0, "center": 0.5, "right": 1.0}
    return lookup[ha] if isinstance(ha, str) else ha


def va_as_float(va: VerticalJustification | float) -> float:
    """
    Return vertical alignment as a float
    """
    lookup = {
        "top": 1.0,
        "center": 0.5,
        "bottom": 0.0,
        # baseline and center_baseline are valid for texts but we do
        # not handle them accurately
        "baseline": 0.5,
        "center_baseline": 0.5,
    }
    return lookup[va] if isinstance(va, str) else va


def has_alpha_channel(c: str | tuple) -> bool:
    """
    Return True if c a color with an alpha value

    Either a 9 character hex string e.g. #AABBCC88 or
    an RGBA tuple e.g. (.6, .7, .8, .5)
    """
    if isinstance(c, str):
        return c.startswith("#") and len(c) == 9
    else:
        return color_utils.is_color_tuple(c) and len(c) == 4


def nextafter_range(rng: tuple[float, float]) -> tuple[float, float]:
    """
    Expand floating-point range by a step to adjacent representable numbers

    Parameters
    ----------
    rng :
        A tuple (min, max) representing the range to expand.

    Returns
    -------
    :
        A new tuple (lower, upper) where,
        - lower is moved 1 float toward -∞
        - upper is moved 1 float toward +∞
    """
    from math import inf, nextafter

    return (nextafter(rng[0], -inf), nextafter(rng[1], inf))


def get_save_format(
    filename: str | Path | BytesIO | None,
    format: str | None,
    *,
    default: str | None,
) -> str | None:
    """
    Resolve the output format for a saved figure

    An explicit format takes priority over the filename suffix and the
    default. A `.png` suffix retains a `retina` default.
    """
    from pathlib import Path

    if format is None and isinstance(filename, (str, Path)):
        format = Path(filename).suffix.lstrip(".").lower() or None
        if format == "png" and (default or "").lower() == "retina":
            format = "retina"
    format = format if format is not None else default
    if format is None:
        return None
    format = format.lower()
    return "jpeg" if format == "jpg" else format
