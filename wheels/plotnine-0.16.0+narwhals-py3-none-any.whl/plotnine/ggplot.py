from __future__ import annotations

from collections.abc import Sequence
from copy import copy, deepcopy
from dataclasses import dataclass
from io import BytesIO
from itertools import chain
from pathlib import Path
from types import SimpleNamespace as NS
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Iterable,
    Optional,
    cast,
    overload,
)
from warnings import warn

from ._utils import (
    frame,
    from_inches,
    get_save_format,
    is_data_like,
    order_as_data_mapping,
    to_inches,
    ungroup,
)
from ._utils.context import assign_figure, plot_context
from ._utils.frame import nominal_enums_scope
from ._utils.ipython import (
    get_ipython,
    get_mimebundle,
    is_inline_backend,
)
from ._utils.quarto import is_knitr_engine, is_quarto_environment
from .coords import coord_cartesian
from .exceptions import PlotnineError, PlotnineWarning
from .facets import facet_null
from .facets.layout import Layout
from .geoms.geom_blank import geom_blank
from .guides.guides import guides
from .iapi import labels_view, mpl_save_view
from .layer import Layers, layer
from .mapping.aes import aes
from .options import get_option
from .scales.scales import Scales
from .themes.theme import theme, theme_get

if TYPE_CHECKING:
    from typing import Protocol

    from matplotlib.axes import Axes
    from matplotlib.figure import Figure
    from typing_extensions import Self

    from plotnine import watermark
    from plotnine._mpl.figure import p9Figure
    from plotnine._mpl.gridspec import p9GridSpec
    from plotnine._mpl.layout_manager._plot_side_space import PlotSideSpaces
    from plotnine.composition import Compose
    from plotnine.coords.coord import coord
    from plotnine.facets.facet import facet
    from plotnine.typing import DataLike, FigureFormat, MimeBundle

    class PlotAddable(Protocol):
        """
        Object that can be added to a ggplot object
        """

        def __radd__(self, other: ggplot) -> ggplot:
            """
            Add to ggplot object

            Parameters
            ----------
            other :
                ggplot object

            Returns
            -------
            :
                ggplot object
            """
            ...


__all__ = ("ggplot", "ggsave", "save_as_pdf_pages")


class ggplot:
    """
    Create a new ggplot object

    Parameters
    ----------
    data :
        Default data for plot. Every layer that does not
        have data of its own will use this one.
    mapping :
        Default aesthetics mapping for the plot. These will be used
        by all layers unless specifically overridden.

    Notes
    -----
    ggplot object only have partial support for pickling. The mappings used
    by pickled objects should not reference variables in the namespace.
    """

    figure: p9Figure
    axs: list[Axes]
    _gridspec: p9GridSpec
    """
    Gridspec (1x1) that contains the whole plot
    """

    _sub_gridspec: p9GridSpec
    """
    Gridspec (nxn) that contains the facet panels

     -------------------------
    |  title                  |<----- ._gridspec
    |  subtitle               |
    |                         |
    |   -------------         |
    |  |      |      |<-------+------ ._sub_gridspec
    |  |      |      |        |
    |  |      |      | legend |
    |   -------------         |
    |   axis_ticks            |
    |   axis_text             |
    |   axis_title            |
    |                 caption |
    |-------------------------|
    |          footer         |
     -------------------------
    """

    _sidespaces: PlotSideSpaces

    built: PlotBuild
    """
    Most recent build result, unset until the first draw
    """

    def __init__(
        self,
        data: Optional[DataLike] = None,
        mapping: Optional[aes] = None,
    ):
        from .composition._inset_element import Insets
        from .mapping._env import Environment

        # Allow some sloppiness
        data, mapping = order_as_data_mapping(data, mapping)
        self.data = data
        self.mapping = mapping if mapping is not None else aes()
        self.facet: facet = facet_null()
        self.labels = labels_view()
        self.layers = Layers()
        self.guides = guides()
        self.guides._owner = self
        self.scales = Scales()
        self.theme = theme_get()
        self.coordinates: coord = coord_cartesian()
        self.environment = Environment.capture(1)
        self.layout = Layout()
        self.watermarks: list[watermark] = []
        self._insets: Insets = Insets()

    def __str__(self) -> str:
        """
        Return a wrapped display size (in pixels) of the plot
        """
        w, h = self.theme._figure_size_px
        return f"<ggplot: ({w} x {h})>"

    def __repr__(self):
        # knitr relies on __repr__ to automatically print the last object
        # in a cell.
        if is_knitr_engine():
            self.show()
            return ""
        return super().__repr__()

    def _repr_mimebundle_(self, include=None, exclude=None) -> MimeBundle:
        """
        Return dynamic MIME bundle for plot display

        This method is called when a ggplot object is the last in the cell.

        Notes
        -----
        - https://ipython.readthedocs.io/en/stable/config/integrating.html
        """
        ip = get_ipython()
        format: FigureFormat = (
            self.theme.getp("figure_format")
            or get_option("figure_format")
            or (ip and ip.config.InlineBackend.get("figure_format"))
            or "retina"
        )
        format = cast("FigureFormat", format.lower())
        if format == "jpg":
            format = "jpeg"

        # While jpegs can be displayed as retina, we restrict the output
        # of "retina" to png
        if format == "retina":
            self = copy(self)
            self.theme = self.theme.to_retina()

        buf = BytesIO()
        self.save(buf, "png" if format == "retina" else format, verbose=False)
        figure_size_px = self.theme._figure_size_px
        return get_mimebundle(buf.getvalue(), format, figure_size_px)

    def show(self):
        """
        Show plot using the matplotlib backend set by the user

        This function is called for its side-effects.
        """
        # Prevent against any modifications to the users
        # ggplot object. Do the copy here as we may/may not
        # assign a default theme
        self = deepcopy(self)

        if is_inline_backend() or is_quarto_environment():
            from IPython.display import display

            data, metadata = self._repr_mimebundle_()
            display(data, metadata=metadata, raw=True)
        else:
            self.draw(show=True)

    def __deepcopy__(self, memo: dict[Any, Any]) -> Self:
        """
        Deep copy without copying the dataframe and environment
        """
        cls = self.__class__
        result = cls.__new__(cls)
        memo[id(self)] = result
        old = self.__dict__
        new = result.__dict__

        skip = {
            "figure",
            "_gridspec",
            "_sub_gridspec",
            "axs",
            # A copied plot has no build result, even when its source does.
            "built",
        }
        for key, item in old.items():
            if key in skip:
                continue

            # Share data and the build-result scaffold with the copy.
            if key in ("data", "_build_objs"):
                new[key] = item
                memo[id(new[key])] = new[key]
            else:
                new[key] = deepcopy(item, memo)

        return result

    def __iadd__(self, other: PlotAddable | list[PlotAddable] | None) -> Self:
        """
        Add other to ggplot object

        Parameters
        ----------
        other :
            Either an object that knows how to "radd"
            itself to a ggplot, or a list of such objects.
        """
        if isinstance(other, Sequence):
            for item in other:
                item.__radd__(self)
        elif other is not None:
            other.__radd__(self)
        return self

    @overload
    def __add__(
        self,
        rhs: PlotAddable | list[PlotAddable] | None,
    ) -> Self: ...

    @overload
    def __add__(self, rhs: Self) -> Compose: ...

    def __add__(
        self,
        rhs: PlotAddable | list[PlotAddable] | None | Self,
    ) -> Self | Compose:
        """
        Add to ggplot

        Parameters
        ----------
        rhs :
            Either an object that knows how to "radd"
            itself to a ggplot, or a list of such objects.
        """
        from .composition import Compose

        self = deepcopy(self)

        if isinstance(rhs, (ggplot, Compose)):
            from .composition import Wrap

            return Wrap([self, rhs])

        return self.__iadd__(rhs)

    def __or__(self, rhs: Self | Compose) -> Compose:
        """
        Compose 2 plots columnwise
        """
        from .composition import Beside

        return Beside([self, rhs])

    def __truediv__(self, rhs: Self | Compose) -> Compose:
        """
        Compose 2 plots rowwise
        """
        from .composition import Stack

        return Stack([self, rhs])

    def __and__(self, rhs: PlotAddable) -> Self:
        """
        Broadcast rhs to this plot and every inset

        Only defined when the plot has insets. On a plot with no insets
        use `+` instead.
        """
        if not self._insets:
            return NotImplemented

        new = deepcopy(self)
        new += rhs
        new._insets = new._insets & rhs
        return new

    def __mul__(self, rhs: PlotAddable) -> Self:
        """
        Apply rhs to this plot only, leaving insets untouched

        Only defined when the plot has insets. On a plot with no insets
        use `+` instead.
        """
        if not self._insets:
            return NotImplemented

        new = deepcopy(self)
        new += rhs
        return new

    def __sub__(self, rhs: Self | Compose) -> Compose:
        """
        Compose 2 plots columnwise
        """
        from .composition import Beside

        return Beside([self, rhs])

    def __rrshift__(self, other: DataLike) -> Self:
        """
        Overload the >> operator to receive a dataframe
        """
        other = ungroup(other)
        if is_data_like(other):
            if self.data is None:
                self.data = other
            else:
                raise PlotnineError("`>>` failed, ggplot object has data.")
        else:
            msg = "Unknown type of data -- {!r}"
            raise TypeError(msg.format(type(other)))
        return self

    def draw(self, *, show: bool = False) -> Figure:
        """
        Render the complete plot

        Parameters
        ----------
        show :
            Whether to show the plot.

        Returns
        -------
        :
            Matplotlib figure
        """
        with plot_context(self, show=show):
            figure = self._setup()
            self._build()

            # setup
            self.coordinates._setup(self)
            self.guides._setup(self)
            self.theme._setup(self)

            # Drawing (order matters)
            self._draw_plot_background()
            self._insets.draw(which="below")

            self._sub_gridspec, self.axs = self.built.facet.setup(self)
            self._draw_layers()
            self._draw_panel_borders()
            self._draw_breaks_and_labels()
            self.guides.draw()
            self._draw_figure_texts()
            self._draw_watermarks()

            # Artist object theming
            self.theme.apply()

            self._insets.draw(which="above")

        return figure

    def _setup(self) -> Figure:
        """
        Setup this instance for the building process
        """
        self._create_figure()
        self._insets._setup(self)
        self.labels.add_defaults(self.mapping.labels)
        return self.figure

    def _create_figure(self):
        """
        Create or reuse the plot's figure and gridspec

        Reuse a figure supplied by a parent composition or host inset, adding
        any missing gridspec. When this plot owns the current figure, replace
        it with a fresh figure and close the previous one.
        """
        import matplotlib.pyplot as plt

        if not hasattr(self, "figure") or self.figure._owner is self:
            from ._mpl.figure import p9Figure
            from ._mpl.gridspec import p9GridSpec

            figure = cast(
                "p9Figure", plt.figure(FigureClass=p9Figure, owner=self)
            )
            assign_figure(self, figure, p9GridSpec(1, 1, figure))
        elif not hasattr(self, "_gridspec"):
            from ._mpl.gridspec import p9GridSpec

            self._gridspec = p9GridSpec(1, 1, self.figure)

    def build(self) -> PlotBuild:
        """
        Build the plot's layers, scales, layout, facet and labels

        Returns
        -------
        :
            The built layers, scales, layout, facet and labels.

        Notes
        -----
        The result contains independent copies of `layers`, `scales`,
        `layout`, `facet` and `labels`, so building does not modify those
        plot attributes. Layer mappings and statistics can add labels, while
        facets can record state such as panel-grid dimensions. These changes
        remain on the build's copies.
        """
        with nominal_enums_scope():
            return self._build_in_scope()

    def _build_in_scope(self) -> PlotBuild:
        """
        Build the plot (see `build`)
        """
        plot = deepcopy(self)
        layers, scales, layout, facet, labels = (
            plot.layers,
            plot.scales,
            plot.layout,
            plot.facet,
            plot.labels,
        )
        if not layers:
            layers.append(layer(geom=geom_blank()))

        # Keep labels derived from layers on the build result.
        layers.update_labels(labels)

        # Give each layer a copy of the data, the mappings and
        # the execution environment
        layers.setup(plot)

        # Initialise panels, add extra data for margins & missing
        # facetting variables, and add on a PANEL variable to data
        layout.setup(layers, plot)

        # Compute aesthetics to produce data with generalised
        # variable names
        layers.compute_aesthetics(plot)

        # Transform data using all scales
        layers.transform(scales)

        # Make sure missing (but required) aesthetics are added
        scales.add_missing(("x", "y"))

        # Map and train positions so that statistics have access
        # to ranges and all positions are numeric
        layout.train_position(layers, scales)
        layout.map_position(layers)

        # Apply and map statistics
        layers.compute_statistic(layout)
        layers.map_statistic(plot)

        # Prepare data in geoms
        # e.g. from y and width to ymin and ymax
        layers.setup_data()

        # Apply position adjustments
        layers.compute_position(layout)

        # Reset position scales, then re-train and map.  This
        # ensures that facets have control over the range of
        # a plot.
        layout.reset_position_scales()
        layout.train_position(layers, scales)
        layout.map_position(layers)

        # Train and map non-position scales
        npscales = scales.non_position_scales()
        if len(npscales):
            layers.train(npscales)
            layers.map(npscales)

        # Train coordinate system
        layout.setup_panel_params(self.coordinates)

        # fill in the defaults
        layers.use_defaults_after_scale(scales)

        # Resolve panel fractions after the ranges for every panel are known.
        layers.resolve_asis_positions(layout, self.coordinates)

        # Allow stats to modify the layer data
        layers.finish_statistics()

        # Allow layout to modify data before rendering
        layout.finish_data(layers)

        return PlotBuild(layers, scales, layout, facet, labels)

    def _build(self):
        """
        Build the plot and attach the result

        Notes
        -----
        Unlike `build()`, this method stores the result on the plot. It also
        refreshes the deprecated build-object alias.
        """
        self.built = self.build()
        # Preserve the deprecated build-object alias for extensions that
        # still depend on it.
        self._build_objs = NS(
            layers=self.built.layers,
            scales=self.built.scales,
            layout=self.built.layout,
        )

    def _draw_panel_borders(self):
        """
        Draw Panel boders
        """
        # We add a patch rather than use ax.patch because want the
        # grid lines below the borders. We leave ax.patch for the
        # background only.
        if self.theme.T.is_blank("panel_border"):
            return

        from matplotlib.patches import Rectangle

        for ax in self.axs:
            rect = Rectangle(
                (0, 0),
                1,
                1,
                facecolor="none",
                transform=ax.transAxes,
                # Adding a clip path but defaulting to no clipping
                # gives a fullwidth border that can perfectly overlap
                # will with legend borders.
                clip_path=ax.patch,
                clip_on=False,
            )
            self.figure.add_artist(rect)
            self.theme.targets.panel_border.append(rect)

    def _draw_layers(self):
        """
        Draw the main plot(s) onto the axes.
        """
        # Draw the geoms
        self.built.layers.draw(self.built.layout, self.coordinates)
        self.coordinates.draw(self.axs)

    def _draw_breaks_and_labels(self):
        """
        Draw breaks and labels
        """
        # 1. Draw facet labels a.k.a strip text
        # 2. Decorate the axes
        #      - xaxis & yaxis breaks, labels, limits, ...
        #
        # pidx is the panel index (location left to right, top to bottom)
        self.built.facet.strips.draw()
        for layout_info in self.built.layout.get_details():
            pidx = layout_info.panel_index
            ax = self.axs[pidx]
            panel_params = self.built.layout.panel_params[pidx]
            self.coordinates.setup_ax(ax, panel_params, layout_info)

    def _draw_figure_texts(self):
        """
        Draw title, x label, y label and caption onto the figure
        """
        from matplotlib.text import Text

        targets = self.theme.targets

        # The locations are handled by the layout manager
        if title := self.labels.get("title", ""):
            targets.plot_title = self.figure.add_artist(Text(text=title))

        if subtitle := self.labels.get("subtitle", ""):
            targets.plot_subtitle = self.figure.add_artist(Text(text=subtitle))

        if caption := self.labels.get("caption", ""):
            targets.plot_caption = self.figure.add_artist(Text(text=caption))

        if footer := self.labels.get("footer", ""):
            targets.plot_footer = self.figure.add_artist(Text(text=footer))

        if tag := self.labels.get("tag", ""):
            targets.plot_tag = self.figure.add_artist(Text(text=tag))

        # Get the axis labels (default or specified by user)
        # and let the coordinate modify them e.g. flip
        labels = self.coordinates.labels(
            self.built.layout.set_xy_labels(copy(self.built.labels))
        )

        # The axis title is registered under a per-side target named for
        # its axis position.
        pp = self.built.layout.panel_params[0]
        if labels.x:
            t = self.figure.add_artist(Text(text=labels.x))
            setattr(targets, f"axis_title_x_{pp.x.position}", t)

        if labels.y:
            t = self.figure.add_artist(Text(text=labels.y))
            setattr(targets, f"axis_title_y_{pp.y.position}", t)

        # The secondary axis title sits on the opposite side; a None
        # name derives the primary title.
        if (sec := pp.x.sec) is not None:
            name = labels.x if sec.name is None else sec.name
            if name:
                t = self.figure.add_artist(Text(text=name))
                setattr(targets, f"axis_title_x_{sec.position}", t)

        if (sec := pp.y.sec) is not None:
            name = labels.y if sec.name is None else sec.name
            if name:
                t = self.figure.add_artist(Text(text=name))
                setattr(targets, f"axis_title_y_{sec.position}", t)

    def _draw_watermarks(self):
        """
        Draw watermark onto figure
        """
        for wm in self.watermarks:
            wm.draw(self.figure)

    def _draw_plot_background(self):
        from matplotlib.lines import Line2D
        from matplotlib.patches import Rectangle

        targets = self.theme.targets

        targets.plot_background = self.figure.add_artist(
            Rectangle((0, 0), 0, 0, facecolor="none")
        )
        self._gridspec.patch = targets.plot_background

        # Footer background and line only if there is a footer.
        if self.labels.get("footer", ""):
            targets.plot_footer_background = self.figure.add_artist(
                Rectangle((0, 0), 0, 0, facecolor="none", linewidth=0)
            )
            targets.plot_footer_line = self.figure.add_artist(
                Line2D([0, 0], [0, 0], color="none", linewidth=0)
            )

    def _save_filename(self, ext: str) -> Path:
        """
        Make a filename for use by the save method

        Parameters
        ----------
        ext : str
            Extension e.g. png, pdf, ...
        """
        hash_token = abs(self.__hash__())
        return Path(f"plotnine-save-{hash_token}.{ext}")

    def save_helper(
        self: ggplot,
        filename: Optional[str | Path | BytesIO] = None,
        format: Optional[str] = None,
        path: Optional[str] = None,
        width: Optional[float] = None,
        height: Optional[float] = None,
        units: str = "in",
        dpi: Optional[float] = None,
        limitsize: bool | None = None,
        verbose: bool = True,
        **kwargs: Any,
    ) -> mpl_save_view:
        """
        Create MPL figure that will be saved

        Notes
        -----
        This method has the same arguments as [](`~plotnine.ggplot.save`).
        Use it to get access to the figure that will be saved.
        """
        append_extension = (
            format is None
            and isinstance(filename, (str, Path))
            and not Path(filename).suffix.lstrip(".")
        )
        format = get_save_format(
            filename, format, default=self.theme.getp("figure_format")
        )
        retina = format == "retina"
        if retina:
            format = "png"

        if limitsize is None:
            limitsize = cast("bool", get_option("limitsize"))

        # filename, depends on the object
        if filename is None:
            format = format or "pdf"
            filename = self._save_filename(format)
        elif append_extension and format is not None:
            filename = f"{str(filename).rstrip('.')}.{format}"

        if path and isinstance(filename, (Path, str)):
            filename = Path(path) / filename

        fig_kwargs: Dict[str, Any] = {"format": format, **kwargs}
        fig_kwargs["fname"] = filename

        # Preserve the users object
        self = deepcopy(self)

        # The figure size should be known by the theme
        if width is not None and height is not None:
            width = to_inches(width, units)
            height = to_inches(height, units)
            self += theme(figure_size=(width, height))
        elif (width is None and height is not None) or (
            width is not None and height is None
        ):
            raise PlotnineError("You must specify both width and height")
        else:
            width, height = cast(
                "tuple[float, float]", self.theme.getp("figure_size")
            )

        if limitsize and (width > 25 or height > 25):
            raise PlotnineError(
                f"Dimensions ({width=}, {height=}) exceed 25 inches "
                "(height and width are specified in inches/cm/mm, "
                "not pixels). If you are sure you want these "
                "dimensions, use 'limitsize=False'."
            )

        if verbose:
            _w = from_inches(width, units)
            _h = from_inches(height, units)
            warn(f"Saving {_w} x {_h} {units} image.", PlotnineWarning)
            warn(f"Filename: {filename}", PlotnineWarning)

        if dpi is not None:
            self.theme = self.theme + theme(dpi=dpi)

        if retina:
            self.theme = self.theme.to_retina()
        self.theme = self.theme + theme(figure_format=format)
        figure = self.draw(show=False)
        return mpl_save_view(figure, fig_kwargs)

    def save(
        self,
        filename: Optional[str | Path | BytesIO] = None,
        format: Optional[str] = None,
        path: str = "",
        width: Optional[float] = None,
        height: Optional[float] = None,
        units: str = "in",
        dpi: Optional[int] = None,
        limitsize: bool | None = None,
        verbose: bool = True,
        **kwargs: Any,
    ):
        """
        Save a ggplot object as an image file

        Parameters
        ----------
        filename :
            File name to write the plot to. If not specified, a name
            like “plotnine-save-<hash>.<format>” is used.
        format :
            Output format. An explicit value takes priority over the filename
            extension and the theme's `figure_format`. Without a filename or
            preference, use PDF; otherwise use Matplotlib's default. The
            `retina` format saves a PNG at twice the requested DPI. A `.png`
            extension retains a `retina` theme preference; pass
            `format="png"` for ordinary resolution.
        path :
            Path to save plot to (if you just want to set path and
            not filename).
        width :
            Width (defaults to value set by the theme). If specified
            the `height` must also be given.
        height :
            Height (defaults to value set by the theme). If specified
            the `width` must also be given.
        units :
            Units for width and height when either one is explicitly
            specified (in, cm, or mm).
        dpi :
            DPI to use for raster graphics. If None, defaults to using
            the `dpi` of theme, if none is set then a `dpi` of 100.
        limitsize :
            If `True` (the default), save will not save images
            larger than 25x25 inches, to prevent the common error
            of specifying dimensions in pixels. The default value
            is from the option `plotine.options.limitsize`.
        verbose :
            If `True`, print the saving information.
        kwargs :
            Additional arguments to pass to matplotlib `savefig()`.
        """
        sv = self.save_helper(
            filename=filename,
            format=format,
            path=path,
            width=width,
            height=height,
            units=units,
            dpi=dpi,
            limitsize=limitsize,
            verbose=verbose,
            **kwargs,
        )

        with plot_context(self).rc_context:
            sv.figure.savefig(**sv.kwargs)

    def layer_data(self, i: int = 0) -> Any:
        """
        Return the data used to draw a specific plot layer

        Parameters
        ----------
        i :
            Index of the layer to retrieve, starting from 0.

        Returns
        -------
        :
            Data used by the specified layer after all transformations,
            statistics, and position adjustments have been applied.
            It is a dataframe of the same library (e.g. pandas or
            polars) as the data of the layer.
        """
        return frame.to_frame(self.build().layers[i].data).to_native()


ggsave = ggplot.save


@dataclass(frozen=True)
class PlotBuild:
    """
    A plot's computed layers, scales, layout, facet and labels

    Parameters
    ----------
    layers :
        Layers with computed aesthetics, statistics and position
        adjustments applied.
    scales :
        Scales trained on the built layer data.
    layout :
        Panel layout with panel parameters resolved.
    facet :
        Facet state computed for this build. This is the same object as
        `layout.facet`.
    labels :
        Labels with each layer's own mapping and statistic defaults
        filled in.
    """

    layers: Layers
    scales: Scales
    layout: Layout
    facet: facet
    labels: labels_view


def save_as_pdf_pages(
    plots: Iterable[ggplot],
    filename: Optional[str | Path] = None,
    path: str | None = None,
    verbose: bool = True,
    **kwargs: Any,
):
    """
    Save multiple [](`~plotnine.ggplot`) objects to a PDF file, one per page.

    Parameters
    ----------
    plots :
        Plot objects to write to file. `plots` may be either a
        collection such as a [](:class:`list`) or [](:class:`set`)

        ```python
        base_plot = ggplot(…)
        plots = [base_plot + ggtitle('%d of 3' % i) for i in range(1, 3)]
        save_as_pdf_pages(plots)
        ```

        or, a generator that yields [](`~plotnine.ggplot`) objects:

        ```python
        def myplots():
            for i in range(1, 3):
                yield ggplot(…) + ggtitle('%d of 3' % i)
        save_as_pdf_pages(myplots())
        ```
    filename :
        File name to write the plot to. If not specified, a name
        like “plotnine-save-<hash>.pdf” is used.
    path :
        Path to save plot to (if you just want to set path and
        not filename).
    verbose :
        If `True`, print the saving information.
    kwargs :
        Additional arguments to pass to
        [](:meth:`~matplotlib.figure.Figure.savefig`).

    Notes
    -----
    Using pandas [](:meth:`~pandas.DataFrame.groupby`) methods, tidy data
    can be "faceted" across pages:

    ```python
    from plotnine.data import mtcars

    def facet_pages(column)
        base_plot = [
            aes(x="wt", y="mpg", label="name"),
            geom_text(),
        ]
        for label, group_data in mtcars.groupby(column):
            yield ggplot(group_data) + base_plot + ggtitle(label)

    save_as_pdf_pages(facet_pages('cyl'))
    ```

    Unlike [](:meth:`~plotnine.ggplot.save`),
    [](:meth:`~plotnine.save_as_pdf_pages`)
    does not process arguments for `height` or `width`. To set the figure
    size, add [](`~plotnine.themes.themeable.figure_size`) to the theme
    for some or all of the objects in `plots`:

    ```python
    plot = ggplot(…)
    # The following are equivalent
    plot.save('filename.pdf', height=6, width=8)
    save_as_pdf_pages([plot + theme(figure_size=(8, 6))])
    ```
    """
    from matplotlib.backends.backend_pdf import PdfPages

    # as in ggplot.save()
    fig_kwargs = {"bbox_inches": "tight"}
    fig_kwargs.update(kwargs)

    # If plots is already an iterator, this is a no-op; otherwise
    # convert a list, etc. to an iterator
    plots = iter(plots)

    # filename, depends on the object
    if filename is None:
        # Take the first element from the iterator, store it, and
        # use it to generate a file name
        peek = [next(plots)]
        plots = chain(peek, plots)
        filename = peek[0]._save_filename("pdf")

    if path:
        filename = Path(path) / filename

    if verbose:
        warn(f"Filename: {filename}", PlotnineWarning)

    with PdfPages(filename) as pdf:
        # Re-add the first element to the iterator, if it was removed
        for plot in plots:
            plot = deepcopy(plot)
            plot.theme = plot.theme + theme(figure_format="pdf")
            fig = plot.draw()
            with plot_context(plot).rc_context:
                # Save as a page in the PDF file
                pdf.savefig(fig, **fig_kwargs)
