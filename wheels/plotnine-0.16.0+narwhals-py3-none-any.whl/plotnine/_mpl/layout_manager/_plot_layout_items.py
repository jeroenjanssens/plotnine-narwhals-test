from __future__ import annotations

from dataclasses import dataclass
from itertools import chain
from typing import TYPE_CHECKING, cast

from matplotlib.text import Text

from plotnine._utils import ha_as_float, side_artists, va_as_float
from plotnine.composition._axis_collection import PanelSpan
from plotnine.composition._compose import Compose
from plotnine.exceptions import PlotnineError

from ..axes import axis_at
from ..utils import (
    ArtistGeometry,
    TextJustifier,
    bbox_in_axes_space,
    get_subplotspecs,
    rel_position,
    resize_footer_background,
    resize_footer_line,
)

if TYPE_CHECKING:
    from typing import (
        Any,
        Iterator,
        Literal,
        TypeAlias,
    )

    from matplotlib.axes import Axes
    from matplotlib.axis import Axis, Tick
    from matplotlib.backend_bases import RendererBase
    from matplotlib.figure import Figure
    from matplotlib.lines import Line2D
    from matplotlib.patches import Rectangle
    from matplotlib.spines import Spine
    from matplotlib.transforms import Bbox, Transform

    from plotnine import ggplot
    from plotnine._mpl._radial_axes import p9RadialAxes
    from plotnine._mpl.offsetbox import FlexibleAnchoredOffsetbox
    from plotnine._mpl.text import StripText
    from plotnine.iapi import legend_artists
    from plotnine.themes.elements import margin as Margin
    from plotnine.themes.theme import theme
    from plotnine.typing import (
        HorizontalJustification,
        PolarSide,
        Side,
        StripPosition,
        VerticalJustification,
    )

    from ._composition_layout_items import CompositionLayoutItems
    from ._composition_side_space import CompositionSideSpaces
    from ._plot_side_space import PlotSideSpaces

    AxesLocation: TypeAlias = Literal[
        "all", "first_row", "last_row", "first_col", "last_col"
    ]
    TagLocation: TypeAlias = Literal["margin", "plot", "panel"]
    TagPosition: TypeAlias = (
        Literal[
            "topleft",
            "top",
            "topright",
            "left",
            "right",
            "bottomleft",
            "bottom",
            "bottomright",
        ]
        | tuple[float, float]
    )


# Polar boundaries that may carry a theta or r axis.
POLAR_SIDES: tuple[PolarSide, ...] = (
    "theta_outside",
    "theta_inside",
    "r_start",
    "r_end",
)


@dataclass
class PolarLabel:
    """
    A tick label of a polar panel, and where it attaches to the panel

    Sizes are in display space. `anchor` is in panel fractions, which hold
    whatever size the panel settles at.
    """

    anchor: tuple[float, float]
    """Point on the panel the label is placed against"""

    unit: tuple[float, float]
    """Outward unit vector at the label's anchor"""

    width: float
    """Width of the label"""

    height: float
    """Height of the label"""

    gap: float
    """Distance the label is held off its anchor"""

    @classmethod
    def make(
        cls,
        ax: p9RadialAxes,
        side: PolarSide,
        loc: float,
        tick: Tick,
        label: Text,
        renderer: RendererBase,
    ) -> PolarLabel:
        """
        The label at one tick of a polar axis

        A theta tick anchors on its own boundary at the angle of its break;
        an r tick anchors along its spoke at the radius of its break. The
        gap covers the tick mark the label clears and the pad beyond it. The
        unit vector points from the panel towards the label.
        """
        r_inner, r_outer = ax.get_ylim()
        if side == "theta_outside":
            point = (loc, r_outer)
        elif side == "theta_inside":
            point = (loc, r_inner)
        else:
            point = (ax.spoke_angle(side), loc)

        box = label.get_window_extent(renderer)
        anchor = ax.transAxes.inverted().transform(
            ax.transData.transform(point)
        )
        unit = ax.outward_unit(side, loc)
        gap_pt = (tick.get_pad() or 0) + tick.get_tick_padding()
        return cls(
            anchor=(anchor[0], anchor[1]),
            unit=(unit[0], unit[1]),
            width=box.width,
            height=box.height,
            gap=gap_pt * ax.figure.dpi / 72,
        )

    def reach_past(self, side: Side, panel: Bbox) -> float:
        """
        How far the label reaches past one edge of the panel, display space

        The direction component towards the edge determines how much of the
        label and gap extend past it. A label parallel to the edge contributes
        half its extent and none of its gap. A negative result means the label
        stops inside the edge.
        """
        if side in ("left", "right"):
            along, extent, span = self.anchor[0], self.width, panel.width
            facing = self.unit[0] if side == "right" else -self.unit[0]
        else:
            along, extent, span = self.anchor[1], self.height, panel.height
            facing = self.unit[1] if side == "top" else -self.unit[1]
        inset = along if side in ("left", "bottom") else 1 - along
        return extent * (1 + facing) / 2 + self.gap * facing - inset * span


@dataclass
class StripSpec:
    """
    Resolved orientation and theme inputs for laying out a strip

    Built from a `StripText` and the plot theme. `axis` selects the
    breadth axis and theme keys; `sign` is the outward direction (`+1` grows
    in the positive axis direction, `-1` in the negative).
    """

    axis: Literal["x", "y"]
    """`x` for top/bottom strips, `y` for left/right"""

    sign: Literal[1, -1]
    """Direction the strip extends from the panel edge: `+1` (top/right)
    toward larger axes coordinates, `-1` (bottom/left) toward smaller"""

    breadth: Literal["height", "width"]
    """Figure dimension that grows with the strip text"""

    margin: Margin
    """Strip text margin with the units in lines"""

    strip_align: float
    """How far the background is offset from the panel edge"""

    bg_along: float
    """Position of the background along the panel edge (transAxes)"""

    bg_fraction: float
    """Fraction of the panel edge the background spans"""

    ha: HorizontalJustification | float
    """Horizontal justification of the text within the background"""

    va: VerticalJustification | float
    """Vertical justification of the text within the background"""

    @classmethod
    def make(cls, strip_text: StripText, theme: theme) -> StripSpec:
        """
        The layout spec for one strip, given the plot theme
        """
        position = strip_text.position
        g: Literal["x", "y"] = "y" if position in ("left", "right") else "x"
        sign: Literal[1, -1] = 1 if position in ("top", "right") else -1
        breadth: Literal["height", "width"] = "height" if g == "x" else "width"
        # bg_fraction is the background's extent *along* the panel edge —
        # the dimension opposite to breadth.
        span_key = "width" if g == "x" else "height"
        text_key = f"strip_text_{g}_{position}"
        along_key = "x" if g == "x" else "y"
        return cls(
            axis=g,
            sign=sign,
            breadth=breadth,
            margin=theme.getp((text_key, "margin")).to("lines"),
            strip_align=theme.getp(f"strip_align_{g}"),
            bg_along=theme.getp((text_key, along_key), 0),
            bg_fraction=theme.getp((f"strip_background_{g}", span_key), 1),
            ha=theme.getp((text_key, "ha"), "center"),
            va=theme.getp((text_key, "va"), "center"),
        )


class PlotLayoutItems:
    """
    Objects required to compute the layout
    """

    def __init__(self, plot: ggplot):
        def get(name: str) -> Any:
            """
            Return themeable target or None
            """
            if self._is_blank(name):
                return None
            else:
                t = getattr(self.plot.theme.targets, name)
                if isinstance(t, Text) and t.get_text() == "":
                    return None
                return t

        self.plot = plot
        self.geometry = ArtistGeometry(self.plot.figure)

        self.axis_title_x_bottom: Text | None = get("axis_title_x_bottom")
        self.axis_title_x_top: Text | None = get("axis_title_x_top")
        self.axis_title_y_left: Text | None = get("axis_title_y_left")
        self.axis_title_y_right: Text | None = get("axis_title_y_right")

        # # The legends references the structure that contains the
        # # AnchoredOffsetboxes (groups of legends)
        self.legends: legend_artists | None = get("legends")
        self.plot_caption: Text | None = get("plot_caption")
        self.plot_footer: Text | None = get("plot_footer")
        self.plot_subtitle: Text | None = get("plot_subtitle")
        self.plot_title: Text | None = get("plot_title")
        self.plot_tag: Text | None = get("plot_tag")
        self.strip_text_x_top: list[StripText] | None = get("strip_text_x_top")
        self.strip_text_x_bottom: list[StripText] | None = get(
            "strip_text_x_bottom"
        )
        self.strip_text_y_left: list[StripText] | None = get(
            "strip_text_y_left"
        )
        self.strip_text_y_right: list[StripText] | None = get(
            "strip_text_y_right"
        )

        self.plot_footer_background: Rectangle | None = get(
            "plot_footer_background"
        )
        self.plot_footer_line: Line2D | None = get("plot_footer_line")

    def _is_blank(self, name: str) -> bool:
        return self.plot.theme.T.is_blank(name)

    def _filter_axes(self, location: AxesLocation = "all") -> list[Axes]:
        """
        Return subset of axes
        """
        axs = self.plot.axs

        if location == "all":
            return axs

        # e.g. is_first_row, is_last_row, ..
        pred_method = f"is_{location}"
        return [
            ax
            for spec, ax in zip(get_subplotspecs(axs), axs)
            if getattr(spec, pred_method)()
        ]

    def axis_text_x(self, ax: Axes, side: Side) -> Iterator[Text]:
        """
        Return the visible x-axis labels on one side of an axes
        """
        major, minor = [], []

        if not self._is_blank("axis_text_x") and (axis := axis_at(ax, side)):
            major = axis.get_major_ticks()
            minor = axis.get_minor_ticks()

        label_attr = side_artists(side)[1]
        return (
            getattr(tick, label_attr)
            for tick in chain(major, minor)
            if _text_is_visible(getattr(tick, label_attr))
        )

    def axis_text_y(self, ax: Axes, side: Side) -> Iterator[Text]:
        """
        Return the visible y-axis labels on one side of an axes
        """
        major, minor = [], []

        if not self._is_blank("axis_text_y") and (axis := axis_at(ax, side)):
            major = axis.get_major_ticks()
            minor = axis.get_minor_ticks()

        label_attr = side_artists(side)[1]
        return (
            getattr(tick, label_attr)
            for tick in chain(major, minor)
            if _text_is_visible(getattr(tick, label_attr))
        )

    def axis_ticks_x(self, ax: Axes, side: Side) -> Iterator[Tick]:
        """
        Return all XTicks on `side` that will be shown
        """
        major, minor = [], []

        if (axis := axis_at(ax, side)) is not None:
            if not self._is_blank("axis_ticks_major_x"):
                major = axis.get_major_ticks()

            if not self._is_blank("axis_ticks_minor_x"):
                minor = axis.get_minor_ticks()

        return chain(major, minor)

    def axis_ticks_y(self, ax: Axes, side: Side) -> Iterator[Tick]:
        """
        Return all YTicks on `side` that will be shown
        """
        major, minor = [], []

        if (axis := axis_at(ax, side)) is not None:
            if not self._is_blank("axis_ticks_major_y"):
                major = axis.get_major_ticks()

            if not self._is_blank("axis_ticks_minor_y"):
                minor = axis.get_minor_ticks()

        return chain(major, minor)

    def strip_patch_bbox(
        self, strip_text: StripText, scale: float = 1
    ) -> Bbox:
        """
        Figure-space bounding box of one strip's background patch

        The breadth (height for x-axis strips, width for y-axis strips) is
        scaled by `scale` so the layout manager can equalise strips in the
        same group.
        """
        from matplotlib.transforms import Bbox

        spec = StripSpec.make(strip_text, self.plot.theme)
        m = spec.margin
        text_bbox = self.geometry.bbox(strip_text)
        ax_bbox = self.geometry.bbox(strip_text.ax)
        W, H = self.plot.figure.bbox.width, self.plot.figure.bbox.height
        line_height = strip_text._line_height(self.geometry.renderer)

        if spec.axis == "x":
            margins = (m.b + m.t) * line_height / H
            breadth = (text_bbox.height + margins) * scale
            along = ax_bbox.width * spec.bg_fraction
            x0 = rel_position(spec.bg_along, 0, ax_bbox.x0, ax_bbox.x1)
            edge = ax_bbox.y1 if spec.sign == 1 else ax_bbox.y0
            y0 = edge if spec.sign == 1 else edge - breadth
            y0 += spec.sign * breadth * spec.strip_align
            return Bbox.from_bounds(x0, y0, along, breadth)
        else:
            margins = (m.l + m.r) * line_height / W
            breadth = (text_bbox.width + margins) * scale
            along = ax_bbox.height * spec.bg_fraction
            y0 = rel_position(spec.bg_along, 0, ax_bbox.y0, ax_bbox.y1)
            edge = ax_bbox.x1 if spec.sign == 1 else ax_bbox.x0
            x0 = edge if spec.sign == 1 else edge - breadth
            x0 += spec.sign * breadth * spec.strip_align
            return Bbox.from_bounds(x0, y0, breadth, along)

    def strip_text_x(self, position: StripPosition) -> float:
        """
        Outward height of the x-axis strips on one side, in figure space
        """
        strips = getattr(self, f"strip_text_x_{position}")
        if not strips:
            return 0

        heights = []
        for st in strips:
            strip_align = StripSpec.make(st, self.plot.theme).strip_align
            if st.patch.get_visible():
                # The patch bounds are not yet set, so derive its natural
                # height from the sizing inputs.
                h = self.strip_patch_bbox(st).height
            else:
                h = self.geometry.height(st)
            heights.append(max(h + h * strip_align, 0))

        return max(heights) if heights else 0

    def strip_text_y(self, position: StripPosition) -> float:
        """
        Outward width of the y-axis strips on one side, in figure space
        """
        strips = getattr(self, f"strip_text_y_{position}")
        if not strips:
            return 0

        widths = []
        for st in strips:
            strip_align = StripSpec.make(st, self.plot.theme).strip_align
            if st.patch.get_visible():
                # The patch bounds are not yet set, so derive its natural
                # width from the sizing inputs.
                w = self.strip_patch_bbox(st).width
            else:
                w = self.geometry.width(st)
            widths.append(max(w + w * strip_align, 0))

        return max(widths) if widths else 0

    def strip_shift(self, st: StripText) -> float:
        """
        Outward shift of one strip past its own panel's axis, figure space

        For `strip_placement="outside"` a strip sits beyond the ticks,
        tick labels and panel-facing text margin that its own panel draws
        on the strip's side, separated by the strip_switch_pad. A panel
        that draws no axis on that side keeps its strip next to the
        panel, so within one facet the strips of axis-bearing panels
        shift while the others do not.
        """
        if self.plot.theme.getp("strip_placement") != "outside":
            return 0
        return self._strip_axis_clearance(st)

    def _strip_axis_clearance(self, st: StripText) -> float:
        """
        Extent of the axis a strip must clear to sit beyond it, figure space

        The ticks, tick labels and panel-facing text margin its own panel
        draws on the strip's side, plus the strip_switch_pad. Zero when the
        panel draws no axis there.
        """
        theme = self.plot.theme
        side, ax = st.position, st.ax
        W, H = theme.getp("figure_size")
        if side in ("top", "bottom"):
            g, dim = "x", H
            text = self.axis_text_x_max_height(ax, side)
            ticks = self.axis_ticks_x_max_height(ax, side)
            facing = "b" if side == "top" else "t"
        else:
            g, dim = "y", W
            text = self.axis_text_y_max_width(ax, side)
            ticks = self.axis_ticks_y_max_width(ax, side)
            facing = "r" if side == "left" else "l"
        band = text + ticks
        if text:
            m = theme.get_margin(f"axis_text_{g}_{side}").fig
            band += getattr(m, facing)
        if not band:
            return 0
        pad_pt = theme.getp(f"strip_switch_pad_{g}") or 0
        return band + (pad_pt / 72) / dim

    def axis_ticks_x_max_height(self, ax: Axes, side: Side) -> float:
        """
        Return maximum height[figure space] of visible x ticks on a side
        """
        attr = side_artists(side)[0]
        heights = [
            self.geometry.tight_height(getattr(tick, attr))
            for tick in self.axis_ticks_x(ax, side)
            if getattr(tick, attr).get_visible()
        ]
        return max(heights) if len(heights) else 0

    def axis_ticks_x_max_height_at(
        self, location: AxesLocation, side: Side
    ) -> float:
        """
        Return maximum height[figure space] of visible x ticks on a side
        """
        heights = [
            self.axis_ticks_x_max_height(ax, side)
            for ax in self._filter_axes(location)
        ]
        return max(heights) if len(heights) else 0

    def axis_text_x_max_height(self, ax: Axes, side: Side) -> float:
        """
        Return maximum height[figure space] of x tick labels on a side
        """
        heights = [
            self.geometry.tight_height(label)
            for label in self.axis_text_x(ax, side)
        ]
        return max(heights) if len(heights) else 0

    def axis_text_x_max_height_at(
        self, location: AxesLocation, side: Side
    ) -> float:
        """
        Return maximum height[figure space] of x tick labels on a side
        """
        heights = [
            self.axis_text_x_max_height(ax, side)
            for ax in self._filter_axes(location)
        ]
        return max(heights) if len(heights) else 0

    def axis_ticks_y_max_width(self, ax: Axes, side: Side) -> float:
        """
        Return maximum width[figure space] of visible y ticks on a side
        """
        attr = side_artists(side)[0]
        widths = [
            self.geometry.tight_width(getattr(tick, attr))
            for tick in self.axis_ticks_y(ax, side)
            if getattr(tick, attr).get_visible()
        ]
        return max(widths) if len(widths) else 0

    def axis_ticks_y_max_width_at(
        self, location: AxesLocation, side: Side
    ) -> float:
        """
        Return maximum width[figure space] of visible y ticks on a side
        """
        widths = [
            self.axis_ticks_y_max_width(ax, side)
            for ax in self._filter_axes(location)
        ]
        return max(widths) if len(widths) else 0

    def axis_text_y_max_width(self, ax: Axes, side: Side) -> float:
        """
        Return maximum width[figure space] of y tick labels on a side
        """
        widths = [
            self.geometry.tight_width(label)
            for label in self.axis_text_y(ax, side)
        ]
        return max(widths) if len(widths) else 0

    def axis_text_y_max_width_at(
        self, location: AxesLocation, side: Side
    ) -> float:
        """
        Return maximum width[figure space] of y tick labels on a side
        """
        widths = [
            self.axis_text_y_max_width(ax, side)
            for ax in self._filter_axes(location)
        ]
        return max(widths) if len(widths) else 0

    # Side-scoped extents — each names a concrete edge (side picks the
    # artist, location picks the panels) and reads 0 when no axis is there.
    @property
    def axis_text_x_bottom(self) -> float:
        return self.axis_text_x_max_height_at("last_row", "bottom")

    @property
    def axis_text_x_top(self) -> float:
        return self.axis_text_x_max_height_at("first_row", "top")

    @property
    def axis_text_y_left(self) -> float:
        return self.axis_text_y_max_width_at("first_col", "left")

    @property
    def axis_text_y_right(self) -> float:
        return self.axis_text_y_max_width_at("last_col", "right")

    @property
    def axis_ticks_x_bottom(self) -> float:
        return self.axis_ticks_x_max_height_at("last_row", "bottom")

    @property
    def axis_ticks_x_top(self) -> float:
        return self.axis_ticks_x_max_height_at("first_row", "top")

    @property
    def axis_ticks_y_left(self) -> float:
        return self.axis_ticks_y_max_width_at("first_col", "left")

    @property
    def axis_ticks_y_right(self) -> float:
        return self.axis_ticks_y_max_width_at("last_col", "right")

    def axis_text_y_top_protrusion(self, location: AxesLocation) -> float:
        """
        Return maximum height[figure space] above the axes of y tick labels
        """
        extras = []
        for ax in self._filter_axes(location):
            ax_top_y = self.geometry.top_y(ax)
            for side in ("left", "right"):
                for label in self.axis_text_y(ax, side):
                    label_top_y = self.geometry.top_y(label)
                    extras.append(max(0, label_top_y - ax_top_y))

        return max(extras) if len(extras) else 0

    def axis_text_y_bottom_protrusion(self, location: AxesLocation) -> float:
        """
        Return maximum height[figure space] below the axes of y tick labels
        """
        extras = []
        for ax in self._filter_axes(location):
            ax_bottom_y = self.geometry.bottom_y(ax)
            for side in ("left", "right"):
                for label in self.axis_text_y(ax, side):
                    label_bottom_y = self.geometry.bottom_y(label)
                    protrusion = abs(min(label_bottom_y - ax_bottom_y, 0))
                    extras.append(protrusion)

        return max(extras) if len(extras) else 0

    def axis_text_x_left_protrusion(self, location: AxesLocation) -> float:
        """
        Return maximum width[figure space] left of the axes of x tick labels
        """
        extras = []
        for ax in self._filter_axes(location):
            ax_left_x = self.geometry.left_x(ax)
            for side in ("bottom", "top"):
                for label in self.axis_text_x(ax, side):
                    label_left_x = self.geometry.left_x(label)
                    protrusion = abs(min(label_left_x - ax_left_x, 0))
                    extras.append(protrusion)

        return max(extras) if len(extras) else 0

    def axis_text_x_right_protrusion(self, location: AxesLocation) -> float:
        """
        Return maximum width[figure space] right of the axes of y tick labels
        """
        extras = []
        for ax in self._filter_axes(location):
            ax_right_x = self.geometry.right_x(ax)
            for side in ("bottom", "top"):
                for label in self.axis_text_x(ax, side):
                    label_right_x = self.geometry.right_x(label)
                    extras.append(max(0, label_right_x - ax_right_x))

        return max(extras) if len(extras) else 0

    def _move_artists(self, spaces: PlotSideSpaces):
        """
        Move the artists to their final positions
        """
        theme = self.plot.theme
        justify = _position_plot_labels(
            spaces.plot.figure, theme, spaces, self
        )

        if self.plot_tag:
            _position_plot_tag(self.plot_tag, spaces)

        if self.axis_title_x_bottom:
            ha = theme.getp(("axis_title_x_bottom", "ha"), "center")
            self.axis_title_x_bottom.set_y(spaces.b.y1("axis_title"))
            _justify_axis_title(
                justify, spaces, self.axis_title_x_bottom, ha, "bottom"
            )

        if self.axis_title_x_top:
            ha = theme.getp(("axis_title_x_top", "ha"), "center")
            self.axis_title_x_top.set_y(spaces.t.y1("axis_title"))
            _justify_axis_title(
                justify, spaces, self.axis_title_x_top, ha, "top"
            )

        if self.axis_title_y_left:
            va = theme.getp(("axis_title_y_left", "va"), "center")
            self.axis_title_y_left.set_x(spaces.l.x1("axis_title"))
            _justify_axis_title(
                justify, spaces, self.axis_title_y_left, va, "left"
            )

        if self.axis_title_y_right:
            va = theme.getp(("axis_title_y_right", "va"), "center")
            self.axis_title_y_right.set_x(spaces.r.x1("axis_title"))
            _justify_axis_title(
                justify, spaces, self.axis_title_y_right, va, "right"
            )

        if self.legends:
            _position_legends(self.legends, spaces)

        self._adjust_axis_text_x(justify, spaces)
        self._adjust_axis_text_y(justify, spaces)
        self._position_strip_band_axes(spaces)
        self._position_strip_backgrounds()

    def _adjust_axis_text_x(
        self, justify: TextJustifier, spaces: PlotSideSpaces
    ):
        """
        Adjust x-axis text, justifying vertically as necessary
        """

        def to_vertical_axis_dimensions(value: float, ax: Axes) -> float:
            """
            Convert value in figure dimensions to axis dimensions
            """
            _, H = self.plot.figure.bbox.size
            h = ax.get_window_extent().height
            return value * H / h

        if self._is_blank("axis_text_x"):
            return

        # For strip_placement="inside", an axis sharing its side with a
        # strip is pushed past the strip; zero otherwise.
        band_offsets = {
            "bottom": spaces.b.strip_band_offset(),
            "top": spaces.t.strip_band_offset(),
        }

        for side in ("bottom", "top"):
            va_default = "top" if side == "bottom" else "bottom"
            va = self.plot.theme.getp(
                (f"axis_text_x_{side}", "va"), va_default
            )
            for ax in self.plot.axs:
                texts = list(self.axis_text_x(ax, side))
                if not texts:
                    continue
                row_height = to_vertical_axis_dimensions(
                    self.axis_text_x_max_height(ax, side), ax
                )
                # bottom labels sit below the panel (axes y 0), top labels
                # above it (axes y 1)
                offset = to_vertical_axis_dimensions(band_offsets[side], ax)
                if side == "bottom":
                    low, high = (-row_height - offset, -offset)
                else:
                    low, high = (1 + offset, 1 + row_height + offset)
                for text in texts:
                    height = to_vertical_axis_dimensions(
                        self.geometry.tight_height(text), ax
                    )
                    justify.vertically(text, va, low, high, height=height)

    def _adjust_axis_text_y(
        self, justify: TextJustifier, spaces: PlotSideSpaces
    ):
        """
        Adjust x-axis text, justifying horizontally as necessary
        """

        def to_horizontal_axis_dimensions(value: float, ax: Axes) -> float:
            """
            Convert value in figure dimensions to axis dimensions

            Matplotlib expects x position of y-axis text is in transAxes,
            but all our layout measurements are in transFigure.

               ---------------------
              |                     |
              |     -----------     |
              |  X |           |    |
              |  X |           |    |
              |  X |           |    |
              |  X |           |    |
              |  X |           |    |
              |  X |           |    |
              |    0-----------1    |
              |        axes         |
              |                     |
              0---------------------1
                       figure

            We do not set the transform to transFigure because, then we need
            to calculate the position in transFigure; accounting for all the
            space wherever the panel may be.
            """
            W, _ = self.plot.figure.bbox.size
            w = ax.get_window_extent().width
            return value * W / w

        if self._is_blank("axis_text_y"):
            return

        # For strip_placement="inside", an axis sharing its side with a
        # strip is pushed past the strip; zero otherwise.
        band_offsets = {
            "left": spaces.l.strip_band_offset(),
            "right": spaces.r.strip_band_offset(),
        }

        for side in ("left", "right"):
            ha_default = "right" if side == "left" else "left"
            ha = self.plot.theme.getp(
                (f"axis_text_y_{side}", "ha"), ha_default
            )
            for ax in self.plot.axs:
                texts = list(self.axis_text_y(ax, side))
                if not texts:
                    continue
                col_width = to_horizontal_axis_dimensions(
                    self.axis_text_y_max_width(ax, side), ax
                )
                # left labels sit left of the panel (axes x 0), right labels
                # to the right of it (axes x 1)
                offset = to_horizontal_axis_dimensions(band_offsets[side], ax)
                if side == "left":
                    low, high = (-col_width - offset, -offset)
                else:
                    low, high = (1 + offset, 1 + col_width + offset)
                for text in texts:
                    width = to_horizontal_axis_dimensions(
                        self.geometry.tight_width(text), ax
                    )
                    justify.horizontally(text, ha, low, high, width=width)

    def _position_strip_band_axes(self, spaces: PlotSideSpaces):
        """
        Push an axis past a strip that shares its side

        On a side where an axis and a facet strip would otherwise
        overlap (`strip_placement="inside"`), the spine and its tick
        marks shift outward by the strip's extent so the axis sits
        beyond the strip. Has no effect when the side has no shared
        strip/axis band.
        """
        fig = self.plot.figure
        to_points = 72 / fig.dpi
        W, H = fig.bbox.width, fig.bbox.height
        offsets: dict[Side, float] = {
            "top": spaces.t.strip_band_offset() * H,
            "bottom": spaces.b.strip_band_offset() * H,
            "left": spaces.l.strip_band_offset() * W,
            "right": spaces.r.strip_band_offset() * W,
        }
        for ax in self.plot.axs:
            for side, offset in offsets.items():
                if not offset or (axis := axis_at(ax, side)) is None:
                    continue
                _spine_set_position_outward(
                    ax.spines[side], axis, offset * to_points
                )

    def _strip_breadth_scales(
        self, group: list[StripText], breadth: Literal["height", "width"]
    ) -> list[float]:
        """
        Per-strip factor that equalises the breadth across a group

        Each strip's natural breadth is grown to match the largest in
        the group, so the backgrounds share a common height (x-axis strips)
        or width (y-axis strips).
        """
        natural = [getattr(self.strip_patch_bbox(st), breadth) for st in group]
        largest = max(natural)
        return [largest / b for b in natural]

    def _position_strip_backgrounds(self):
        """
        Fix each strip background at its final bounds and place its text

        When `strip_placement="outside"`, each strip is shifted outward
        to clear the axis its own panel draws on the strip's side.
        """
        theme = self.plot.theme
        groups = (
            self.strip_text_x_top or [],
            self.strip_text_x_bottom or [],
            self.strip_text_y_right or [],
            self.strip_text_y_left or [],
        )
        for group in groups:
            if not group:
                continue
            breadth = StripSpec.make(group[0], theme).breadth
            scales = self._strip_breadth_scales(group, breadth)
            for st, scale in zip(group, scales):
                spec = StripSpec.make(st, theme)
                x0, y0, w, h = self.strip_patch_bbox(st, scale).bounds
                shift = self.strip_shift(st)
                if spec.axis == "x":
                    y0 += spec.sign * shift
                else:
                    x0 += spec.sign * shift
                st.patch.set_bounds((x0, y0, w, h))
                self._position_strip_text(st)

    @staticmethod
    def _justify_within(
        rel: float,
        text_extent: float,
        lo: float,
        hi: float,
        lo_margin: float,
        hi_margin: float,
        line_height: float,
        expand: bool,
    ) -> float:
        """
        Axes-space centre of strip text justified within one patch axis

        `expand` true means the patch was sized independently of the text
        (the along axis), so the margins widen the justified content; false
        means the patch was pre-sized to the text plus margins (the breadth
        axis), so the margins inset the bounds.
        """
        if expand:
            content = text_extent + (lo_margin + hi_margin) * line_height
            return (
                rel_position(rel, content, lo, hi)
                + lo_margin * line_height
                + text_extent / 2
            )
        return (
            rel_position(
                rel,
                text_extent,
                lo + lo_margin * line_height,
                hi - hi_margin * line_height,
            )
            + text_extent / 2
        )

    def _position_strip_text(self, st: StripText):
        """
        Justify the strip text within its final background bounds
        """
        spec = StripSpec.make(st, self.plot.theme)
        m = spec.margin
        ax = st.ax
        renderer = self.geometry.renderer
        rel_x, rel_y = ha_as_float(spec.ha), va_as_float(spec.va)

        patch_bbox = bbox_in_axes_space(st.patch, ax, renderer)
        text_bbox = bbox_in_axes_space(st, ax, renderer)

        if spec.axis == "x":
            # breadth = y (inset), along = x (expanded)
            line_height = st._line_height(renderer) / ax.bbox.height
            x = self._justify_within(
                rel_x,
                text_bbox.width,
                patch_bbox.x0,
                patch_bbox.x1,
                m.l,
                m.r,
                line_height,
                expand=True,
            )
            y = self._justify_within(
                rel_y,
                text_bbox.height,
                patch_bbox.y0,
                patch_bbox.y1,
                m.b,
                m.t,
                line_height,
                expand=False,
            )
        else:
            # breadth = x (inset), along = y (expanded)
            line_height = st._line_height(renderer) / ax.bbox.width
            x = self._justify_within(
                rel_x,
                text_bbox.width,
                patch_bbox.x0,
                patch_bbox.x1,
                m.l,
                m.r,
                line_height,
                expand=False,
            )
            y = self._justify_within(
                rel_y,
                text_bbox.height,
                patch_bbox.y0,
                patch_bbox.y1,
                m.b,
                m.t,
                line_height,
                expand=True,
            )

        st.set_position((x, y))


class PolarPlotLayoutItems(PlotLayoutItems):
    """
    Space around a polar panel for its axis decorations

    A theta axis follows an arc and an r axis follows a spoke, so a tick
    label attaches to the panel wherever its break falls rather than along
    one Cartesian side. Each side reserves the labels that reach past it:
    a label's size and the gap that holds it off its boundary, less however
    much of that reach falls inside the panel.

    The size and the gap are physical, so they hold wherever the panel ends
    up. The inset is a fraction of the panel, and the panel is what the
    layout is solving for, so it comes from the previous render. A first
    render therefore over-reserves, which costs a little space and clips
    nothing.

    The band is reported as text clearance, so tick clearance stays zero
    rather than counting the marks twice. Per-side label protrusions stay
    zero too: a label reaching past a second edge is counted on that edge.
    """

    def _axis_clearance(self, ax: Axes, side: Side) -> float:
        """
        Space the panel's axes need past one edge, figure space
        """
        panel = ax.get_window_extent(self.geometry.renderer)
        reaches = [
            label.reach_past(side, panel) for label in self._outward_labels(ax)
        ]
        figure = self.plot.figure.bbox
        span = figure.width if side in ("left", "right") else figure.height
        return max([*reaches, 0]) / span

    def _outward_labels(self, ax: Axes) -> Iterator[PolarLabel]:
        """
        Every tick label the panel will show, with where it attaches

        Each boundary contributes only the label pair assigned to that side.
        """
        renderer = self.geometry.renderer
        panel = cast("p9RadialAxes", ax)
        for polar_side in POLAR_SIDES:
            axis = axis_at(ax, polar_side)
            if axis is None:
                continue
            _, label_attr = side_artists(polar_side)
            for locs, ticks in (
                (axis.get_majorticklocs(), axis.get_major_ticks()),
                (axis.get_minorticklocs(), axis.get_minor_ticks()),
            ):
                for loc, tick in zip(locs, ticks):
                    label = getattr(tick, label_attr)
                    if _text_is_visible(label):
                        yield PolarLabel.make(
                            panel, polar_side, loc, tick, label, renderer
                        )

    def axis_ticks_x_max_height(self, ax: Axes, side: Side) -> float:
        return 0

    def axis_text_x_max_height(self, ax: Axes, side: Side) -> float:
        return self._axis_clearance(ax, side)

    def axis_ticks_y_max_width(self, ax: Axes, side: Side) -> float:
        return 0

    def axis_text_y_max_width(self, ax: Axes, side: Side) -> float:
        return self._axis_clearance(ax, side)

    def axis_text_y_top_protrusion(self, location: AxesLocation) -> float:
        return 0.0

    def axis_text_y_bottom_protrusion(self, location: AxesLocation) -> float:
        return 0.0

    def axis_text_x_left_protrusion(self, location: AxesLocation) -> float:
        return 0.0

    def axis_text_x_right_protrusion(self, location: AxesLocation) -> float:
        return 0.0

    def strip_shift(self, st: StripText) -> float:
        """
        Outward shift of a strip past the polar decorations, figure space

        A polar panel draws its theta and r axes on the arc perimeter,
        so there is no room between the panel and its axis for a strip to
        sit "inside". The strip therefore always clears the decorations,
        as it does for `strip_placement="outside"` on a Cartesian panel,
        regardless of the theme's `strip_placement`.
        """
        return self._strip_axis_clearance(st)


def _spine_set_position_outward(spine: Spine, axis: Axis, distance: float):
    """
    Move a spine and its tick marks outward, keeping the theme's tick styling

    This mirrors `Spine.set_position(("outward", distance))` but skips its
    `axis.reset_ticks()`, which would regenerate the ticks and drop the
    per-tick styling the theme applied (tick label colour and font, blanked
    minor tick marks, ...). The reset is avoided by re-pointing the existing
    tick marks at the moved spine's transform; the tick labels are
    positioned separately by the layout.
    """
    spine._position = ("outward", distance)  # pyright: ignore[reportAttributeAccessIssue]
    transform = spine.get_spine_transform()
    spine.set_transform(transform)
    # The outward-facing marks are tick2 on a top/right spine and
    # tick1 on a bottom/left spine.
    outer = (
        "tick2line" if spine.spine_type in ("top", "right") else "tick1line"
    )
    for tick in (*axis.get_major_ticks(), *axis.get_minor_ticks()):
        getattr(tick, outer).set_transform(transform)
    spine.stale = True


def _text_is_visible(text: Text) -> bool:
    """
    Return True if text is visible and is not empty
    """
    return text.get_visible() and text._text  # type: ignore


def _justify_axis_title(
    justify: TextJustifier,
    spaces: PlotSideSpaces,
    text: Text,
    ratio: float,
    side: Side,
):
    """
    Position an axis title across the panels it labels

    A collected title spans every panel it labels. An uncollected title uses
    the plot's own panel bounds, so its span contains only that plot's
    panels.

    Parameters
    ----------
    justify :
        Text positioner for figure-space bounds.
    spaces :
        Side spaces for the plot that draws the title.
    text :
        Axis title to position.
    ratio :
        Horizontal or vertical alignment within the span.
    side :
        Side containing the title.
    """
    span = spaces.axis_title_span.get(side) or PanelSpan((spaces,))
    if side in ("bottom", "top"):
        justify.horizontally(text, ratio, span.left, span.right)
    else:
        justify.vertically(text, ratio, span.bottom, span.top)


def _position_plot_labels(
    figure: Figure,
    theme: theme,
    spaces: PlotSideSpaces | CompositionSideSpaces,
    items: PlotLayoutItems | CompositionLayoutItems,
) -> TextJustifier:
    """
    Position title, subtitle, caption, footer, and footer decorations

    Returns the TextJustifier so the caller can reuse it for
    additional positioning (e.g. axis titles).
    """
    plot_title_position = theme.getp("plot_title_position", "panel")
    plot_caption_position = theme.getp("plot_caption_position", "panel")
    plot_footer_position = theme.getp("plot_footer_position", "plot")
    justify = TextJustifier.from_boundaries(
        figure,
        plot_left=spaces.plot_left,
        plot_right=spaces.plot_right,
        plot_bottom=spaces.plot_bottom,
        plot_top=spaces.plot_top,
        panel_left=spaces.panel_left,
        panel_right=spaces.panel_right,
        panel_bottom=spaces.panel_bottom,
        panel_top=spaces.panel_top,
    )

    if items.plot_title:
        ha = theme.getp(("plot_title", "ha"))
        items.plot_title.set_y(spaces.t.y2("plot_title"))
        justify.horizontally_about(items.plot_title, ha, plot_title_position)

    if items.plot_subtitle:
        ha = theme.getp(("plot_subtitle", "ha"))
        items.plot_subtitle.set_y(spaces.t.y2("plot_subtitle"))
        justify.horizontally_about(
            items.plot_subtitle, ha, plot_title_position
        )

    if items.plot_caption:
        ha = theme.getp(("plot_caption", "ha"), "right")
        items.plot_caption.set_y(spaces.b.y1("plot_caption"))
        justify.horizontally_about(
            items.plot_caption, ha, plot_caption_position
        )

    if items.plot_footer:
        ha = theme.getp(("plot_footer", "ha"), "left")
        items.plot_footer.set_y(spaces.b.y1("plot_footer"))
        justify.horizontally_about(items.plot_footer, ha, plot_footer_position)
        if items.plot_footer_background:
            resize_footer_background(
                items.plot_footer_background,
                x=spaces.l.offset,
                y=spaces.b.offset,
                height=spaces.b.footer_height,
                width=spaces.plot_width,
            )
        if items.plot_footer_line:
            resize_footer_line(
                items.plot_footer_line,
                x=spaces.l.offset,
                width=spaces.plot_width,
                y=spaces.b.offset + spaces.b.footer_height,
            )

    return justify


def _position_legends(
    legends: legend_artists,
    spaces: PlotSideSpaces | CompositionSideSpaces,
):
    """
    Place legends on the figure, justifying each as required

    Works for both plot-level and composition-level legends. Both
    side-space hierarchies expose an `owner` property — a `ggplot`
    or `Compose` — which provides the `_sub_gridspec` to anchor
    against and the `figure` to transform onto.
    """
    panels_gs = spaces.owner._sub_gridspec
    params = panels_gs.get_subplot_params()
    transFigure = spaces.owner.figure.transFigure

    def set_position(
        aob: FlexibleAnchoredOffsetbox,
        anchor_point: tuple[float, float],
        xy_loc: tuple[float, float],
        transform: Transform = transFigure,
    ):
        """
        Place box (by the anchor point) at given xy location

        Parameters
        ----------
        aob :
           Offsetbox to place
        anchor_point :
            Point on the Offsefbox.
        xy_loc :
            Point where to place the offsetbox.
        transform :
            Transformation
        """
        aob.xy_loc = xy_loc
        aob.set_bbox_to_anchor(anchor_point, transform)  # type: ignore

    if legends.right:
        y = rel_position(
            legends.right.justification,
            spaces.r.legend_height,
            params.bottom,
            params.top,
        )
        x = spaces.r.x2("legend")
        set_position(legends.right.box, (x, y), (1, 0))

    if legends.left:
        y = rel_position(
            legends.left.justification,
            spaces.l.legend_height,
            params.bottom,
            params.top,
        )
        x = spaces.l.x1("legend")
        set_position(legends.left.box, (x, y), (0, 0))

    if legends.top:
        x = rel_position(
            legends.top.justification,
            spaces.t.legend_width,
            params.left,
            params.right,
        )
        y = spaces.t.y2("legend")
        set_position(legends.top.box, (x, y), (0, 1))

    if legends.bottom:
        x = rel_position(
            legends.bottom.justification,
            spaces.b.legend_width,
            params.left,
            params.right,
        )
        y = spaces.b.y1("legend")
        set_position(legends.bottom.box, (x, y), (0, 0))

    # Inside legends are placed using the panels coordinate system.
    # For a `Compose` owner with a `guide_area` host, the guides are
    # rendered in the guide_areas panel, so we need that gridspec
    if legends.inside:
        if isinstance(spaces.owner, Compose) and spaces.owner._guide_area:
            panels_gs = spaces.owner._guide_area._sub_gridspec

        transPanels = panels_gs.to_transform()
        for l in legends.inside:
            set_position(l.box, l.position, l.justification, transPanels)


def _position_plot_tag(tag: Text, spaces: PlotSideSpaces):
    """
    Set the position of the plot_tag
    """
    theme = spaces.plot.theme
    panels_gs = spaces.plot._sub_gridspec
    location: TagLocation = theme.getp("plot_tag_location")
    position: TagPosition = theme.getp("plot_tag_position")
    margin = theme.get_margin("plot_tag")

    if location == "margin":
        return _position_plot_tag_in_margin(tag, spaces)

    lookup: dict[str, tuple[float, float]] = {
        "topleft": (0, 1),
        "top": (0.5, 1),
        "topright": (1, 1),
        "left": (0, 0.5),
        "right": (1, 0.5),
        "bottomleft": (0, 0),
        "bottom": (0.5, 0),
        "bottomright": (1, 0),
    }

    if isinstance(position, str):
        # Coordinates of the space in which to place the tag
        if location == "plot":
            (x1, y1), (x2, y2) = spaces.plot_area_coordinates
        else:
            (x1, y1), (x2, y2) = spaces.panel_area_coordinates

        # Calculate the position when the tag has no margins
        rel_x, rel_y = lookup[position]
        width, height = spaces.items.geometry.size(tag)
        x = rel_position(rel_x, width, x1, x2)
        y = rel_position(rel_y, height, y1, y2)

        # Adjust the position to account for the margins
        # When the units for the margin are in the figure coordinates,
        # the adjustment is proportional to the size of the space.
        # For points, inches and lines, the adjustment is absolute.
        mx, my = _plot_tag_margin_adjustment(margin, position)
        if margin.unit == "fig":
            panel_width, panel_height = (x2 - x1), (y2 - y1)
        else:
            panel_width, panel_height = 1, 1

        x += panel_width * mx
        y += panel_height * my

        position = (x, y)
        tag.set_horizontalalignment("left")
        tag.set_verticalalignment("bottom")
    else:
        if location == "panel":
            transPanels = panels_gs.to_transform()
            tag.set_transform(transPanels)

    tag.set_position(position)


def _position_plot_tag_in_margin(tag: Text, spaces: PlotSideSpaces):
    """
    Place the tag in an inner margin around the plot

    The panel_margin remains outside the tag. For compositions, the
    tag is placed and within the tag_alignment space.
    """
    position: TagPosition = spaces.plot.theme.getp("plot_tag_position")
    if not isinstance(position, str):
        raise PlotnineError(
            f"Cannot have plot_tag_location='margin' if "
            f"plot_tag_position={position!r}."
        )

    tag.set_position(spaces.to_figure_space((0.5, 0.5)))
    ha = spaces.plot.theme.get_ha("plot_tag")
    va = spaces.plot.theme.get_va("plot_tag")
    if "left" in position:  # left, topleft, bottomleft
        space = spaces.l.tag_alignment
        x = spaces.l.x1("plot_tag") - (1 - ha) * space
        tag.set_x(x)
        tag.set_horizontalalignment("left")
    if "right" in position:  # right, topright, bottomright
        space = spaces.r.tag_alignment
        x = spaces.r.x1("plot_tag") + ha * space
        tag.set_x(x)
        tag.set_horizontalalignment("left")
    if "bottom" in position:  # bottom, bottomleft, bottomright
        space = spaces.b.tag_alignment
        y = spaces.b.y1("plot_tag") + (1 - va) * space
        tag.set_y(y)
        tag.set_verticalalignment("bottom")
    if "top" in position:  # top, topleft, topright
        space = spaces.t.tag_alignment
        y = spaces.t.y1("plot_tag") + va * space
        tag.set_y(y)
        tag.set_verticalalignment("bottom")

    justify = TextJustifier.from_boundaries(
        spaces.plot.figure,
        plot_left=spaces.l.plot_left,
        plot_right=spaces.r.plot_right,
        plot_bottom=spaces.b.plot_bottom,
        plot_top=spaces.t.plot_top,
        panel_left=spaces.l.panel_left,
        panel_right=spaces.r.panel_right,
        panel_bottom=spaces.b.panel_bottom,
        panel_top=spaces.t.panel_top,
    )
    if position in ("left", "right"):
        justify.vertically_along_plot(tag, va)
    elif position in ("top", "bottom"):
        justify.horizontally_across_plot(tag, ha)


def _plot_tag_margin_adjustment(
    margin: Margin, position: str
) -> tuple[float, float]:
    """
    How to adjust the plot_tag to account for the margin
    """
    m = margin.fig
    dx, dy = 0, 0

    if "top" in position:
        dy = -m.t
    elif "bottom" in position:
        dy = m.b

    if "left" in position:
        dx = m.l
    elif "right" in position:
        dx = -m.r

    return (dx, dy)
