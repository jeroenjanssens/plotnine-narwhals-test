"""
Routines to adjust subplot params so that subplots are
nicely fit in the figure. In doing so, only axis labels, tick labels, axes
titles and offsetboxes that are anchored to axes are currently considered.

Internally, this module assumes that the margins (left margin, etc.) which are
differences between `Axes.get_tightbbox` and `Axes.bbox` are independent of
Axes position. This may fail if `Axes.adjustable` is `datalim` as well as
such cases as when left or right margin are affected by xlabel.
"""

from __future__ import annotations

from dataclasses import replace
from functools import cached_property
from typing import TYPE_CHECKING, Literal, cast

from plotnine.coords import coord_radial
from plotnine.exceptions import PlotnineError
from plotnine.facets import facet_grid, facet_null, facet_wrap

from ._plot_layout_items import PlotLayoutItems, PolarPlotLayoutItems
from ._side_space import GridSpecParams, _side_space

if TYPE_CHECKING:
    from plotnine import ggplot
    from plotnine._mpl.gridspec import p9GridSpec
    from plotnine.composition._axis_collection import PanelSpan
    from plotnine.iapi import outside_legend
    from plotnine.typing import Side


class _plot_side_space(_side_space):
    """
    Base class for the side space around a plot
    """

    def __init__(self, items: PlotLayoutItems):
        self.items = items
        self.gridspec = items.plot._gridspec
        self._calculate()

    @cached_property
    def _legend_size(self) -> tuple[float, float]:
        """
        Return size of legend in figure coordinates

        We need this to accurately justify the legend by proportional
        values e.g. 0.2, instead of just left, right, top,  bottom &
        center.
        """
        if not self.has_legend:
            return (0, 0)

        ol: outside_legend = getattr(self.items.legends, self.side)
        return self.items.geometry.size(ol.box)

    @cached_property
    def legend_width(self) -> float:
        """
        Return width of legend in figure coordinates
        """
        return self._legend_size[0]

    @cached_property
    def legend_height(self) -> float:
        """
        Return height of legend in figure coordinates
        """
        return self._legend_size[1]

    @property
    def has_tag(self) -> bool:
        """
        Return True if the space/margin to this side of the panel has a tag

        If it does, then it will be included in the layout
        """
        getp = self.items.plot.theme.getp
        return getp("plot_tag_location") == "margin" and self.side in getp(
            "plot_tag_position"
        )

    @property
    def has_legend(self) -> bool:
        """
        Return True if the space/margin to this side of the panel has a legend

        If it does, then it will be included in the layout
        """
        if not self.items.legends:
            return False
        return hasattr(self.items.legends, self.side)

    @property
    def tag_width(self) -> float:
        """
        The width of the tag including the margins

        The value is zero except if all these are true:
            - The tag is in the margin `theme(plot_tag_position = "margin")`
            - The tag at one one of the the following locations;
              left, right, topleft, topright, bottomleft or bottomright
        """
        return 0

    @property
    def tag_height(self) -> float:
        """
        The height of the tag including the margins

        The value is zero except if all these are true:
            - The tag is in the margin `theme(plot_tag_position = "margin")`
            - The tag at one one of the the following locations;
              top, bottom, topleft, topright, bottomleft or bottomright
        """
        return 0

    @property
    def axis_title_clearance(self) -> float:
        """
        The distance between the axis title and the panel

         Figure
         ----------------------------
        |         Panel              |
        |         -----------        |
        |        |           |       |
        |        |           |       |
        |  Y<--->|           |       |
        |        |           |       |
        |        |           |       |
        |         -----------        |
        |                            |
         ----------------------------

        We use this value to when aligning axis titles in a
        plot composition.
        """

        try:
            return self.total - self.sum_upto("axis_title_alignment")
        except AttributeError as err:
            # There is probably an error in in the layout manager
            raise PlotnineError("Side has no axis title") from err

    @property
    def _axis_ticks_and_text(self) -> float:
        """
        Outward extent of this side's axis ticks and tick labels, figure space

        The axis title is excluded. Computed from the items present on the
        side, identically for all four sides; zero on a side with no axis.
        """
        return self.sum_incl("axis_ticks") - self.sum_upto("axis_text")

    def _strip_switch_pad(self, axis: Literal["x", "y"]) -> float:
        """
        Reserved gap between a shared axis and a strip placed beyond it

        The gap is non-zero only for `strip_placement="outside"` on a
        side that carries both a strip and an axis; otherwise zero. The
        themeable value is in points and is returned as a fraction of
        the relevant figure dimension (height for x strips, width for y).
        """
        theme = self.items.plot.theme
        if theme.getp("strip_placement") != "outside":
            return 0
        strip_breadth: float = self.strip_text  # pyright: ignore[reportAttributeAccessIssue]
        if not (strip_breadth and self._axis_ticks_and_text):
            return 0
        pad_pt = theme.getp(f"strip_switch_pad_{axis}") or 0
        W, H = theme.getp("figure_size")
        dim = H if axis == "x" else W
        return (pad_pt / 72) / dim

    def strip_band_offset(self) -> float:
        """
        Outward offset of the axis within a shared strip/axis band

        When a facet strip and an axis occupy the same side, the band is
        ordered from the panel outward. `strip_placement` chooses the order:

            "inside":   panel | strip | ticks+labels | title
            "outside":  panel | ticks+labels | strip | title

        For `"inside"` the axis (ticks and tick labels) clears the strip,
        so the offset is the strip breadth; for `"outside"` the axis stays
        at the panel and each strip clears its own panel's axis instead
        (`PlotLayoutItems.strip_shift`). The offset is produced here in
        figure space and consumed per artist in its own coordinate system:
        the tick labels in axes fractions, the spine in points.

        The offset is zero unless the side carries both a strip and an axis.
        """
        strip_breadth: float = self.strip_text  # pyright: ignore[reportAttributeAccessIssue]
        if not (strip_breadth and self._axis_ticks_and_text):
            return 0
        placement = self.items.plot.theme.getp("strip_placement")
        return strip_breadth if placement == "inside" else 0


class left_space(_plot_side_space):
    """
    Space in the figure for artists on the left of the panel area

    Ordered from the edge of the figure and going inwards
    """

    plot_margin: float = 0
    tag_alignment: float = 0
    """
    Space added to align the tag in this plot with others in a composition

    This value is calculated during the layout process, and it ensures that
    all tags on this side of the plot take up the same amount of space in
    the margin. e.g. from

         ------------------------------------
        | plot_margin | tag | artists        |
        |------------------------------------|
        | plot_margin | A long tag | artists |
         ------------------------------------

    to

         ------------------------------------
        | plot_margin |     tag    | artists |
        |------------------------------------|
        | plot_margin | A long tag | artists |
         ------------------------------------

    And the tag is justified within that space e.g if ha="left" we get

         ------------------------------------
        | plot_margin | tag        | artists |
        |------------------------------------|
        | plot_margin | A long tag | artists |
         ------------------------------------

    So, contrary to the order in which the space items are laid out, the 
    tag_alignment does not necessarily come before the plot_tag.
    """
    plot_tag_margin_left: float = 0
    plot_tag: float = 0
    plot_tag_margin_right: float = 0
    margin_alignment: float = 0
    """
    Space added to align this plot with others in a composition

    This value is calculated during the layout process in a tree structure
    that has convenient access to the sides/edges of the panels in the
    composition.
    """
    legend: float = 0
    legend_box_spacing: float = 0
    axis_title_margin_left: float = 0
    """Outer (edge-facing) margin of the y-axis title"""
    axis_title: float = 0
    axis_title_margin_right: float = 0
    """Panel-facing margin of the y-axis title"""
    axis_title_alignment: float = 0
    """
    Space added to align the axis title with others in a composition

    This value is calculated during the layout process. The amount is
    the difference between the largest and smallest axis_title_clearance
    among the items in the composition.
    """
    axis_text_margin_left: float = 0
    """Outer (edge-facing) margin of the y-axis text"""
    axis_text: float = 0
    axis_text_margin_right: float = 0
    """Panel-facing margin of the y-axis text"""
    axis_ticks: float = 0
    strip_switch_pad: float = 0
    """Gap between a shared axis and a strip beyond it (outside placement)"""
    strip_text: float = 0
    """Outward extent of a left facet strip"""

    def _calculate(self):
        theme = self.items.plot.theme
        geometry = self.items.geometry
        items = self.items

        self.plot_margin = theme.getp("plot_margin_left")

        if self.has_tag and items.plot_tag:
            m = theme.get_margin("plot_tag").fig
            self.plot_tag_margin_left = m.l
            self.plot_tag = geometry.width(items.plot_tag)
            self.plot_tag_margin_right = m.r

        if items.legends and items.legends.left:
            self.legend = self.legend_width
            self.legend_box_spacing = theme.getp("legend_box_spacing")

        # A left y-axis reads its left (outer) and right (panel-facing)
        # margins directly.
        if items.axis_title_y_left:
            self.axis_title = geometry.width(items.axis_title_y_left)
            m = theme.get_margin("axis_title_y_left").fig
            self.axis_title_margin_left = m.l
            self.axis_title_margin_right = m.r

        self.axis_text = items.axis_text_y_left
        if self.axis_text:
            m = theme.get_margin("axis_text_y_left").fig
            self.axis_text_margin_left = m.l
            self.axis_text_margin_right = m.r

        self.axis_ticks = items.axis_ticks_y_left
        self.strip_text = items.strip_text_y("left")
        self.strip_switch_pad = self._strip_switch_pad("y")

        # Adjust plot_margin to make room for ylabels that protude well
        # beyond the axes
        # NOTE: This adjustment breaks down when the protrusion is large
        protrusion = items.axis_text_x_left_protrusion("all")
        adjustment = protrusion - (self.total - self.plot_margin)
        if adjustment > 0:
            self.plot_margin += adjustment

    @property
    def offset(self) -> float:
        """
        Distance from left of the figure to the left of the plot gridspec

              ----------------(1, 1)
             |      ----      |
             |  dx |    |     |
             |<--->|    |     |
             |     |    |     |
             |      ----      |
        (0, 0)----------------

        """
        return self.gridspec.bbox_relative.x0

    def x1(self, item: str) -> float:
        """
        Lower x-coordinate in figure space of the item
        """
        return self.to_figure_space(self.sum_upto(item))

    def x2(self, item: str) -> float:
        """
        Higher x-coordinate in figure space of the item
        """
        return self.to_figure_space(self.sum_incl(item))

    @property
    def panel_left_relative(self):
        """
        Left (relative to the gridspec) of the panels in figure dimensions
        """
        return self.total

    @property
    def panel_left(self):
        """
        Left of the panels in figure space
        """
        return self.to_figure_space(self.panel_left_relative)

    @property
    def plot_left(self):
        """
        Distance up to the left-most artist in figure space
        """
        return self.x1("legend")

    @property
    def tag_width(self):
        """
        The width of the tag including the margins
        """
        return (
            self.plot_tag_margin_left
            + self.plot_tag
            + self.plot_tag_margin_right
        )


class right_space(_plot_side_space):
    """
    Space in the figure for artists on the right of the panel area

    Ordered from the edge of the figure and going inwards
    """

    plot_margin: float = 0
    tag_alignment: float = 0
    plot_tag_margin_right: float = 0
    plot_tag: float = 0
    plot_tag_margin_left: float = 0
    margin_alignment: float = 0
    legend: float = 0
    legend_box_spacing: float = 0
    axis_title_margin_right: float = 0
    """Outer (edge-facing) margin of the y-axis title"""
    axis_title: float = 0
    axis_title_margin_left: float = 0
    """Panel-facing margin of the y-axis title"""
    axis_title_alignment: float = 0
    axis_text_margin_right: float = 0
    """Outer (edge-facing) margin of the y-axis text"""
    axis_text: float = 0
    axis_text_margin_left: float = 0
    """Panel-facing margin of the y-axis text"""
    axis_ticks: float = 0
    strip_switch_pad: float = 0
    """Gap between a shared axis and a strip beyond it (outside placement)"""
    strip_text: float = 0
    """Outward extent of a right facet strip (next to the panel by default)"""

    def _calculate(self):
        items = self.items
        theme = self.items.plot.theme
        geometry = self.items.geometry

        self.plot_margin = theme.getp("plot_margin_right")

        if self.has_tag and items.plot_tag:
            m = theme.get_margin("plot_tag").fig
            self.plot_tag_margin_right = m.r
            self.plot_tag = geometry.width(items.plot_tag)
            self.plot_tag_margin_left = m.l

        if items.legends and items.legends.right:
            self.legend = self.legend_width
            self.legend_box_spacing = theme.getp("legend_box_spacing")

        self.strip_text = items.strip_text_y("right")

        # A right y-axis reads its right (outer) and left (panel-facing)
        # margins directly.
        if items.axis_title_y_right:
            self.axis_title = geometry.width(items.axis_title_y_right)
            m = theme.get_margin("axis_title_y_right").fig
            self.axis_title_margin_right = m.r
            self.axis_title_margin_left = m.l

        self.axis_text = items.axis_text_y_right
        if self.axis_text:
            m = theme.get_margin("axis_text_y_right").fig
            self.axis_text_margin_right = m.r
            self.axis_text_margin_left = m.l
        self.axis_ticks = items.axis_ticks_y_right
        self.strip_switch_pad = self._strip_switch_pad("y")

        # Adjust plot_margin to make room for ylabels that protude well
        # beyond the axes
        # NOTE: This adjustment breaks down when the protrusion is large
        protrusion = items.axis_text_x_right_protrusion("all")
        adjustment = protrusion - (self.total - self.plot_margin)
        if adjustment > 0:
            self.plot_margin += adjustment

    @property
    def offset(self):
        """
        Distance from right of the figure to the right of the plot gridspec

              ---------------(1, 1)
             |     ----      |
             |    |    | -dx |
             |    |    |<--->|
             |    |    |     |
             |     ----      |
        (0, 0)---------------

        """
        return self.gridspec.bbox_relative.x1 - 1

    def x1(self, item: str) -> float:
        """
        Lower x-coordinate in figure space of the item
        """
        return self.to_figure_space(1 - self.sum_incl(item))

    def x2(self, item: str) -> float:
        """
        Higher x-coordinate in figure space of the item
        """
        return self.to_figure_space(1 - self.sum_upto(item))

    @property
    def panel_right_relative(self):
        """
        Right (relative to the gridspec) of the panels in figure dimensions
        """
        return 1 - self.total

    @property
    def panel_right(self):
        """
        Right of the panels in figure space
        """
        return self.to_figure_space(self.panel_right_relative)

    @property
    def plot_right(self):
        """
        Distance up to the right-most artist in figure space
        """
        return self.x2("legend")

    @property
    def tag_width(self):
        """
        The width of the tag including the margins
        """
        return (
            self.plot_tag_margin_right
            + self.plot_tag
            + self.plot_tag_margin_left
        )


class top_space(_plot_side_space):
    """
    Space in the figure for artists above the panel area

    Ordered from the edge of the figure and going inwards
    """

    plot_margin: float = 0
    tag_alignment: float = 0
    plot_tag_margin_top: float = 0
    plot_tag: float = 0
    plot_tag_margin_bottom: float = 0
    margin_alignment: float = 0
    plot_title_margin_top: float = 0
    plot_title: float = 0
    plot_title_margin_bottom: float = 0
    plot_subtitle_margin_top: float = 0
    plot_subtitle: float = 0
    plot_subtitle_margin_bottom: float = 0
    plot_title_alignment: float = 0
    """
    Space added to align the plot title with others in a composition

    This value is calculated during the layout process. The amount is
    the difference between the largest and smallest plot_title_clearance
    among the items in the composition.
    """
    legend: float = 0
    legend_box_spacing: float = 0
    axis_title_margin_top: float = 0
    """Outer (edge-facing) margin of the x-axis title"""
    axis_title: float = 0
    axis_title_margin_bottom: float = 0
    """Panel-facing margin of the x-axis title"""
    axis_title_alignment: float = 0
    axis_text_margin_top: float = 0
    """Outer (edge-facing) margin of the x-axis text"""
    axis_text: float = 0
    axis_text_margin_bottom: float = 0
    """Panel-facing margin of the x-axis text"""
    axis_ticks: float = 0
    strip_switch_pad: float = 0
    """Gap between a shared axis and a strip beyond it (outside placement)"""
    strip_text: float = 0
    """Outward extent of a top facet strip (next to the panel by default)"""

    def _calculate(self):
        items = self.items
        theme = self.items.plot.theme
        geometry = self.items.geometry
        W, H = theme.getp("figure_size")
        F = W / H

        self.plot_margin = theme.getp("plot_margin_top") * F

        if self.has_tag and items.plot_tag:
            m = theme.get_margin("plot_tag").fig
            self.plot_tag_margin_top = m.t
            self.plot_tag = geometry.height(items.plot_tag)
            self.plot_tag_margin_bottom = m.b

        if items.plot_title:
            m = theme.get_margin("plot_title").fig
            self.plot_title_margin_top = m.t
            self.plot_title = geometry.height(items.plot_title)
            self.plot_title_margin_bottom = m.b

        if items.plot_subtitle:
            m = theme.get_margin("plot_subtitle").fig
            self.plot_subtitle_margin_top = m.t
            self.plot_subtitle = geometry.height(items.plot_subtitle)
            self.plot_subtitle_margin_bottom = m.b

        if items.legends and items.legends.top:
            self.legend = self.legend_height
            self.legend_box_spacing = theme.getp("legend_box_spacing") * F

        self.strip_text = items.strip_text_x("top")

        # A top x-axis reads its top (outer) and bottom (panel-facing)
        # margins directly.
        if items.axis_title_x_top:
            self.axis_title = geometry.height(items.axis_title_x_top)
            m = theme.get_margin("axis_title_x_top").fig
            self.axis_title_margin_top = m.t
            self.axis_title_margin_bottom = m.b

        self.axis_text = items.axis_text_x_top
        if self.axis_text:
            m = theme.get_margin("axis_text_x_top").fig
            self.axis_text_margin_top = m.t
            self.axis_text_margin_bottom = m.b
        self.axis_ticks = items.axis_ticks_x_top
        self.strip_switch_pad = self._strip_switch_pad("x")

        # Adjust plot_margin to make room for ylabels that protude well
        # beyond the axes
        # NOTE: This adjustment breaks down when the protrusion is large
        protrusion = items.axis_text_y_top_protrusion("all")
        adjustment = protrusion - (self.total - self.plot_margin)
        if adjustment > 0:
            self.plot_margin += adjustment

    @property
    def plot_title_clearance(self) -> float:
        """
        The distance between the plot title block and the panel

        Everything between the title & subtitle and the panel — legend,
        axis title, axis text, ticks and facet strip — counts toward
        this distance. When it is equal across the plots in a row of a
        composition, their titles sit at the same height.
        """
        return self.total - self.sum_upto("plot_title_alignment")

    @property
    def offset(self) -> float:
        """
        Distance from top of the figure to the top of the plot gridspec

              ----------------(1, 1)
             |       ^        |
             |       |-dy     |
             |       v        |
             |      ----      |
             |     |    |     |
             |     |    |     |
             |     |    |     |
             |      ----      |
             |                |
        (0, 0)----------------
        """
        return self.gridspec.bbox_relative.y1 - 1

    def y1(self, item: str) -> float:
        """
        Lower y-coordinate in figure space of the item
        """
        return self.to_figure_space(1 - self.sum_incl(item))

    def y2(self, item: str) -> float:
        """
        Higher y-coordinate in figure space of the item
        """
        return self.to_figure_space(1 - self.sum_upto(item))

    @property
    def panel_top_relative(self):
        """
        Top (relative to the gridspec) of the panels in figure dimensions
        """
        return 1 - self.total

    @property
    def panel_top(self):
        """
        Top of the panels in figure space
        """
        return self.to_figure_space(self.panel_top_relative)

    @property
    def plot_top(self):
        """
        Distance up to the top-most artist in figure space
        """
        return self.y2("legend")

    @property
    def tag_height(self):
        """
        The height of the tag including the margins
        """
        return (
            self.plot_tag_margin_top
            + self.plot_tag
            + self.plot_tag_margin_bottom
        )


class bottom_space(_plot_side_space):
    """
    Space in the figure for artists below the panel area

    Ordered from the edge of the figure and going inwards
    """

    plot_footer_margin_bottom: float = 0
    plot_footer: float = 0
    plot_footer_margin_top: float = 0
    plot_margin: float = 0
    tag_alignment: float = 0
    plot_tag_margin_bottom: float = 0
    plot_tag: float = 0
    plot_tag_margin_top: float = 0
    margin_alignment: float = 0
    plot_caption_margin_bottom: float = 0
    plot_caption: float = 0
    plot_caption_margin_top: float = 0
    legend: float = 0
    legend_box_spacing: float = 0
    axis_title_margin_bottom: float = 0
    """Outer (edge-facing) margin of the x-axis title"""
    axis_title: float = 0
    axis_title_margin_top: float = 0
    """Panel-facing margin of the x-axis title"""
    axis_title_alignment: float = 0
    """
    Space added to align the axis title with others in a composition

    This value is calculated during the layout process in a tree structure
    that has convenient access to the sides/edges of the panels in the
    composition. It's amount is the difference in height between this axis
    text (and it's margins) and the tallest axis text (and it's margin).
    """
    axis_text_margin_bottom: float = 0
    """Outer (edge-facing) margin of the x-axis text"""
    axis_text: float = 0
    axis_text_margin_top: float = 0
    """Panel-facing margin of the x-axis text"""
    axis_ticks: float = 0
    strip_switch_pad: float = 0
    """Gap between a shared axis and a strip beyond it (outside placement)"""
    strip_text: float = 0
    """Outward extent of a bottom facet strip"""

    def _calculate(self):
        items = self.items
        theme = self.items.plot.theme
        geometry = self.items.geometry
        W, H = theme.getp("figure_size")
        F = W / H

        self.plot_margin = theme.getp("plot_margin_bottom") * F

        if self.has_tag and items.plot_tag:
            m = theme.get_margin("plot_tag").fig
            self.plot_tag_margin_bottom = m.b
            self.plot_tag = geometry.height(items.plot_tag)
            self.plot_tag_margin_top = m.t

        if items.plot_caption:
            m = theme.get_margin("plot_caption").fig
            self.plot_caption_margin_bottom = m.b
            self.plot_caption = geometry.height(items.plot_caption)
            self.plot_caption_margin_top = m.t

        if items.plot_footer:
            m = theme.get_margin("plot_footer").fig
            self.plot_footer_margin_bottom = m.b
            self.plot_footer = geometry.height(items.plot_footer)
            self.plot_footer_margin_top = m.t

        if items.legends and items.legends.bottom:
            self.legend = self.legend_height
            self.legend_box_spacing = theme.getp("legend_box_spacing") * F

        # A bottom x-axis reads its bottom (outer) and top (panel-facing)
        # margins directly.
        if items.axis_title_x_bottom:
            self.axis_title = geometry.height(items.axis_title_x_bottom)
            m = theme.get_margin("axis_title_x_bottom").fig
            self.axis_title_margin_bottom = m.b
            self.axis_title_margin_top = m.t

        self.axis_text = items.axis_text_x_bottom
        if self.axis_text:
            m = theme.get_margin("axis_text_x_bottom").fig
            self.axis_text_margin_bottom = m.b
            self.axis_text_margin_top = m.t
        self.axis_ticks = items.axis_ticks_x_bottom
        self.strip_text = items.strip_text_x("bottom")
        self.strip_switch_pad = self._strip_switch_pad("x")

        # Adjust plot_margin to make room for ylabels that protude well
        # beyond the axes
        # NOTE: This adjustment breaks down when the protrusion is large
        protrusion = items.axis_text_y_bottom_protrusion("all")
        adjustment = protrusion - (self.total - self.plot_margin)
        if adjustment > 0:
            self.plot_margin += adjustment

    @property
    def offset(self) -> float:
        """
        Distance from bottom of the figure to the bottom of the plot gridspec

              ----------------(1, 1)
             |                |
             |      ----      |
             |     |    |     |
             |     |    |     |
             |     |    |     |
             |      ----      |
             |       ^        |
             |       |dy      |
             |       v        |
        (0, 0)----------------
        """
        return self.gridspec.bbox_relative.y0

    def y1(self, item: str) -> float:
        """
        Lower y-coordinate in figure space of the item
        """
        return self.to_figure_space(self.sum_upto(item))

    def y2(self, item: str) -> float:
        """
        Higher y-coordinate in figure space of the item
        """
        return self.to_figure_space(self.sum_incl(item))

    @property
    def panel_bottom_relative(self):
        """
        Bottom (relative to the gridspec) of the panels in figure dimensions
        """
        return self.total

    @property
    def panel_bottom(self):
        """
        Bottom of the panels in figure space
        """
        return self.to_figure_space(self.panel_bottom_relative)

    @property
    def plot_bottom(self):
        """
        Distance up to the bottom-most artist in figure space
        """
        return self.y1("legend")

    @property
    def footer_height(self):
        """
        The height of the footer including the margins
        """
        return (
            self.plot_footer_margin_bottom
            + self.plot_footer
            + self.plot_footer_margin_top
        )

    @property
    def tag_height(self):
        """
        The height of the tag including the margins
        """
        return (
            self.plot_tag_margin_bottom
            + self.plot_tag
            + self.plot_tag_margin_top
        )


class PlotSideSpaces:
    """
    Compute the all the spaces required in the layout

    These are:

    1. The space of each artist between the panel and the edge of the
       figure.
    2. The space in-between the panels

    From these values, we put together the grid-spec parameters required
    by matplotblib to position the axes. We also use the values to adjust
    the coordinates of all the artists that occupy these spaces, placing
    them in their final positions.
    """

    W: float
    """Figure Width [inches]"""

    H: float
    """Figure Height [inches]"""

    w: float
    """Axes width w.r.t figure in [0, 1]"""

    h: float
    """Axes height w.r.t figure in [0, 1]"""

    sh: float
    """horizontal spacing btn panels w.r.t figure"""

    sw: float
    """vertical spacing btn panels w.r.t figure"""

    def __init__(self, plot: ggplot):
        self.plot = plot
        self.gridspec = plot._gridspec
        self.sub_gridspec = plot._sub_gridspec
        items_cls = (
            PolarPlotLayoutItems
            if isinstance(plot.coordinates, coord_radial)
            else PlotLayoutItems
        )
        self.items = items_cls(plot)

        self.l = left_space(self.items)
        """All subspaces to the left of the panels"""

        self.r = right_space(self.items)
        """All subspaces to the right of the panels"""

        self.t = top_space(self.items)
        """All subspaces above the top of the panels"""

        self.b = bottom_space(self.items)
        """All subspaces below the bottom of the panels"""

        self.W, self.H = plot.theme.getp("figure_size")

        self.axis_title_span: dict[Side, PanelSpan] = {}
        """
        Combined panel bounds for each collected axis title, keyed by side

        The mapping is empty when the plot retains no collected title.
        """

    @property
    def owner(self) -> ggplot:
        """
        The plot these side-spaces are calculated against
        """
        return self.plot

    def arrange(self):
        """
        Resize plot and place artists in final positions around the panels
        """
        self.resize_gridspec()
        self.items._move_artists(self)
        self._arrange_insets()

    def _arrange_insets(self):
        """
        Position and arrange every inset attached to this plot

        The host's panel/plot/full region is now finalised, so the
        inset's fractional bounding box is scaled into figure
        coordinates. For ggplot / Compose insets the bbox drives the
        inset's gridspec and its side-space layout runs to position
        its content. For image insets the adapter's `_arrange_in_box`
        does the aspect-fit math directly — no gridspec or side-space
        work needed.
        """
        from plotnine import ggplot
        from plotnine.composition import Compose
        from plotnine.composition._inset_image import _InsetImage

        from ._composition_side_space import CompositionSideSpaces

        for inset in self.plot._insets:
            if inset.align_to == "panel":
                (x1, y1), (x2, y2) = self.panel_area_coordinates
            elif inset.align_to == "plot":
                (x1, y1), (x2, y2) = self.plot_area_coordinates
            elif inset.align_to == "footer":
                if not self.plot.labels.get("footer", ""):
                    continue

                (x1, y1), (x2, y2) = self.footer_area_coordinates
            else:  # "full"
                # Note that this isn't necessarily the figure's coordinates,
                # rather the entire ggplot area.
                bbox = self.plot._gridspec.bbox_relative
                (x1, y1), (x2, y2) = (bbox.x0, bbox.y0), (bbox.x1, bbox.y1)

            left = x1 + inset.left * (x2 - x1)
            bottom = y1 + inset.bottom * (y2 - y1)
            right = x1 + inset.right * (x2 - x1)
            top = y1 + inset.top * (y2 - y1)

            if isinstance(inset.obj, (ggplot, Compose)):
                params = GridSpecParams(
                    left=left,
                    bottom=bottom,
                    right=right,
                    top=top,
                    wspace=0,
                    hspace=0,
                )
                inset.obj._gridspec.update_params_and_artists(params)
                if isinstance(inset.obj, ggplot):
                    inset.obj._sidespaces = PlotSideSpaces(inset.obj)
                else:
                    inset.obj._sidespaces = CompositionSideSpaces(inset.obj)
                inset.obj._sidespaces.arrange()
            elif isinstance(inset.obj, _InsetImage):
                inset.obj._arrange_in_box(left, bottom, right, top)

    def resize_gridspec(self):
        """
        Apply the space calculations to the sub_gridspec

        After calling this method, the sub_gridspec will be appropriately
        sized to accommodate the artists around the panels.
        """
        gsparams = self.calculate_gridspec_params()
        self.sub_gridspec.update_params_and_artists(gsparams)

    def calculate_gridspec_params(self) -> GridSpecParams:
        """
        Grid spacing between panels w.r.t figure
        """
        gsparams = self._calculate_panel_spacing()

        # Adjust the spacing parameters for the desired aspect ratio
        # It is simpler to adjust for the aspect ratio than to calculate
        # the final parameters that are true to the aspect ratio in
        # one-short
        if (ratio := self.plot.built.facet._aspect_ratio()) is not None:
            current_ratio = self.aspect_ratio
            if ratio > current_ratio:
                # Increase aspect ratio, taller panels
                gsparams = self._reduce_width(gsparams, ratio)
            elif ratio < current_ratio:
                # Increase aspect ratio, wider panels
                gsparams = self._reduce_height(gsparams, ratio)

        return gsparams

    @property
    def plot_width(self) -> float:
        """
        Width [figure dimensions] of the whole plot
        """
        return float(self.gridspec.width)

    @property
    def plot_height(self) -> float:
        """
        Height [figure dimensions] of the whole plot
        """
        return float(self.gridspec.height)

    @property
    def panel_width(self) -> float:
        """
        Width [figure dimensions] of panels
        """
        return self.r.panel_right - self.l.panel_left

    @property
    def panel_height(self) -> float:
        """
        Height [figure dimensions] of panels
        """
        return self.t.panel_top - self.b.panel_bottom

    @property
    def plot_left(self) -> float:
        return self.l.plot_left

    @property
    def plot_right(self) -> float:
        return self.r.plot_right

    @property
    def plot_bottom(self) -> float:
        return self.b.plot_bottom

    @property
    def plot_top(self) -> float:
        return self.t.plot_top

    @property
    def panel_left(self) -> float:
        return self.l.panel_left

    @property
    def panel_right(self) -> float:
        return self.r.panel_right

    @property
    def panel_bottom(self) -> float:
        return self.b.panel_bottom

    @property
    def panel_top(self) -> float:
        return self.t.panel_top

    @property
    def horizontal_space(self) -> float:
        """
        Horizontal non-panel space [figure dimensions]
        """
        # The same as plot_width - panel_width
        return self.l.total + self.r.total

    @property
    def vertical_space(self) -> float:
        """
        Vertical non-panel space [figure dimensions]
        """
        # The same as plot_height - panel_height
        return self.t.total + self.b.total

    def increase_horizontal_plot_margin(self, dw: float):
        """
        Increase the plot_margin to the right & left of the panels
        """
        self.l.plot_margin += dw
        self.r.plot_margin += dw

    def increase_vertical_plot_margin(self, dh: float):
        """
        Increase the plot_margin to the above & below of the panels
        """
        self.t.plot_margin += dh
        self.b.plot_margin += dh

    @property
    def plot_area_coordinates(
        self,
    ) -> tuple[tuple[float, float], tuple[float, float]]:
        """
        Lower-left and upper-right coordinates of the plot area

        This is the area surrounded by the plot_margin.
        """
        x1, x2 = self.l.x2("plot_margin"), self.r.x1("plot_margin")
        y1, y2 = self.b.y2("plot_margin"), self.t.y1("plot_margin")
        return ((x1, y1), (x2, y2))

    @property
    def panel_area_coordinates(
        self,
    ) -> tuple[tuple[float, float], tuple[float, float]]:
        """
        Lower-left and upper-right coordinates of the panel area

        This is the area in which the panels are drawn.
        """
        x1, x2 = self.l.panel_left, self.r.panel_right
        y1, y2 = self.b.panel_bottom, self.t.panel_top
        return ((x1, y1), (x2, y2))

    @property
    def footer_area_coordinates(
        self,
    ) -> tuple[tuple[float, float], tuple[float, float]]:
        """
        Lower-left and upper-right coordinates of the footer band

        This is the strip reserved at the bottom of the figure for the
        plot footer text and its margins. It spans the full plot width.
        It has zero height when there is no footer text.
        """
        # Full plot width, matching where the footer background is drawn
        x1 = self.l.offset
        x2 = self.l.offset + self.plot_width
        y1 = self.b.offset
        y2 = self.b.offset + self.b.footer_height
        return ((x1, y1), (x2, y2))

    def _calculate_panel_spacing(self) -> GridSpecParams:
        """
        Spacing between the panels (wspace & hspace)

        Both spaces are calculated from a fraction of the width.
        This ensures that the same fraction gives equals space
        in both directions.
        """
        facet = self.plot.built.facet
        if isinstance(facet, facet_wrap):
            wspace, hspace = self._calculate_panel_spacing_facet_wrap()
        elif isinstance(facet, facet_grid):
            wspace, hspace = self._calculate_panel_spacing_facet_grid()
        elif isinstance(facet, facet_null):
            wspace, hspace = self._calculate_panel_spacing_facet_null()
        else:
            raise TypeError(f"Unknown type of facet: {type(facet)}")

        return GridSpecParams(
            self.l.panel_left_relative,
            self.r.panel_right_relative,
            self.t.panel_top_relative,
            self.b.panel_bottom_relative,
            wspace,
            hspace,
        )

    def _polar_gulley_clearance(self) -> tuple[float, float]:
        """
        Extra gulley space a polar panel's decorations need, `(sw, sh)`

        A polar panel draws its full theta and r axes on every panel,
        not just the ones on the grid's edge, so their ticks and labels
        reach into the gulleys on all four sides. Reserve room for both
        the left and right decorations in the horizontal gulley and the
        top and bottom decorations in the vertical one. As on the
        Cartesian free-scale path, the tick-label extent is bare and the
        tick-label margin is added here.
        """
        items = self.items
        theme = self.plot.theme
        sw = 0.0
        for side in ("left", "right"):
            text = items.axis_text_y_max_width_at("all", side)
            if text:
                m = theme.get_margin(f"axis_text_y_{side}").fig
                text += m.l + m.r
            sw += text + items.axis_ticks_y_max_width_at("all", side)
        sh = 0.0
        for side in ("top", "bottom"):
            text = items.axis_text_x_max_height_at("all", side)
            if text:
                m = theme.get_margin(f"axis_text_x_{side}").fig
                text += m.t + m.b
            sh += text + items.axis_ticks_x_max_height_at("all", side)
        return sw, sh

    def _calculate_panel_spacing_facet_grid(self) -> tuple[float, float]:
        """
        Calculate spacing parts for facet_grid
        """
        theme = self.plot.theme

        ncol = self.plot.built.facet.ncol
        nrow = self.plot.built.facet.nrow

        # Both spacings are specified as fractions of the figure width
        # Multiply the vertical by (W/H) so that the gullies along both
        # directions are equally spaced.
        self.sw = theme.getp("panel_spacing_x")
        self.sh = theme.getp("panel_spacing_y") * self.W / self.H

        if isinstance(self.plot.coordinates, coord_radial):
            extra_sw, extra_sh = self._polar_gulley_clearance()
            self.sw += extra_sw
            self.sh += extra_sh

        # width and height of axes as fraction of figure width & height
        self.w = (self.panel_width - self.sw * (ncol - 1)) / ncol
        self.h = (self.panel_height - self.sh * (nrow - 1)) / nrow

        # Spacing as fraction of axes width & height
        wspace = self.sw / self.w
        hspace = self.sh / self.h
        return (wspace, hspace)

    def _calculate_panel_spacing_facet_wrap(self) -> tuple[float, float]:
        """
        Calculate spacing parts for facet_wrap
        """
        facet = cast("facet_wrap", self.plot.built.facet)
        theme = self.plot.theme

        ncol = facet.ncol
        nrow = facet.nrow

        # Both spacings are specified as fractions of the figure width
        self.sw = theme.getp("panel_spacing_x")
        self.sh = theme.getp("panel_spacing_y") * self.W / self.H

        # The strip (plus any switch pad) claims space in the gullies on
        # the side it is placed. The side space's strip_text folds in
        # strip_align_{x,y} and is zero when the strip is fully inside
        # the panel.
        space = {
            "top": self.t,
            "bottom": self.b,
            "left": self.l,
            "right": self.r,
        }[facet.strip_position]
        if facet.strip_position in ("top", "bottom"):
            self.sh += space.strip_text + space.strip_switch_pad
        else:
            self.sw += space.strip_text + space.strip_switch_pad

        # A polar panel draws its full theta and r axes on every panel,
        # so its decorations reach into the gullies regardless of free.
        # A cartesian panel only shows them on the grid's edge, so per-panel
        # axes claim gulley space only where the scales are free.
        if isinstance(self.plot.coordinates, coord_radial):
            extra_sw, extra_sh = self._polar_gulley_clearance()
            self.sw += extra_sw
            self.sh += extra_sh
        else:
            if facet.free["x"]:
                for side in ("bottom", "top"):
                    text = self.items.axis_text_x_max_height_at("all", side)
                    if text:
                        m = theme.get_margin(f"axis_text_x_{side}").fig
                        text += m.t + m.b
                    self.sh += text + self.items.axis_ticks_x_max_height_at(
                        "all", side
                    )
            if facet.free["y"]:
                for side in ("left", "right"):
                    text = self.items.axis_text_y_max_width_at("all", side)
                    if text:
                        m = theme.get_margin(f"axis_text_y_{side}").fig
                        text += m.l + m.r
                    self.sw += text + self.items.axis_ticks_y_max_width_at(
                        "all", side
                    )

        # width and height of axes as fraction of figure width & height
        self.w = (self.panel_width - self.sw * (ncol - 1)) / ncol
        self.h = (self.panel_height - self.sh * (nrow - 1)) / nrow

        # Spacing as fraction of axes width & height
        wspace = self.sw / self.w
        hspace = self.sh / self.h
        return (wspace, hspace)

    def _calculate_panel_spacing_facet_null(self) -> tuple[float, float]:
        """
        Calculate spacing parts for facet_null
        """
        self.w = self.panel_width
        self.h = self.panel_height
        self.sw = 0
        self.sh = 0
        return 0, 0

    def _reduce_height(self, gsparams: GridSpecParams, ratio: float):
        """
        Reduce the height of axes to get the aspect ratio
        """
        # New height w.r.t figure height
        h1 = ratio * self.w * (self.W / self.H)

        # Half of the total vertical reduction w.r.t figure height
        dh = (self.h - h1) * self.plot.built.facet.nrow / 2

        # Add more vertical plot margin
        self.increase_vertical_plot_margin(dh)

        return replace(
            gsparams,
            top=gsparams.top - dh,
            bottom=gsparams.bottom + dh,
            hspace=self.sh / h1,
        )

    def _reduce_width(self, gsparams: GridSpecParams, ratio: float):
        """
        Reduce the width of axes to get the aspect ratio
        """
        # New width w.r.t figure width
        w1 = (self.h * self.H) / (ratio * self.W)

        # Half of the total horizontal reduction w.r.t figure width
        dw = (self.w - w1) * self.plot.built.facet.ncol / 2

        # Add more horizontal margin
        self.increase_horizontal_plot_margin(dw)

        return replace(
            gsparams,
            left=gsparams.left + dw,
            right=gsparams.right - dw,
            wspace=self.sw / w1,
        )

    @property
    def aspect_ratio(self) -> float:
        """
        Default aspect ratio of the panels
        """
        return (self.h * self.H) / (self.w * self.W)

    @cached_property
    def gs(self) -> p9GridSpec:
        """
        The gridspec
        """
        return self.plot._gridspec

    def to_figure_space(
        self,
        position: tuple[float, float],
    ) -> tuple[float, float]:
        """
        Convert position from gridspec space to figure space
        """
        _x, _y = position
        x = self.l.plot_left + (self.r.plot_right - self.l.plot_left) * _x
        y = self.b.plot_bottom + (self.t.plot_top - self.b.plot_bottom) * _y
        return (x, y)
