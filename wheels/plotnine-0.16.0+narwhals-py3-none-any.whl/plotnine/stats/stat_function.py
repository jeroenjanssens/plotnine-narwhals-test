from __future__ import annotations

import typing

import numpy as np

from .._utils import frame
from ..doctools import document
from ..exceptions import PlotnineError
from ..mapping.evaluation import after_stat
from ..scales.scale_continuous import scale_continuous
from .stat import stat

if typing.TYPE_CHECKING:
    from typing import Any, Callable

    from plotnine.typing import FloatArrayLike


@document
class stat_function(stat):
    """
    Superimpose a function onto a plot

    {usage}

    Parameters
    ----------
    {common_parameters}
    fun : callable
        Function to evaluate.
    n : int, default=101
        Number of points at which to evaluate the function.
    xlim : tuple, default=None
        `x` limits for the range. The default depends on
        the `x` aesthetic. There is not an `x` aesthetic
        then the `xlim` must be provided.
    args : Optional[tuple[Any] | dict[str, Any]], default=None
        Arguments to pass to `fun`.

    See Also
    --------
    plotnine.geom_path : The default `geom` for this `stat`.
    """

    _aesthetics_doc = """
    {aesthetics_table}

    **Options for computed aesthetics**

    ```python
    "x"   # x points at which the function is evaluated
    "fx"  # points evaluated at each x
    ```

    """

    DEFAULT_PARAMS = {
        "geom": "path",
        "fun": None,
        "n": 101,
        "args": None,
        "xlim": None,
    }

    DEFAULT_AES = {"y": after_stat("fx")}
    CREATES = {"fx"}

    def __init__(self, mapping=None, data=None, **kwargs):
        if data is None:

            def _data_func(data: Any) -> Any:
                df = frame.to_frame(data)
                if not len(df):
                    df = frame.frame_like(df, {"group": [1]})
                return df.to_native()

            data = _data_func

        super().__init__(mapping, data, **kwargs)

    def setup_params(self, data):
        if not callable(self.params["fun"]):
            raise PlotnineError(
                "stat_function requires parameter 'fun' to be "
                "a function or any other callable object"
            )

    def compute_group(self, data, scales):
        old_fun: Callable[..., FloatArrayLike] = self.params["fun"]
        n = self.params["n"]
        args = self.params["args"]
        xlim = self.params["xlim"]
        range_x = xlim or scales.x.dimension((0, 0))

        if isinstance(args, (list, tuple)):

            def fun(x):
                return old_fun(x, *args)

        elif isinstance(args, dict):

            def fun(x):
                return old_fun(x, **args)

        elif args is not None:

            def fun(x):
                return old_fun(x, args)

        else:

            def fun(x):
                return old_fun(x)

        x = np.linspace(range_x[0], range_x[1], n)

        # continuous scale
        if isinstance(scales.x, scale_continuous):
            x = scales.x.inverse(x)

        # We know these can handle array_likes
        if isinstance(old_fun, (np.ufunc, np.vectorize)):
            fx = fun(x)
        else:
            fx = [fun(val) for val in x]

        return frame.frame_like(data, {"x": x, "fx": fx})
