from __future__ import annotations

import typing
from copy import deepcopy
from typing import Any
from warnings import warn

import narwhals as nw

from .._utils import (
    check_required_aesthetics,
    data_mapping_as_kwargs,
    frame,
    groupby_apply,
    remove_missing,
    uniquecols,
)
from .._utils.registry import Register, _MergedDefaultParams
from ..layer import layer
from ..mapping import aes

if typing.TYPE_CHECKING:
    from plotnine import ggplot
    from plotnine._utils.frame import DataFrame
    from plotnine.facets.layout import Layout
    from plotnine.iapi import pos_scales
    from plotnine.mapping import Environment
    from plotnine.typing import DataLike

from abc import ABC

DROPPED_TPL = """
The following aesthetics were dropped during processing: {dropped}.
plotnine could not infer the correct grouping.
Did you forget to specify a `group` aesthetic or to convert a numerical \
variable into a categorial?
"""


def restore_constant_columns(
    computed: DataFrame, original: DataFrame
) -> DataFrame:
    """
    Restore columns that are constant within the original group

    Carry over only original columns that have one value throughout the
    group. Preserve columns produced by the statistic. An empty result
    keeps its full schema and remains empty.

    Parameters
    ----------
    computed :
        Statistics computed for one group.
    original :
        Data of that group.
    """
    unique = uniquecols(original)
    missing = sorted(set(unique.columns) - set(computed.columns))
    if not missing:
        return computed

    restored = frame.take(unique.select(missing), [0] * len(computed))
    if not len(computed.columns):
        return restored
    return nw.concat([computed, restored], how="horizontal")


class stat(ABC, metaclass=Register):
    """Base class of all stats"""

    DEFAULT_AES: dict[str, Any] = {}
    """Default aesthetics for the stat"""

    REQUIRED_AES: set[str] = set()
    """Required aesthetics for the stat"""

    NON_MISSING_AES: set[str] = set()
    """Required aesthetics for the stat"""

    DEFAULT_PARAMS: dict[str, Any] = {
        "geom": "blank",
        "position": "identity",
        "na_rm": False,
    }
    """
    Default values for the parameters that the stat accepts

    A stat inherits the parameters of its parent stat; declare only
    those that are new or have a different default value.
    """

    DROPPED_AES: list[str] = []
    """
    Aesthetics that may be dropped during processing.

    These are typically common aesthetics that a particular stat does not use.
    If a value is mapped to any of these aesthetics, the stat may discard them
    silently (without issuing a warning).
    """

    CREATES: set[str] = set()
    """
    Stats may modify existing columns or create extra
    columns.

    Any extra columns that may be created by the stat
    should be specified in this set
    see: stat_bin

    Documentation for the aesthetics. It ie added under the
    documentation for mapping parameter. Use {aesthetics_table}
    placeholder to insert a table for all the aesthetics and
    their default values.
    """

    # All recognized parameters and their default values
    default_params = _MergedDefaultParams()

    _aesthetics_doc = "{aesthetics_table}"

    # Plot namespace, it gets its value when the plot is being
    # built.
    environment: Environment

    def __init__(
        self,
        mapping: aes | None = None,
        data: DataLike | None = None,
        **kwargs: Any,
    ):
        kwargs = data_mapping_as_kwargs((data, mapping), kwargs)
        self._raw_kwargs = kwargs  # Will be used to create the geom
        overridden_params = self.default_params.keys() & kwargs.keys()
        self.params = {
            **self.default_params,
            **{k: kwargs[k] for k in overridden_params},
        }
        self.DEFAULT_AES = aes(**self.DEFAULT_AES)
        self.aes_params = {
            ae: kwargs[ae] for ae in self.aesthetics() & set(kwargs)
        }

    def __deepcopy__(self, memo: dict[Any, Any]) -> stat:
        """
        Deep copy without copying the self.data dataframe

        stats should not override this method.
        """
        cls = self.__class__
        result = cls.__new__(cls)
        memo[id(self)] = result
        old = self.__dict__
        new = result.__dict__

        # don't make a _raw_kwargs
        shallow = {"_raw_kwargs"}
        for key, item in old.items():
            if key in shallow:
                new[key] = item  # pyright: ignore[reportIndexIssue]
                memo[id(new[key])] = new[key]
            else:
                new[key] = deepcopy(item, memo)  # pyright: ignore[reportIndexIssue]

        return result

    @classmethod
    def aesthetics(cls) -> set[str]:
        """
        Return a set of all non-computed aesthetics for this stat.

        stats should not override this method.
        """
        aesthetics = cls.REQUIRED_AES.copy()
        calculated = aes(**cls.DEFAULT_AES)._calculated
        for ae in set(cls.DEFAULT_AES) - set(calculated):
            aesthetics.add(ae)
        return aesthetics

    def use_defaults(self, data: DataFrame) -> DataFrame:
        """
        Combine data with defaults and set aesthetics from parameters

        stats should not override this method.

        Parameters
        ----------
        data :
            Data used for drawing the geom.

        Returns
        -------
        out :
            Data used for drawing the geom.
        """
        missing = (
            self.aesthetics() - set(self.aes_params.keys()) - set(data.columns)
        )

        defaults = {
            ae: self.DEFAULT_AES[ae]
            for ae in sorted(missing - self.REQUIRED_AES)
            if self.DEFAULT_AES[ae] is not None
        }
        return frame.assign(data, **defaults, **self.aes_params)

    def setup_params(self, data: DataFrame):
        """
        Override this to verify and/or adjust parameters

        Parameters
        ----------
        data :
            Data

        Returns
        -------
        out :
            Parameters used by the stats.
        """

    def setup_data(self, data: DataFrame) -> DataFrame:
        """
        Override to modify data before compute_layer is called

        Parameters
        ----------
        data :
            Data

        Returns
        -------
        out :
            Data
        """
        return data

    def finish_layer(self, data: DataFrame) -> DataFrame:
        """
        Modify data after the aesthetics have been mapped

        This can be used by stats that require access to the mapped
        values of the computed aesthetics, part 3 as shown below.

            1. stat computes and creates variables
            2. variables mapped to aesthetics
            3. stat sees and modifies data according to the
               aesthetic values

        The default to is to do nothing.

        Parameters
        ----------
        data :
            Data for the layer
        params :
            Parameters

        Returns
        -------
        data :
            Modified data
        """
        return data

    def compute_layer(self, data: DataFrame, layout: Layout) -> DataFrame:
        """
        Calculate statistics for this layers

        This is the top-most computation method for the
        stat. It does not do any computations, but it
        knows how to verify the data, partition it call the
        next computation method and merge results.

        Override this method only when a statistic must compute across the
        full layer. Preserve standard validation and grouping by calling
        the base implementation before or after the layer-wide work.

        Parameters
        ----------
        data :
            Data points for all objects in a layer.
        layout :
            Panel layout information
        """
        check_required_aesthetics(
            self.REQUIRED_AES,
            list(data.columns) + list(self.params.keys()),
            self.__class__.__name__,
        )

        data = remove_missing(
            data,
            na_rm=self.params.get("na_rm", False),
            vars=list(self.REQUIRED_AES | self.NON_MISSING_AES),
            name=self.__class__.__name__,
            finite=True,
        )

        def fn(pdata):
            """
            Compute function helper
            """
            # Given data belonging to a specific panel, grab
            # the corresponding scales and call the method
            # that does the real computation
            if len(pdata) == 0:
                return pdata
            pscales = layout.get_scales(pdata["PANEL"].item(0))
            return as_frame_of(self.compute_panel(pdata, pscales), pdata)

        return groupby_apply(data, "PANEL", fn)

    def compute_panel(self, data: DataFrame, scales: pos_scales) -> DataFrame:
        """
        Calculate the statistics for all the groups

        Return the results in a single dataframe.

        This is a default function that can be overridden
        by individual stats

        Parameters
        ----------
        data :
            data for the computing
        scales :
            x (``scales.x``) and y (``scales.y``) scale objects.
            The most likely reason to use scale information is
            to find out the physical size of a scale. e.g.

            ```python
            range_x = scales.x.dimension()
            ```
        params :
            The parameters for the stat. It includes default
            values if user did not set a particular parameter.
        """
        if not len(data):
            return frame.empty_like(data)

        stats = []
        for _, old in frame.group_split(data, "group"):
            new = as_frame_of(self.compute_group(old, scales), old)
            stats.append(restore_constant_columns(new, old))

        stats = frame.concat(stats)
        dropped = sorted(
            set(data.columns) - (set(stats.columns) | set(self.DROPPED_AES))
        )
        if dropped:
            warn(DROPPED_TPL.format(dropped=dropped))
        # Note: If the data coming in has columns with non-unique
        # values with-in group(s), this implementation loses the
        # columns. Individual stats may want to do some preparation
        # before then fall back on this implementation or override
        # it completely.
        return stats

    def compute_group(self, data: DataFrame, scales: pos_scales) -> DataFrame:
        """
        Calculate statistics for the group

        All stats should implement this method

        Parameters
        ----------
        data :
            Data for a group
        scales :
            x (``scales.x``) and y (``scales.y``) scale objects.
            The most likely reason to use scale information is
            to find out the physical size of a scale. e.g.

            ```python
            range_x = scales.x.dimension()
            ```
        params :
            Parameters
        """
        msg = "{} should implement this method."
        raise NotImplementedError(msg.format(self.__class__.__name__))

    def __radd__(self, other: ggplot) -> ggplot:
        """
        Add layer representing stat object on the right

        Parameters
        ----------
        other :
            ggplot object

        Returns
        -------
        out :
            ggplot object with added layer
        """
        other += layer(stat=self)
        return other


def as_frame_of(result: Any, data: DataFrame) -> DataFrame:
    """
    Make the result of a computation a dataframe of the same library

    Stats (e.g. those in other packages) may return dataframes of
    another library.
    """
    return frame.convert(frame.to_frame(result), data.implementation)
