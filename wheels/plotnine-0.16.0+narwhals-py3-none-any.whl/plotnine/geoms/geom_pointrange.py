from __future__ import annotations

import typing
from copy import copy

import narwhals as nw

from ..doctools import document
from .geom import geom
from .geom_linerange import geom_linerange
from .geom_path import geom_path
from .geom_point import geom_point

if typing.TYPE_CHECKING:
    from typing import Any

    from matplotlib.axes import Axes
    from matplotlib.offsetbox import DrawingArea

    from plotnine._utils.frame import DataFrame
    from plotnine.coords.coord import coord
    from plotnine.iapi import panel_view
    from plotnine.layer import layer


@document
class geom_pointrange(geom):
    """
    Vertical interval represented by a line with a point

    {usage}

    Parameters
    ----------
    {common_parameters}
    fatten : float, default=2
        A multiplicative factor used to increase the size of the
        point along the line-range.
    """

    DEFAULT_AES = {
        "alpha": 1,
        "color": "black",
        "fill": None,
        "linetype": "solid",
        "shape": "o",
        "size": 0.5,
    }
    REQUIRED_AES = {"x", "y", "ymin", "ymax"}
    DEFAULT_PARAMS = {"fatten": 4}

    @staticmethod
    def draw_group(
        data: DataFrame,
        panel_params: panel_view,
        coord: coord,
        ax: Axes,
        params: dict[str, Any],
    ):
        geom_linerange.draw_group(data, panel_params, coord, ax, params)
        data = data.with_columns(
            size=nw.col("size") * params["fatten"],
            stroke=nw.lit(geom_point.DEFAULT_AES["stroke"]),
        )
        geom_point.draw_group(data, panel_params, coord, ax, params)

    @staticmethod
    def draw_legend(
        data: dict[str, Any], da: DrawingArea, lyr: layer
    ) -> DrawingArea:
        """
        Draw a point in the box

        Parameters
        ----------
        data : Series
            Data Row
        da : DrawingArea
            Canvas
        lyr : layer
            Layer

        Returns
        -------
        out : DrawingArea
        """
        geom_path.draw_legend(data, da, lyr)
        data["size"] = data["size"] * lyr.geom.params["fatten"]
        data["stroke"] = geom_point.DEFAULT_AES["stroke"]
        geom_point.draw_legend(data, da, lyr)
        return da

    @staticmethod
    def legend_key_size(
        data: dict[str, Any], min_size: tuple[int, int], lyr: layer
    ) -> tuple[int, int]:
        data = copy(data)
        data["size"] = data["size"] * lyr.geom.params["fatten"]
        data["stroke"] = geom_point.DEFAULT_AES["stroke"]
        return geom_point.legend_key_size(data, min_size, lyr)
