from __future__ import annotations

import typing

import narwhals as nw

from .._utils import SIZE_FACTOR, frame, to_rgba
from ..doctools import document
from ..exceptions import PlotnineError
from .geom import geom
from .geom_path import stroke_paths
from .geom_polygon import geom_polygon

if typing.TYPE_CHECKING:
    from typing import Any

    from matplotlib.axes import Axes

    from plotnine._utils.frame import DataFrame
    from plotnine.coords.coord import coord
    from plotnine.iapi import panel_view
    from plotnine.typing import ColorsLike


@document
class geom_ribbon(geom):
    """
    Ribbon plot

    {usage}

    Parameters
    ----------
    {common_parameters}
    outline_type : Literal["upper", "lower", "both", "full"], default="both"
        How to stroke to outline of the region / area.
        If `upper`, draw only upper bounding line.
        If `lower`, draw only lower bounding line.
        If `both`, draw both upper & lower bounding lines.
        If `full`, draw closed polygon around the area.
    """

    _aesthetics_doc = """
    {aesthetics_table}

    **Aesthetics Descriptions**

    `where`

    :   Define where to exclude horizontal regions from being filled.
        Regions between any two `False` values are skipped.
        For sensible demarcation the value used in the *where* predicate
        expression should match the `ymin` value or expression. i.e.

        ```python
         aes(ymin=0, ymax="col1", where="col1 > 0")  # good
         aes(ymin=0, ymax="col1", where="col1 > 10")  # bad

         aes(ymin=col2, ymax="col1", where="col1 > col2")  # good
         aes(ymin=col2, ymax="col1", where="col1 > col3")  # bad
        ```
    """
    DEFAULT_AES = {
        "alpha": 1,
        "color": "none",
        "fill": "#333333",
        "linetype": "solid",
        "size": 0.5,
        "where": True,
    }
    REQUIRED_AES = {"x", "ymax", "ymin"}
    DEFAULT_PARAMS = {"outline_type": "both"}
    draw_legend = staticmethod(geom_polygon.draw_legend)

    def handle_na(self, data: DataFrame) -> DataFrame:
        return data

    def setup_data(self, data: DataFrame) -> DataFrame:
        if "xmax" in data.columns and "x" not in data.columns:
            data = data.with_columns(x=nw.col("xmax"))
        if "ymax" in data.columns and "y" not in data.columns:
            data = data.with_columns(y=nw.col("ymax"))
        return data

    @staticmethod
    def draw_group(
        data: DataFrame,
        panel_params: panel_view,
        coord: coord,
        ax: Axes,
        params: dict[str, Any],
    ):
        _x = "x" if coord.preserves_dimensions else "y"
        data = coord.transform(data, panel_params, munch=True)
        data = frame.sort(data, ["group", _x])

        units = ["alpha", "color", "fill", "linetype", "size"]
        if len(frame.unique_rows(data, units)) > 1:
            msg = "Aesthetics cannot vary within a ribbon."
            raise PlotnineError(msg)

        if len(data):
            geom_ribbon.draw_unit(data, panel_params, coord, ax, params)

    @staticmethod
    def draw_unit(
        data: DataFrame,
        panel_params: panel_view,
        coord: coord,
        ax: Axes,
        params: dict[str, Any],
    ):
        linewidth = data["size"].item(0) * SIZE_FACTOR
        fill = to_rgba(data["fill"], data["alpha"])

        if frame.isna(data["color"]).all():
            color: ColorsLike = "none"
        else:
            color = data["color"].to_list()

        if fill is None:
            fill = "none"

        if coord.preserves_dimensions:
            fill_between = ax.fill_between
            _x, _min, _max = (
                frame.to_numpy(data[c]) for c in ("x", "ymin", "ymax")
            )
        else:
            fill_between = ax.fill_betweenx
            _x, _min, _max = (
                frame.to_numpy(data[c]) for c in ("y", "xmin", "xmax")
            )

        # We only change this defaults for fill_between when necessary
        if "where" in data.columns:
            where = frame.to_numpy(data["where"])
            interpolate = not where.all()
        else:
            where, interpolate = None, False

        if params["outline_type"] != "full":
            linewidth = 0
            color = "none"

        fill_between(
            _x,
            _min,
            _max,
            where=where,
            interpolate=interpolate,
            facecolor=fill,
            edgecolor=color,
            linewidth=linewidth,
            linestyle=data["linetype"].item(0),
            zorder=params["zorder"],
            rasterized=params["raster"],
        )

        # Alpha does not affect the outlines
        data = data.with_columns(alpha=nw.lit(1))
        geom_ribbon._draw_outline(data, coord, ax, params)

    @staticmethod
    def _draw_outline(
        data: DataFrame,
        coord: coord,
        ax: Axes,
        params: dict[str, Any],
    ):
        outline_type = params["outline_type"]

        if outline_type == "full":
            return

        bounds = "y" if coord.preserves_dimensions else "x"

        if outline_type in ("lower", "both"):
            lower = data.with_columns(nw.col(f"{bounds}min").alias(bounds))
            stroke_paths(lower, ax, params, constant=True)

        if outline_type in ("upper", "both"):
            upper = data.with_columns(nw.col(f"{bounds}max").alias(bounds))
            stroke_paths(upper, ax, params, constant=True)
