from __future__ import annotations

import typing

import numpy as np

from .._utils import SIZE_FACTOR, frame, to_rgba
from ..doctools import document
from ..exceptions import PlotnineError
from .geom import geom
from .geom_point import geom_point
from .geom_polygon import geom_polygon

if typing.TYPE_CHECKING:
    from typing import Any

    import numpy.typing as npt
    from matplotlib.axes import Axes
    from matplotlib.offsetbox import DrawingArea
    from matplotlib.patches import PathPatch
    from shapely.geometry.polygon import LinearRing, Polygon

    from plotnine import aes
    from plotnine._utils.frame import DataFrame
    from plotnine.coords.coord import coord
    from plotnine.iapi import panel_view
    from plotnine.layer import layer
    from plotnine.typing import DataLike


@document
class geom_map(geom):
    """
    Draw map feature

    {usage}

    The map feature are drawn without any special projections.

    Parameters
    ----------
    {common_parameters}

    Notes
    -----
    This geom is best suited for plotting a shapefile read into
    geopandas dataframe. The dataframe should have a `geometry`
    column.
    """

    DEFAULT_AES = {
        "alpha": 1,
        "color": "#111111",
        "fill": "#333333",
        "linetype": "solid",
        "shape": "o",
        "size": 0.5,
        "stroke": 0.5,
    }
    REQUIRED_AES = {"geometry"}

    def __init__(
        self,
        mapping: aes | None = None,
        data: DataLike | None = None,
        **kwargs: Any,
    ):
        geom.__init__(self, mapping, data, **kwargs)
        # Almost all geodataframes loaded from shapefiles
        # have a geometry column.
        if "geometry" not in self.mapping:
            self.mapping["geometry"] = "geometry"

    def setup_data(self, data: DataFrame) -> DataFrame:
        if not len(data):
            return data

        # Remove any NULL geometries, and remember
        # All the non-Null shapes in a shapefile are required to be
        # of the same shape type.
        bool_idx = np.array(
            [g is not None for g in data["geometry"].to_list()]
        )
        if not np.all(bool_idx):
            data = frame.filter_rows(data, bool_idx)

        # Add polygon limits. Scale training uses them
        bounds = np.array(
            [g.bounds for g in data["geometry"].to_list()], dtype=float
        ).reshape(-1, 4)
        return frame.assign(
            data,
            xmin=bounds[:, 0],
            ymin=bounds[:, 1],
            xmax=bounds[:, 2],
            ymax=bounds[:, 3],
        )

    def draw_panel(
        self,
        data: DataFrame,
        panel_params: panel_view,
        coord: coord,
        ax: Axes,
    ):
        if not len(data):
            return

        params = self.params

        def missing_as_none(col: str) -> list[Any]:
            values = data[col].to_list()
            missing = frame.isna(data[col])
            return ["none" if na else v for v, na in zip(values, missing)]

        data = frame.assign(
            data, color=missing_as_none("color"), fill=missing_as_none("fill")
        )
        geometries = data["geometry"].to_list()
        geom_type = geometries[0].geom_type

        if geom_type in ("Polygon", "MultiPolygon"):
            from matplotlib.collections import PatchCollection

            linewidth = frame.to_numpy(data["size"]) * SIZE_FACTOR
            fill = to_rgba(data["fill"], data["alpha"])
            patches = [PolygonPatch(g) for g in geometries]
            coll = PatchCollection(
                patches,
                edgecolor=data["color"].to_list(),
                facecolor=fill,
                linestyle=data["linetype"].to_list(),
                linewidth=linewidth,
                zorder=params["zorder"],
                rasterized=params["raster"],
            )
            ax.add_collection(coll)
        elif geom_type == "Point":
            # Extract point coordinates from shapely geom
            # and plot with geom_point
            arr = np.array([list(g.coords)[0] for g in geometries])
            data = frame.assign(data, x=arr[:, 0], y=arr[:, 1])
            for _, gdata in frame.group_split(data, "group"):
                geom_point.draw_group(gdata, panel_params, coord, ax, params)
        elif geom_type == "MultiPoint":
            # Where n is the length of the dataframe (no. of multipoints),
            #       m is the number of all points in all multipoints
            #
            # - MultiPoint -> List of Points (tuples) (n -> m)
            # - Explode the list, to create a dataframe were each point
            #      is associated with the right aesthetics (n -> m)
            # - Create x & y columns from the points (m -> m)
            points = [[p.coords[0] for p in mp.geoms] for mp in geometries]
            idx = [i for i, pts in enumerate(points) for _ in pts]
            xy = np.array([p for pts in points for p in pts]).reshape(-1, 2)
            data = frame.assign(frame.take(data, idx), x=xy[:, 0], y=xy[:, 1])
            geom_point.draw_group(data, panel_params, coord, ax, params)
        elif geom_type in ("LineString", "MultiLineString"):
            from matplotlib.collections import LineCollection

            linewidth = frame.to_numpy(data["size"]) * SIZE_FACTOR
            color = to_rgba(data["color"], data["alpha"])
            segments = []
            for g in geometries:
                if g.geom_type == "LineString":
                    segments.append(g.coords)
                else:
                    segments.extend(_g.coords for _g in g.geoms)

            coll = LineCollection(
                segments,
                edgecolor=color,
                linewidth=linewidth,
                linestyle=data["linetype"].to_list(),
                zorder=params["zorder"],
                rasterized=params["raster"],
            )
            ax.add_collection(coll)
        else:
            raise TypeError(f"Could not plot geometry of type '{geom_type}'")

    @staticmethod
    def draw_legend(
        data: dict[str, Any], da: DrawingArea, lyr: layer
    ) -> DrawingArea:
        """
        Draw a rectangle in the box

        Parameters
        ----------
        data : Series
            Data Row
        da : DrawingArea
            Canvas
        lyr : layer
            Layer

        Returns
        -------
        out : DrawingArea
        """
        data["size"] = data["stroke"]
        del data["stroke"]
        return geom_polygon.draw_legend(data, da, lyr)


def PolygonPatch(
    obj: Polygon,
) -> PathPatch:
    """
    Return a Matplotlib patch from a Polygon/MultiPolygon Geometry

    Parameters
    ----------
    obj : shapley.geometry.Polygon | shapley.geometry.MultiPolygon
        A Polygon or MultiPolygon to create a patch for description

    Returns
    -------
    result : matplotlib.patches.PathPatch
        A patch representing the shapely geometry

    Notes
    -----
    This functionality was originally provided by the descartes package
    by Sean Gillies (BSD license, https://pypi.org/project/descartes)
    which is nolonger being maintained.
    """
    from matplotlib.patches import PathPatch
    from matplotlib.path import Path

    def cw_coords(ring: LinearRing) -> npt.NDArray[Any]:
        """
        Return Clockwise array coordinates

        Parameters
        ----------
        ring: shapely.geometry.polygon.LinearRing
            LinearRing

        Returns
        -------
        out: ndarray
            (n x 2) array of coordinate points.
        """
        if ring.is_ccw:
            return np.asarray(ring.coords)[:, :2][::-1]
        return np.asarray(ring.coords)[:, :2]

    def ccw_coords(ring: LinearRing) -> npt.NDArray[Any]:
        """
        Return Counter Clockwise array coordinates

        Parameters
        ----------
        ring: shapely.geometry.polygon.LinearRing
            LinearRing

        Returns
        -------
        out: ndarray
            (n x 2) array of coordinate points.
        """
        if ring.is_ccw:
            return np.asarray(ring.coords)[:, :2]
        return np.asarray(ring.coords)[:, :2][::-1]

    # The interiors are holes in the Polygon
    # MPL draws a hole if the vertex points are specified
    # in an opposite direction. So we use Clockwise for
    # the exterior/shell and Counter-Clockwise for any
    # interiors/holes
    if obj.geom_type == "Polygon":
        _exterior = [Path(cw_coords(obj.exterior))]
        _interior = [Path(ccw_coords(ring)) for ring in obj.interiors]
    else:
        # A MultiPolygon has one or more Polygon geoms.
        # Concatenate the exterior of all the Polygons
        # and the interiors
        _exterior = []
        _interior = []
        for p in obj.geoms:  # type: ignore
            _exterior.append(Path(cw_coords(p.exterior)))
            _interior.extend([Path(ccw_coords(ring)) for ring in p.interiors])

    path = Path.make_compound_path(*_exterior, *_interior)
    return PathPatch(path)


def check_geopandas():
    try:
        import geopandas  # noqa: F401
    except ImportError as e:
        msg = "geom_map requires geopandas. Please install geopandas."
        raise PlotnineError(msg) from e
