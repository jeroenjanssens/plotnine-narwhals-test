from __future__ import annotations

from collections import Counter
from contextlib import suppress
from typing import TYPE_CHECKING
from warnings import warn

import narwhals as nw
import numpy as np

from .._utils import SIZE_FACTOR, frame, make_line_segments, match, to_rgba
from ..doctools import document
from ..exceptions import PlotnineWarning
from .geom import geom

if TYPE_CHECKING:
    from typing import Any, Literal

    import numpy.typing as npt
    from matplotlib.axes import Axes
    from matplotlib.offsetbox import DrawingArea
    from matplotlib.path import Path

    from plotnine._utils.frame import DataFrame
    from plotnine.coords.coord import coord
    from plotnine.iapi import panel_view
    from plotnine.layer import layer
    from plotnine.typing import BoolArray


@document
class geom_path(geom):
    """
    Connected points

    {usage}

    Parameters
    ----------
    {common_parameters}
    lineend : Literal["butt", "round", "projecting"], default="butt"
        Line end style. This option is applied for solid linetypes.
    linejoin : Literal["round", "miter", "bevel"], default="round"
        Line join style. This option is applied for solid linetypes.
    arrow : ~plotnine.geoms.geom_path.arrow, default=None
        Arrow specification. Default is no arrow.

    See Also
    --------
    plotnine.arrow : for adding arrowhead(s) to paths.
    """

    DEFAULT_AES = {
        "alpha": 1,
        "color": "black",
        "linetype": "solid",
        "size": 0.5,
    }

    REQUIRED_AES = {"x", "y"}
    DEFAULT_PARAMS = {
        "lineend": "butt",
        "linejoin": "round",
        "arrow": None,
    }

    def handle_na(self, data: DataFrame) -> DataFrame:
        def keep(x: BoolArray) -> BoolArray:
            # first non-missing to last non-missing
            first = match([False], x, nomatch=1, start=0)[0]
            last = len(x) - match([False], x[::-1], nomatch=1, start=0)[0]
            bool_idx = np.hstack(
                [
                    np.repeat(False, first),
                    np.repeat(True, last - first),
                    np.repeat(False, len(x) - last),
                ]
            )
            return bool_idx

        if not len(data):
            return data

        # Get indices where any row for the select aesthetics has
        # NaNs at the beginning or the end. Those we drop
        columns = ["x", "y", "size", "color", "linetype"]
        bool_idx = np.column_stack(
            [
                keep(frame.isna(data[c]))  # Beginning or the End
                for c in columns
                if c in data.columns
            ]
        )
        bool_idx = np.all(bool_idx, axis=1)  # Across the aesthetics

        # return data
        n1 = len(data)
        data = frame.filter_rows(data, bool_idx)
        n2 = len(data)

        if n2 != n1 and not self.params["na_rm"]:
            geom = self.__class__.__name__
            msg = f"{geom}: Removed {n1 - n2} rows containing missing values."
            warn(msg, PlotnineWarning)

        return data

    def draw_panel(
        self,
        data: DataFrame,
        panel_params: panel_view,
        coord: coord,
        ax: Axes,
    ):
        group = frame.to_numpy(data["group"])
        if len(np.unique(group)) == len(group):
            geom = self.__class__.__name__
            warn(
                f"{geom}: Each group consist of only one "
                "observation. Do you need to adjust the "
                "group aesthetic?",
                PlotnineWarning,
            )

        # drop lines with less than two points
        c = Counter(group)
        counts = np.array([c[v] for v in group])
        data = frame.filter_rows(data, counts >= 2)

        if len(data) < 2:
            return

        # The sort is stable, we rely on that here
        data = frame.sort(data, "group")

        # When the parameters of the path are not constant
        # with in the group, then the lines that make the paths
        # can be drawn as separate segments
        cols = {"color", "size", "linetype", "alpha", "group"}
        cols = sorted(cols & set(data.columns))
        rows = zip(*(data[c].to_list() for c in cols))
        num_unique_rows = len(set(rows))
        ngroup = data["group"].n_unique()

        constant = num_unique_rows == ngroup
        self.params["constant"] = constant

        if not constant:
            self.draw_group(data, panel_params, coord, ax, self.params)
        else:
            for _, gdata in frame.group_split(data, "group"):
                self.draw_group(gdata, panel_params, coord, ax, self.params)

    @staticmethod
    def draw_group(
        data: DataFrame,
        panel_params: panel_view,
        coord: coord,
        ax: Axes,
        params: dict[str, Any],
    ):
        data = coord.transform(data, panel_params, munch=True)
        data = data.with_columns(linewidth=nw.col("size") * SIZE_FACTOR)
        constant = stroke_paths(data, ax, params, params.get("constant"))

        if "arrow" in params and params["arrow"]:
            params["arrow"].draw(
                data, panel_params, coord, ax, params, constant=constant
            )

    @staticmethod
    def draw_legend(
        data: dict[str, Any], da: DrawingArea, lyr: layer
    ) -> DrawingArea:
        """
        Draw a horizontal line in the box

        Parameters
        ----------
        data : dict
            Data Row
        da : DrawingArea
            Canvas
        lyr : layer
            Layer

        Returns
        -------
        out : DrawingArea
        """
        from matplotlib.lines import Line2D

        linewidth = data["size"] * SIZE_FACTOR
        x = [0, da.width]
        y = [0.5 * da.height] * 2
        color = to_rgba(data["color"], data["alpha"])

        key = Line2D(
            x,
            y,
            linestyle=data["linetype"],
            linewidth=linewidth,
            color=color,
            solid_capstyle="butt",
            antialiased=False,
        )
        da.add_artist(key)
        return da

    @staticmethod
    def legend_key_size(
        data: dict[str, Any], min_size: tuple[int, int], lyr: layer
    ) -> tuple[int, int]:
        w, h = min_size
        pad_w, pad_h = w * 0.5, h * 0.5
        _w = _h = data.get("size", 0) * SIZE_FACTOR
        if data["color"] is not None:
            w = max(w, _w + pad_w)
            h = max(h, _h + pad_h)
        return w, h


class arrow:
    """
    Define arrow (actually an arrowhead)

    This is used to define arrow heads for
    [](`~plotnine.geoms.geom_path`).

    Parameters
    ----------
    angle :
        angle in degrees between the tail a
        single edge.
    length :
        of the edge in "inches"
    ends :
        At which end of the line to draw the
        arrowhead
    type :
        When it is closed, it is also filled
    """

    def __init__(
        self,
        angle: float = 30,
        length: float = 0.2,
        ends: Literal["first", "last", "both"] = "last",
        type: Literal["open", "closed"] = "open",
    ):
        self.angle = angle
        self.length = length
        self.ends = ends
        self.type = type

    def draw(
        self,
        data: DataFrame,
        panel_params: panel_view,
        coord: coord,
        ax: Axes,
        params: dict[str, Any],
        constant: bool = True,
    ):
        """
        Draw arrows at the end(s) of the lines

        Parameters
        ----------
        data : dataframe
            Data to be plotted by this geom. This is the
            dataframe created in the plot_build pipeline.
        panel_params : panel_view
            The scale information as may be required by the
            axes. At this point, that information is about
            ranges, ticks and labels. Attributes are of interest
            to the geom are:

            ```python
            "panel_params.x.range"  # tuple
            "panel_params.y.range"  # tuple
            ```
        coord : coord
            Coordinate (e.g. coord_cartesian) system of the
            geom.
        ax : axes
            Axes on which to plot.
        constant: bool
            If the path attributes vary along the way. If false,
            the arrows are per segment of the path
        params : dict
            Combined parameters for the geom and stat. Also
            includes the `zorder`.
        """
        first = self.ends in ("first", "both")
        last = self.ends in ("last", "both")

        data = frame.sort(data, "group")
        if "linewidth" not in data.columns:
            data = data.with_columns(linewidth=nw.col("size") * SIZE_FACTOR)

        color = to_rgba(data["color"], data["alpha"])
        facecolor = ["none"] * len(data) if self.type == "open" else color

        x = frame.to_numpy(data["x"])
        y = frame.to_numpy(data["y"])
        linewidth = frame.to_numpy(data["linewidth"])
        linetype = data["linetype"].to_list()

        if not constant:
            from matplotlib.collections import PathCollection

            # Get segments/points (x1, y1) -> (x2, y2)
            # for which to calculate the arrow heads
            group = frame.to_numpy(data["group"])
            idx1: list[int] = []
            idx2: list[int] = []
            for g in np.unique(group):
                positions = np.flatnonzero(group == g)
                idx1.extend(positions[:-1])
                idx2.extend(positions[1:])

            d = {
                "zorder": params["zorder"],
                "rasterized": params["raster"],
                "edgecolor": [color[i] for i in idx1],
                "facecolor": [facecolor[i] for i in idx1],
                "linewidth": linewidth[idx1],
                "linestyle": [linetype[i] for i in idx1],
            }

            x1, y1 = x[idx1], y[idx1]
            x2, y2 = x[idx2], y[idx2]

            if first:
                paths = self.get_paths(x1, y1, x2, y2, panel_params, coord, ax)
                coll = PathCollection(paths, **d)
                ax.add_collection(coll)
            if last:
                x1, y1, x2, y2 = x2, y2, x1, y1
                paths = self.get_paths(x1, y1, x2, y2, panel_params, coord, ax)
                coll = PathCollection(paths, **d)
                ax.add_collection(coll)
        else:
            from matplotlib.patches import PathPatch

            d = {
                "zorder": params["zorder"],
                "rasterized": params["raster"],
                "edgecolor": color[0],
                "facecolor": facecolor[0],
                "linewidth": linewidth[0],
                "linestyle": linetype[0],
                "joinstyle": "round",
                "capstyle": "butt",
            }

            if first:
                x1, x2 = x[0:2]
                y1, y2 = y[0:2]
                x1, y1, x2, y2 = (np.array([i]) for i in (x1, y1, x2, y2))
                paths = self.get_paths(x1, y1, x2, y2, panel_params, coord, ax)
                patch = PathPatch(paths[0], **d)
                ax.add_artist(patch)

            if last:
                x1, x2 = x[-2:]
                y1, y2 = y[-2:]
                x1, y1, x2, y2 = x2, y2, x1, y1
                x1, y1, x2, y2 = (np.array([i]) for i in (x1, y1, x2, y2))
                paths = self.get_paths(x1, y1, x2, y2, panel_params, coord, ax)
                patch = PathPatch(paths[0], **d)
                ax.add_artist(patch)

    def get_paths(
        self,
        x1: npt.ArrayLike,
        y1: npt.ArrayLike,
        x2: npt.ArrayLike,
        y2: npt.ArrayLike,
        panel_params: panel_view,
        coord: coord,
        ax: Axes,
    ) -> list[Path]:
        """
        Compute paths that create the arrow heads

        Parameters
        ----------
        x1, y1, x2, y2 : array_like
            List of points that define the tails of the arrows.
            The arrow heads will be at x1, y1. If you need them
            at x2, y2 reverse the input.
        panel_params : panel_view
            The scale information as may be required by the
            axes. At this point, that information is about
            ranges, ticks and labels. Attributes are of interest
            to the geom are:

            ```python
            "panel_params.x.range"  # tuple
            "panel_params.y.range"  # tuple
            ```
        coord : coord
            Coordinate (e.g. coord_cartesian) system of the geom.
        ax : axes
            Axes on which to plot.

        Returns
        -------
        out : list of Path
            Paths that create arrow heads
        """
        from matplotlib.path import Path

        # The arrowhead path has 3 vertices,
        # plus a dummy vertex for the STOP code
        dummy = (0, 0)

        # codes list remains the same after initialization
        codes = [Path.MOVETO, Path.LINETO, Path.LINETO, Path.STOP]

        # We need the axes dimensions so that we can
        # compute scaling factors
        width, height = _axes_get_size_inches(ax)
        width_ = np.ptp(panel_params.x.range)
        height_ = np.ptp(panel_params.y.range)

        # scaling factors to prevent skewed arrowheads
        lx = self.length * width_ / width
        ly = self.length * height_ / height

        # angle in radians
        a = self.angle * np.pi / 180

        # direction of arrow head
        xdiff, ydiff = x2 - x1, y2 - y1  # type: ignore
        rotations = np.arctan2(ydiff / ly, xdiff / lx)

        # Arrow head vertices
        v1x = x1 + lx * np.cos(rotations + a)
        v1y = y1 + ly * np.sin(rotations + a)
        v2x = x1 + lx * np.cos(rotations - a)
        v2y = y1 + ly * np.sin(rotations - a)

        # create a path for each arrow head
        paths = []
        for t in zip(v1x, v1y, x1, y1, v2x, v2y):  # type: ignore
            verts = [t[:2], t[2:4], t[4:], dummy]
            paths.append(Path(verts, codes))

        return paths


def stroke_paths(
    data: DataFrame,
    ax: Axes,
    params: dict[str, Any],
    constant: bool | None = None,
) -> bool:
    """
    Draw paths from panel-coordinate data

    Parameters
    ----------
    data :
        Path data in panel coordinates. Must include a `size` column.
    ax :
        Axes on which to draw the paths.
    params :
        Geom and stat parameters used to style the paths.
    constant :
        Whether aesthetics remain constant along each path. If `False`,
        draw each pair of adjacent points as a separate segment. If
        `None`, infer `True` when the data contains one group.

    Returns
    -------
    :
        Whether the paths were drawn with constant aesthetics. Callers
        use this value to draw matching arrowheads.
    """
    if "linewidth" not in data.columns:
        data = data.with_columns(linewidth=nw.col("size") * SIZE_FACTOR)

    if constant is None:
        constant = data["group"].n_unique() == 1

    if constant:
        _draw_lines(data, ax, params)
    else:
        _draw_segments(data, ax, params)

    return constant


def _draw_segments(data: DataFrame, ax: Axes, params: dict[str, Any]):
    """
    Draw independent line segments between all the
    points
    """
    from matplotlib.collections import LineCollection

    color = to_rgba(data["color"], data["alpha"])
    group = frame.to_numpy(data["group"])
    x = frame.to_numpy(data["x"])
    y = frame.to_numpy(data["y"])
    linewidths = frame.to_numpy(data["linewidth"])
    linetypes = data["linetype"].to_list()

    # All we do is line-up all the points in a group
    # into segments, all in a single list.
    # Along the way the other parameters are put in
    # sequences accordingly
    indices: list[int] = []  # for attributes of starting point of each segment
    _segments = []
    for g in np.unique(group):
        idx = np.flatnonzero(group == g)
        indices.extend(idx[:-1])  # One line from two points
        _segments.append(make_line_segments(x[idx], y[idx], ispath=True))

    segments = np.vstack(_segments).tolist()

    edgecolor = color if color is None else [color[i] for i in indices]
    linewidth = linewidths[indices]
    linestyle = [linetypes[i] for i in indices]

    coll = LineCollection(
        segments,
        edgecolor=edgecolor,
        linewidth=linewidth,
        linestyle=linestyle,
        capstyle=params.get("lineend"),
        zorder=params["zorder"],
        rasterized=params["raster"],
    )
    ax.add_collection(coll)


def _draw_lines(data: DataFrame, ax: Axes, params: dict[str, Any]):
    """
    Draw a path with the same characteristics from the
    first point to the last point
    """
    from matplotlib.lines import Line2D

    color = to_rgba(data["color"].item(0), data["alpha"].item(0))
    join_style = _get_joinstyle(data, params)
    lines = Line2D(
        frame.to_numpy(data["x"]),
        frame.to_numpy(data["y"]),
        color=color,
        linewidth=data["linewidth"].item(0),
        linestyle=data["linetype"].item(0),
        zorder=params["zorder"],
        rasterized=params["raster"],
        **join_style,
    )
    ax.add_artist(lines)


def _get_joinstyle(data: DataFrame, params: dict[str, Any]) -> dict[str, Any]:
    with suppress(KeyError):
        if params["linejoin"] == "mitre":
            params["linejoin"] = "miter"

    with suppress(KeyError):
        if params["lineend"] == "square":
            params["lineend"] = "projecting"

    joinstyle = params.get("linejoin", "miter")
    capstyle = params.get("lineend", "butt")
    d = {}
    linetype = data["linetype"].item(0)
    if linetype == "solid":
        d["solid_joinstyle"] = joinstyle
        d["solid_capstyle"] = capstyle
    elif linetype == "dashed":
        d["dash_joinstyle"] = joinstyle
        d["dash_capstyle"] = capstyle
    return d


def _axes_get_size_inches(ax: Axes) -> tuple[float, float]:
    """
    Size of axes in inches

    Parameters
    ----------
    ax : axes
        Axes

    Returns
    -------
    out : tuple[float, float]
        (width, height) of ax in inches
    """
    fig = ax.get_figure()
    bbox = ax.get_window_extent().transformed(
        fig.dpi_scale_trans.inverted()  # pyright: ignore
    )
    return bbox.width, bbox.height
