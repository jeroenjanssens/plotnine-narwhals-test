from __future__ import annotations

from abc import ABC
from contextlib import suppress
from copy import deepcopy
from itertools import chain, repeat
from typing import TYPE_CHECKING

import numpy as np

from .._utils import (
    data_mapping_as_kwargs,
    frame,
    remove_missing,
)
from .._utils.registry import Register, _MergedDefaultParams
from ..exceptions import PlotnineError
from ..layer import layer
from ..mapping.aes import rename_aesthetics
from ..mapping.evaluation import evaluate

if TYPE_CHECKING:
    from typing import Any

    from matplotlib.axes import Axes
    from matplotlib.offsetbox import DrawingArea

    from plotnine import aes, ggplot
    from plotnine._utils.frame import DataFrame
    from plotnine.coords.coord import coord
    from plotnine.facets.layout import Layout
    from plotnine.iapi import panel_view
    from plotnine.mapping import Environment
    from plotnine.typing import DataLike


class geom(ABC, metaclass=Register):
    """Base class of all Geoms"""

    DEFAULT_AES: dict[str, Any] = {}
    """Default aesthetics for the geom"""

    REQUIRED_AES: set[str] = set()
    """Required aesthetics for the geom"""

    NON_MISSING_AES: set[str] = set()
    """Required aesthetics for the geom"""

    DEFAULT_PARAMS: dict[str, Any] = {
        "stat": "identity",
        "position": "identity",
        "na_rm": False,
    }
    """
    Default values for the parameters that the geom accepts

    A geom inherits the parameters of its parent geom; declare only
    those that are new or have a different default value.
    """

    data: DataLike
    """Geom/layer specific dataframe"""

    mapping: aes
    """Mappings i.e. `aes(x="col1", fill="col2")`{.py}"""

    # All recognized parameters and their default values
    default_params = _MergedDefaultParams()

    aes_params: dict[str, Any] = {}  # setting of aesthetic
    params: dict[str, Any]  # parameter settings

    # Plot namespace, it gets its value when the plot is being
    # built.
    environment: Environment

    # The geom responsible for the legend if draw_legend is
    # not implemented
    legend_geom: str = "point"

    # Documentation for the aesthetics. It is added under the
    # documentation for mapping parameter. Use {aesthetics}
    # placeholder to insert a table for all the aesthetics and
    # their default values.
    _aesthetics_doc: str = "{aesthetics_table}"

    def __init__(
        self,
        mapping: aes | None = None,
        data: DataLike | None = None,
        **kwargs: Any,
    ):
        kwargs = rename_aesthetics(kwargs)
        kwargs = data_mapping_as_kwargs((data, mapping), kwargs)
        self._raw_kwargs = kwargs  # Will be used to create stat & layer
        overridden_params = self.default_params.keys() & kwargs.keys()

        # separate aesthetics and parameters
        self.aes_params = {
            ae: kwargs[ae] for ae in self.aesthetics() & set(kwargs)
        }
        self.params = {
            **self.default_params,
            **{k: kwargs[k] for k in overridden_params},
        }
        self.mapping = kwargs["mapping"]
        self.data = kwargs["data"]

    @classmethod
    def aesthetics(cls: type[geom]) -> set[str]:
        """
        Return all the aesthetics for this geom

        geoms should not override this method.
        """
        main = cls.DEFAULT_AES.keys() | cls.REQUIRED_AES
        other = {"group", "subgroup"}
        # Need to recognize both spellings
        if "color" in main:
            other.add("colour")
        if "outlier_color" in main:
            other.add("outlier_colour")
        return main | other

    def __deepcopy__(self, memo: dict[Any, Any]) -> geom:
        """
        Deep copy without copying the self.data dataframe

        geoms should not override this method.
        """
        cls = self.__class__
        result = cls.__new__(cls)
        memo[id(self)] = result
        old = self.__dict__
        new = result.__dict__

        # don't make a deepcopy of data, or environment
        shallow = {"data", "_raw_kwargs", "environment"}
        for key, item in old.items():
            if key in shallow:
                new[key] = item  # pyright: ignore[reportIndexIssue]
                memo[id(new[key])] = new[key]
            else:
                new[key] = deepcopy(item, memo)  # pyright: ignore[reportIndexIssue]

        return result

    def setup_params(self, data: DataFrame):
        """
        Override this method to verify and/or adjust parameters

        Parameters
        ----------
        data :
            Data
        """

    def setup_aes_params(self, data: DataFrame):
        """
        Override this method to verify and/or adjust aesthetic parameters

        Parameters
        ----------
        data :
            Data
        """

    def setup_data(self, data: DataFrame) -> DataFrame:
        """
        Modify the data before drawing takes place

        This function is called *before* position adjustments are done.
        It is used by geoms to create the final aesthetics used for
        drawing. The base class method does nothing, geoms can override
        this method for two reasons:

        1. The `stat` does not create all the aesthetics (usually
           position aesthetics) required for drawing the `geom`,
           but those aesthetics can be computed from the available
           data. For example [](`~plotnine.geoms.geom_boxplot`)
           and [](`~plotnine.geoms.geom_violin`).

        2. The `geom` inherits from another `geom` (superclass) which
           does the drawing and the superclass requires certain aesthetics
           to be present in the data. For example
           [](`~plotnine.geoms.geom_tile`) and
           [](`~plotnine.geoms.geom_area`).

        Parameters
        ----------
        data :
            Data used for drawing the geom.

        Returns
        -------
        :
            Data used for drawing the geom.
        """
        return data

    def use_defaults(
        self, data: DataFrame, aes_modifiers: dict[str, Any]
    ) -> DataFrame:
        """
        Combine data with defaults and set aesthetics from parameters

        geoms should not override this method.

        Parameters
        ----------
        data :
            Data used for drawing the geom.
        aes_modifiers :
            Aesthetics to evaluate

        Returns
        -------
        :
            Data used for drawing the geom.
        """
        from plotnine.mapping._asis import is_asis
        from plotnine.mapping._atomic import ae_value, broadcast_ae_value

        missing_aes = (
            self.DEFAULT_AES.keys()
            - self.aes_params.keys()
            - set(data.columns)
        )

        # Not in data and not set, use default
        data = frame.assign(
            data, **{ae: self.DEFAULT_AES[ae] for ae in sorted(missing_aes)}
        )

        # Evaluate/Modify the mapped aesthetics
        evaled = evaluate(aes_modifiers, data, self.environment)
        modified = [ae for ae in evaled.columns if ae in data.columns]
        if modified:
            data = data.with_columns(evaled[ae] for ae in modified)

        n = len(data)
        num_panels = data["PANEL"].n_unique() if "PANEL" in data.columns else 1
        across_panels = num_panels > 1 and not self.params["inherit_aes"]

        # Aesthetics set as parameters in the geom/stat
        params = {}
        for ae, value in self.aes_params.items():
            if isinstance(value, (str, int, float, np.integer, np.floating)):
                params[ae] = value
            elif isinstance(value, ae_value):
                params[ae] = value * n
            elif is_asis(value):
                # The layer records literal parameters, so position
                # fractions remain available for later resolution.
                values = value.to_numpy()
                params[ae] = (
                    np.repeat(values, n) if len(values) == 1 else values
                )
            elif across_panels:
                params[ae] = list(chain(*repeat(value, num_panels)))
            else:
                # Try to make sense of aesthetics whose values can be tuples
                # or sequences of sorts.
                with suppress(ValueError):
                    params[ae] = broadcast_ae_value(value, ae, n)
                    continue

                # This should catch the aesthetic assignments to
                # non-numeric or non-string values or sequence of values.
                # e.g. x=datetime, x=Sequence[datetime],
                #      x=Sequence[float], shape=Sequence[str]
                params[ae] = value

        try:
            return frame.assign(data, **params)
        except (ValueError, TypeError) as e:
            msg = (
                f"Aesthetic parameters {self.aes_params} are not valid values"
            )
            raise PlotnineError(msg) from e

    def draw_layer(self, data: DataFrame, layout: Layout, coord: coord):
        """
        Draw layer across all panels

        geoms should not override this method.

        Parameters
        ----------
        data :
            DataFrame specific for this layer
        layout :
            Layout object created when the plot is getting
            built
        coord :
            Type of coordinate axes
        params :
            Combined *geom* and *stat* parameters. Also
            includes the stacking order of the layer in
            the plot (*zorder*)
        """
        for _, pdata in frame.group_split(data, "PANEL"):
            if len(pdata) == 0:
                continue
            ploc = pdata["PANEL"].item(0) - 1
            panel_params = layout.panel_params[ploc]
            ax = layout.axs[ploc]
            self.draw_panel(pdata, panel_params, coord, ax)

    def draw_panel(
        self,
        data: DataFrame,
        panel_params: panel_view,
        coord: coord,
        ax: Axes,
    ):
        """
        Plot all groups

        For efficiency, geoms that do not need to partition
        different groups before plotting should override this
        method and avoid the groupby.

        Parameters
        ----------
        data :
            Data to be plotted by this geom. This is the
            dataframe created in the plot_build pipeline.
        panel_params :
            The scale information as may be required by the
            axes. At this point, that information is about
            ranges, ticks and labels. Attributes are of interest
            to the geom are:

            ```python
            "panel_params.x.range"  # tuple
            "panel_params.y.range"  # tuple
            ```
        coord :
            Coordinate (e.g. coord_cartesian) system of the geom.
        ax :
            Axes on which to plot.
        params :
            Combined parameters for the geom and stat. Also
            includes the `zorder`.
        """
        for _, gdata in frame.group_split(data, "group"):
            self.draw_group(gdata, panel_params, coord, ax, self.params)

    @staticmethod
    def draw_group(
        data: DataFrame,
        panel_params: panel_view,
        coord: coord,
        ax: Axes,
        params: dict[str, Any],
    ):
        """
        Plot data belonging to a group.

        Parameters
        ----------
        data :
            Data to be plotted by this geom. This is the
            dataframe created in the plot_build pipeline.
        panel_params :
            The scale information as may be required by the
            axes. At this point, that information is about
            ranges, ticks and labels. Keys of interest to
            the geom are:

            ```python
            "x_range"  # tuple
            "y_range"  # tuple
            ```
        coord : coord
            Coordinate (e.g. coord_cartesian) system of the geom.
        ax : axes
            Axes on which to plot.
        params : dict
            Combined parameters for the geom and stat. Also
            includes the `zorder`.
        """
        msg = "The geom should implement this method."
        raise NotImplementedError(msg)

    @staticmethod
    def draw_unit(
        data: DataFrame,
        panel_params: panel_view,
        coord: coord,
        ax: Axes,
        params: dict[str, Any],
    ):
        """
        Plot data belonging to a unit.

        A matplotlib plot function may require that an aethestic
        have a single unique value. e.g. `linestyle="dashed"`{.py}
        and not `linestyle=["dashed", "dotted", ...]`{.py}.
        A single call to such a function can only plot lines with
        the same linestyle. However, if the plot we want has more
        than one line with different linestyles, we need to group
        the lines with the same linestyle and plot them as one
        unit. In this case, draw_group calls this function to do
        the plotting. For an example see
        [](`~plotnine.geoms.geom_point`).

        Parameters
        ----------
        data :
            Data to be plotted by this geom. This is the
            dataframe created in the plot_build pipeline.
        panel_params :
            The scale information as may be required by the
            axes. At this point, that information is about
            ranges, ticks and labels. Keys of interest to
            the geom are:

            ```python
            "x_range"  # tuple
            "y_range"  # tuple
            ```

            In rare cases a geom may need access to the x or y scales.
            Those are available at:

            ```python
            "scales"   # SimpleNamespace
            ```
        coord :
            Coordinate (e.g. coord_cartesian) system of the
            geom.
        ax :
            Axes on which to plot.
        params :
            Combined parameters for the geom and stat. Also
            includes the `zorder`.
        """
        msg = "The geom should implement this method."
        raise NotImplementedError(msg)

    def __radd__(self, other: ggplot) -> ggplot:
        """
        Add layer representing geom object on the right

        Parameters
        ----------
        other :
            ggplot object

        Returns
        -------
        :
            ggplot object with added layer.
        """
        other += layer(geom=self)
        return other

    def handle_na(self, data: DataFrame) -> DataFrame:
        """
        Remove rows with NaN values

        geoms that infer extra information from missing values
        should override this method. For example
        [](`~plotnine.geoms.geom_path`).

        Parameters
        ----------
        data :
            Data

        Returns
        -------
        :
            Data without the NaNs.

        Notes
        -----
        Shows a warning if the any rows are removed and the
        `na_rm` parameter is False. It only takes into account
        the columns of the required aesthetics.
        """
        return remove_missing(
            data,
            self.params.get("na_rm", False),
            list(self.REQUIRED_AES | self.NON_MISSING_AES),
            self.__class__.__name__,
        )

    @staticmethod
    def draw_legend(
        data: dict[str, Any], da: DrawingArea, lyr: layer
    ) -> DrawingArea:
        """
        Draw a rectangle in the box

        Parameters
        ----------
        data :
            A row of the data plotted to this layer. It maps the
            column names to the values.
        da :
            Canvas on which to draw
        lyr :
            Layer that the geom belongs to.

        Returns
        -------
        :
            The DrawingArea after a layer has been drawn onto it.
        """
        msg = "The geom should implement this method."
        raise NotImplementedError(msg)

    @staticmethod
    def legend_key_size(
        data: dict[str, Any], min_size: tuple[int, int], lyr: layer
    ) -> tuple[int, int]:
        """
        Calculate the size of key that would fit the layer contents

        Parameters
        ----------
        data :
            A row of the data plotted to this layer
        min_size :
            Initial size which should be expanded to fit the contents.
        lyr :
            Layer
        """
        return min_size
