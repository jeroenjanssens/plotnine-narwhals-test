from __future__ import annotations

import re
import typing
from warnings import warn

import narwhals as nw
import numpy as np

from .._utils import frame, join_keys, match
from .._utils.frame import native_io
from ..exceptions import PlotnineError, PlotnineWarning
from .facet import (
    add_missing_facets,
    combine_vars,
    eval_facet_vars,
    facet,
    layout_null,
)
from .strips import Strips, strip

if typing.TYPE_CHECKING:
    from typing import Any, Literal, Optional, Sequence

    import numpy.typing as npt
    from matplotlib.axes import Axes

    from plotnine._utils.frame import DataFrame
    from plotnine.iapi import layout_details
    from plotnine.typing import StripPosition

    from ..scales.scales import Scales


class facet_wrap(facet):
    """
    Wrap 1D Panels onto 2D surface

    Parameters
    ----------
    facets :
        Variables to groupby and plot on different panels.
        If a string formula is used it should be right sided,
        e.g `"~ a + b"`, `("a", "b")`
    nrow : int, default=None
        Number of rows
    ncol : int, default=None
        Number of columns
    scales :
        Whether `x` or `y` scales should be allowed (free)
        to vary according to the data on each of the panel.
    shrink :
        Whether to shrink the scales to the output of the
        statistics instead of the raw data.
    labeller :
        How to label the facets. A string value if it should be
        one of `["label_value", "label_both", "label_context"]`{.py}.
    as_table :
        If `True`, the facets are laid out like a table with
        the highest values at the bottom-right. If `False`
        the facets are laid out like a plot with the highest
        value a the top-right
    drop :
        If `True`, all factor levels not used in the data
        will automatically be dropped. If `False`, all
        factor levels will be shown, regardless of whether
        or not they appear in the data.
    dir :
        Direction in which to layout the panels. `h` for
        horizontal and `v` for vertical.
    strip_position :
        Side of each panel on which to draw the strip. One of
        `["top", "bottom", "left", "right"]`{.py}.
    """

    def __init__(
        self,
        facets: Optional[str | Sequence[str]] = None,
        *,
        nrow: Optional[int] = None,
        ncol: Optional[int] = None,
        scales: Literal["fixed", "free", "free_x", "free_y"] = "fixed",
        shrink: bool = True,
        labeller: Literal[
            "label_value", "label_both", "label_context"
        ] = "label_value",
        as_table: bool = True,
        drop: bool = True,
        dir: Literal["h", "v"] = "h",
        strip_position: Literal["top", "bottom", "left", "right"] = "top",
    ):
        super().__init__(
            scales=scales,
            shrink=shrink,
            labeller=labeller,
            as_table=as_table,
            drop=drop,
            dir=dir,
        )
        if strip_position not in ("top", "bottom", "left", "right"):
            raise PlotnineError(
                "strip_position should be one of 'top', 'bottom', "
                f"'left' or 'right'. Got {strip_position!r}."
            )
        self.strip_position: StripPosition = strip_position
        self.vars = parse_wrap_facets(facets)
        self._nrow, self._ncol = check_dimensions(nrow, ncol)

    def compute_layout(
        self,
        data: list[DataFrame],
        scales: Scales,
    ) -> DataFrame:
        if not self.vars:
            self.nrow, self.ncol = 1, 1
            return layout_null(data[0].implementation)

        base = combine_vars(data, self.environment, self.vars, drop=self.drop)
        n = len(base)
        dims = wrap_dims(n, self._nrow, self._ncol)
        _id = np.arange(1, n + 1)

        if self.dir == "v":
            dims = dims[::-1]

        if self.as_table:
            row = (_id - 1) // dims[1] + 1
        else:
            row = dims[0] - (_id - 1) // dims[1]

        col = (_id - 1) % dims[1] + 1

        if self.dir == "v":
            row, col = col, row

        layout = frame.frame(
            {"PANEL": _id, "ROW": row.astype(int), "COL": col.astype(int)},
            backend=base.implementation,
        )
        layout = nw.concat([layout, base], how="horizontal")
        self.nrow = layout["ROW"].n_unique()
        self.ncol = layout["COL"].n_unique()

        # Figure out where axes should go.
        # The row/column of each panel that shows the axis, on the side the
        # axis sits (default: bottom-most row, left-most column)
        rows, cols = layout["ROW"].to_numpy(), layout["COL"].to_numpy()
        x_side, y_side = scales.axis_positions
        if x_side == "top":
            x_idx, x_sec_idx = (
                _argext(cols, rows, min),
                _argext(cols, rows, max),
            )
        else:
            x_idx, x_sec_idx = (
                _argext(cols, rows, max),
                _argext(cols, rows, min),
            )
        if y_side == "right":
            y_idx, y_sec_idx = (
                _argext(rows, cols, max),
                _argext(rows, cols, min),
            )
        else:
            y_idx, y_sec_idx = (
                _argext(rows, cols, min),
                _argext(rows, cols, max),
            )

        def flags(idx: list[int], free: bool) -> npt.NDArray[np.bool_]:
            arr = np.zeros(n, dtype=bool)
            arr[idx] = True
            return arr | free

        return frame.assign(
            layout,
            # Add scale identification
            SCALE_X=_id if self.free["x"] else 1,
            SCALE_Y=_id if self.free["y"] else 1,
            AXIS_X=flags(x_idx, self.free["x"]),
            AXIS_Y=flags(y_idx, self.free["y"]),
            AXIS_X_SEC=flags(x_sec_idx, self.free["x"]),
            AXIS_Y_SEC=flags(y_sec_idx, self.free["y"]),
        )

    @native_io
    def map(self, data: DataFrame, layout: DataFrame) -> DataFrame:
        if not len(data):
            return frame.assign(
                data,
                PANEL=frame.series(
                    [], backend=data.implementation, dtype=nw.Int64
                ),
            )

        facet_vals = eval_facet_vars(data, self.vars, self.environment)
        data, facet_vals = add_missing_facets(
            data, layout, self.vars, facet_vals
        )

        # assign each point to a panel
        if len(facet_vals) and len(facet_vals.columns):
            keys = join_keys(
                facet_vals,
                frame.convert(layout, data.implementation),
                self.vars,
            )
            panel = match(keys["x"], keys["y"], start=1)
        else:
            # Special case of no facetting
            panel = 1

        return frame.assign(data, PANEL=panel)

    def make_strips(self, layout_info: layout_details, ax: Axes) -> Strips:
        if not self.vars:
            return Strips([])

        s = strip(self.vars, layout_info, self, ax, self.strip_position)
        return Strips([s])


def check_dimensions(
    nrow: Optional[int], ncol: Optional[int]
) -> tuple[int | None, int | None]:
    """
    Verify dimensions of the facet
    """
    if nrow is not None:
        if nrow < 1:
            warn(
                "'nrow' must be greater than 0. Your value has been ignored.",
                PlotnineWarning,
            )
            nrow = None
        else:
            nrow = int(nrow)

    if ncol is not None:
        if ncol < 1:
            warn(
                "'ncol' must be greater than 0. Your value has been ignored.",
                PlotnineWarning,
            )
            ncol = None
        else:
            ncol = int(ncol)

    return nrow, ncol


def parse_wrap_facets(facets: Optional[str | Sequence[str]]) -> Sequence[str]:
    """
    Return list of facetting variables
    """
    if facets is None:
        return []
    elif isinstance(facets, str):
        if "~" in facets:
            return parse_wrap_facets_old(facets)  # formala
        else:
            return [facets]
    return facets


def parse_wrap_facets_old(facets: str | Sequence[str]) -> Sequence[str]:
    """
    Return list of facetting variables

    This handles the old & silently deprecated r-style formulas
    """
    valid_forms = ["~ var1", "~ var1 + var2"]
    error_msg = f"Valid formula for 'facet_wrap' look like {valid_forms}"

    if isinstance(facets, (list, tuple)):
        return facets

    if not isinstance(facets, str):
        raise PlotnineError(error_msg)

    if "~" in facets:
        variables_pattern = r"(\w+(?:\s*\+\s*\w+)*|\.)"
        pattern = rf"\s*~\s*{variables_pattern}\s*"
        match = re.match(pattern, facets)
        if not match:
            raise PlotnineError(error_msg)

        facets = [var.strip() for var in match.group(1).split("+")]
    elif re.match(r"\w+", facets):
        # allow plain string as the variable name
        facets = [facets]
    else:
        raise PlotnineError(error_msg)

    return facets


def wrap_dims(
    n: int, nrow: Optional[int] = None, ncol: Optional[int] = None
) -> tuple[int, int]:
    """
    Wrap dimensions
    """
    if nrow is None:
        if ncol is None:
            return n_to_nrow_ncol(n)
        else:
            nrow = int(np.ceil(n / ncol))

    if ncol is None:
        ncol = int(np.ceil(n / nrow))

    if not nrow * ncol >= n:
        raise PlotnineError(
            "Allocated fewer panels than are required. "
            "Make sure the number of rows and columns can "
            "hold all the plot panels."
        )
    return (nrow, ncol)


def n_to_nrow_ncol(n: int) -> tuple[int, int]:
    """
    Compute the rows and columns given the number of plots.
    """
    if n <= 3:
        nrow, ncol = 1, n
    elif n <= 6:
        nrow, ncol = 2, (n + 1) // 2
    elif n <= 12:
        nrow, ncol = 3, (n + 2) // 3
    else:
        ncol = int(np.ceil(np.sqrt(n)))
        nrow = int(np.ceil(n / ncol))
    return (nrow, ncol)


def _argext(
    groups: npt.NDArray[Any], values: npt.NDArray[Any], fn
) -> list[int]:
    """
    For each group, the position of the first min/max value
    """
    result = []
    for g in np.unique(groups):
        (positions,) = np.nonzero(groups == g)
        target = fn(values[positions])
        result.append(int(positions[values[positions] == target][0]))
    return result
